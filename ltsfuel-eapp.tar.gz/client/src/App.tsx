import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { Header } from "@/components/header";
import { NavigationTabs } from "@/components/navigation-tabs";
import { MaintenanceBanner } from "@/components/maintenance-banner";
import Dashboard from "@/pages/dashboard";
import FuelForm from "@/pages/fuel-form";
import Deliveries from "@/pages/deliveries";
import Tanks from "@/pages/tanks";
import History from "@/pages/history";
import AdminApp from "@/pages/admin-app";
import LoginPage from "@/pages/login-page";
import NotFound from "@/pages/not-found";

function DriverRouter() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/fuel" component={FuelForm} />
      <ProtectedRoute path="/deliveries" component={Deliveries} />
      <ProtectedRoute path="/tanks" component={Tanks} />
      <ProtectedRoute path="/history" component={History} />
      <Route component={NotFound} />
    </Switch>
  );
}

function DriverApp() {
  return (
    <div className="min-h-screen bg-gray-50">
      <MaintenanceBanner />
      <Header />
      <div className="mobile-container py-4 sm:py-6">
        <NavigationTabs />
        <DriverRouter />
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Switch>
            <Route path="/login" component={LoginPage} />
            <ProtectedRoute path="/admin/:rest*" component={AdminApp} requiredRole="admin" />
            <ProtectedRoute path="/admin" component={AdminApp} requiredRole="admin" />
            <Route path="/" component={DriverApp} />
            <Route path="/fuel" component={DriverApp} />
            <Route path="/deliveries" component={DriverApp} />
            <Route path="/tanks" component={DriverApp} />
            <Route path="/history" component={DriverApp} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
