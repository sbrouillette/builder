import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Switch } from "@/components/ui/switch";
import { Settings, MessageSquare, AlertTriangle, Loader2, ChevronDown, Sliders, Users, Plus, Edit, Trash2, Shield, ClipboardList, Truck, Fuel, Building, Database, Server, Mail, Key, Clock } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";

type SystemSetting = {
  id: string;
  key: string;
  value: string;
  description?: string;
  updatedAt: string;
  updatedBy?: string;
};

type User = {
  id: string;
  username: string;
  name: string;
  email: string;
  role: "driver" | "administrator" | "developer";
  permissions: string;
  status: string;
};

type RoleTemplate = {
  name: string;
  description: string;
  permissions: any;
};

type RoleTemplates = {
  driver: RoleTemplate;
  administrator: RoleTemplate;
  developer: RoleTemplate;
};

const welcomeMessageSchema = z.object({
  message: z.string().min(1, "Welcome message is required"),
});

const alertBannerSchema = z.object({
  enabled: z.boolean(),
  message: z.string().min(1, "Alert message is required when enabled"),
});

const maintenanceModeSchema = z.object({
  enabled: z.boolean(),
});

const companyNameSchema = z.object({
  name: z.string().min(1, "Company name is required"),
});

const systemConfigSchema = z.object({
  sessionTimeout: z.number().min(15).max(10080).default(1440), // 15 minutes to 7 days in minutes
  maxLoginAttempts: z.number().min(3).max(50).default(5),
  accountLockoutDuration: z.number().min(5).max(1440).default(30), // 5 minutes to 24 hours in minutes
  passwordMinLength: z.number().min(6).max(128).default(6),
  requirePasswordComplexity: z.boolean().default(false),
  enableAuditLogging: z.boolean().default(true),
  logRetentionDays: z.number().min(1).max(365).default(14),
  emailNotifications: z.boolean().default(false),
  smtpServer: z.string().optional(),
  smtpPort: z.number().min(1).max(65535).default(587).optional(),
  smtpUsername: z.string().optional(),
  smtpPassword: z.string().optional(),
  smtpEncryption: z.enum(["none", "tls", "ssl"]).default("tls"),
  backupRetentionDays: z.number().min(1).max(365).default(30),
  enableRateLimiting: z.boolean().default(true),
  apiRateLimit: z.number().min(10).max(10000).default(100), // requests per minute
  enableMaintenanceWindow: z.boolean().default(false),
  maintenanceStartTime: z.string().default("02:00"),
  maintenanceEndTime: z.string().default("04:00"),
});

const createUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  role: z.enum(["driver", "administrator", "developer"]),
});

const roleTemplateSchema = z.object({
  name: z.string().min(1, "Role name is required"),
  description: z.string().min(1, "Description is required"),
  permissions: z.object({
    systemSettings: z.object({
      canAccessSystemSettings: z.boolean(),
      canEditWelcomeMessage: z.boolean(),
      canEditAlertBanner: z.boolean(),
    }),
    userManagement: z.object({
      canViewUsers: z.boolean(),
      canCreateUsers: z.boolean(),
      canEditUsers: z.boolean(),
      canDeleteUsers: z.boolean(),
    }),
    transactions: z.object({
      canViewAllTransactions: z.boolean(),
      canEditTransactions: z.boolean(),
      canDeleteTransactions: z.boolean(),
    }),
    vehicles: z.object({
      canViewVehicles: z.boolean(),
      canCreateVehicles: z.boolean(),
      canEditVehicles: z.boolean(),
      canDeleteVehicles: z.boolean(),
    }),
    tanks: z.object({
      canViewTankLevels: z.boolean(),
      canEditTankLevels: z.boolean(),
      canCreateTanks: z.boolean(),
      canDeleteTanks: z.boolean(),
    }),
  }),
});

type WelcomeMessageFormData = z.infer<typeof welcomeMessageSchema>;
type AlertBannerFormData = z.infer<typeof alertBannerSchema>;
type MaintenanceModeFormData = z.infer<typeof maintenanceModeSchema>;
type CompanyNameFormData = z.infer<typeof companyNameSchema>;
type CreateUserFormData = z.infer<typeof createUserSchema>;
type RoleTemplateFormData = z.infer<typeof roleTemplateSchema>;

export default function AdminSystemSettings() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isWelcomeDialogOpen, setIsWelcomeDialogOpen] = useState(false);
  const [isAlertDialogOpen, setIsAlertDialogOpen] = useState(false);
  const [isCompanyNameDialogOpen, setIsCompanyNameDialogOpen] = useState(false);
  const [isUserGroupDialogOpen, setIsUserGroupDialogOpen] = useState(false);
  const [isCreateUserDialogOpen, setIsCreateUserDialogOpen] = useState(false);
  const [isEditRoleDialogOpen, setIsEditRoleDialogOpen] = useState(false);
  const [isCreateRoleDialogOpen, setIsCreateRoleDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [editingRoleKey, setEditingRoleKey] = useState<string>("");
  const [editingRoleData, setEditingRoleData] = useState<any>(null);
  const [isSystemConfigDialogOpen, setIsSystemConfigDialogOpen] = useState(false);

  // Parse user permissions
  const userPermissions = user?.permissions ? (() => {
    try {
      return JSON.parse(user.permissions);
    } catch (e) {
      return {};
    }
  })() : {};

  const canEditWelcomeMessage = user?.role === "developer" || userPermissions.systemSettings?.canEditWelcomeMessage;
  const canEditAlertBanner = user?.role === "developer" || userPermissions.systemSettings?.canEditAlertBanner;
  const canEditMaintenanceMode = user?.role === "developer";

  const { data: settings, isLoading } = useQuery<SystemSetting[]>({
    queryKey: ["/api/system-settings"],
  });

  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: user?.role === "developer",
  });

  const { data: roleTemplates, isLoading: roleTemplatesLoading } = useQuery<RoleTemplates>({
    queryKey: ["/api/role-templates"],
    enabled: user?.role === "developer",
  });

  const updateSettingMutation = useMutation({
    mutationFn: async ({ key, value, description }: { key: string; value: string; description?: string }) => {
      const res = await apiRequest("PUT", "/api/system-settings", { key, value, description });
      return await res.json();
    },
    onSuccess: (_, variables) => {
      // Invalidate both private and public system settings cache
      queryClient.invalidateQueries({ queryKey: ["/api/system-settings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/system-settings/public"] });
      
      // Force page reload for company name changes to ensure all components update
      if (variables.key === "company_name") {
        toast({
          title: "Company name updated",
          description: "Reloading page to apply changes...",
        });
        // Force a page reload to ensure all components get the new company name
        setTimeout(() => {
          window.location.reload();
        }, 1000);
        return;
      }
      
      toast({
        title: "Setting updated",
        description: "System setting has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating setting",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createUserMutation = useMutation({
    mutationFn: async (userData: CreateUserFormData) => {
      const res = await apiRequest("POST", "/api/users/create-with-role", userData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsCreateUserDialogOpen(false);
      createUserForm.reset();
      toast({
        title: "User created",
        description: "New user has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateUserRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      const res = await apiRequest("PUT", `/api/users/${userId}/apply-role`, { role });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "User role updated",
        description: "User role has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating user role",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("DELETE", `/api/users/${userId}`);
      return res;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "User deleted",
        description: "User has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateRoleTemplateMutation = useMutation({
    mutationFn: async ({ roleKey, roleData }: { roleKey: string; roleData: RoleTemplateFormData }) => {
      const res = await apiRequest("PUT", `/api/role-templates/${roleKey}`, roleData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/role-templates"] });
      setIsEditRoleDialogOpen(false);
      toast({
        title: "Role template updated",
        description: "Role template has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating role template",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createRoleTemplateMutation = useMutation({
    mutationFn: async (roleData: RoleTemplateFormData) => {
      const res = await apiRequest("POST", "/api/role-templates", roleData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/role-templates"] });
      setIsCreateRoleDialogOpen(false);
      createRoleForm.reset();
      toast({
        title: "Role template created",
        description: "New role template has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating role template",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const welcomeForm = useForm<WelcomeMessageFormData>({
    resolver: zodResolver(welcomeMessageSchema),
    defaultValues: {
      message: "",
    },
  });

  const alertForm = useForm<AlertBannerFormData>({
    resolver: zodResolver(alertBannerSchema),
    defaultValues: {
      enabled: false,
      message: "",
    },
  });

  const companyNameForm = useForm<CompanyNameFormData>({
    resolver: zodResolver(companyNameSchema),
    defaultValues: {
      name: "",
    },
  });

  const createUserForm = useForm<CreateUserFormData>({
    resolver: zodResolver(createUserSchema),
    defaultValues: {
      username: "",
      password: "",
      name: "",
      email: "",
      role: "driver",
    },
  });

  const editRoleForm = useForm<RoleTemplateFormData>({
    resolver: zodResolver(roleTemplateSchema),
    defaultValues: {
      name: "",
      description: "",
      permissions: {
        systemSettings: {
          canAccessSystemSettings: false,
          canEditWelcomeMessage: false,
          canEditAlertBanner: false,
        },
        userManagement: {
          canViewUsers: false,
          canCreateUsers: false,
          canEditUsers: false,
          canDeleteUsers: false,
        },
        transactions: {
          canViewAllTransactions: false,
          canEditTransactions: false,
          canDeleteTransactions: false,
        },
        vehicles: {
          canViewVehicles: false,
          canCreateVehicles: false,
          canEditVehicles: false,
          canDeleteVehicles: false,
        },
        tanks: {
          canViewTankLevels: false,
          canEditTankLevels: false,
          canCreateTanks: false,
          canDeleteTanks: false,
        },
      },
    },
  });

  const createRoleForm = useForm<RoleTemplateFormData>({
    resolver: zodResolver(roleTemplateSchema),
    defaultValues: {
      name: "",
      description: "",
      permissions: {
        systemSettings: {
          canAccessSystemSettings: false,
          canEditWelcomeMessage: false,
          canEditAlertBanner: false,
        },
        userManagement: {
          canViewUsers: false,
          canCreateUsers: false,
          canEditUsers: false,
          canDeleteUsers: false,
        },
        transactions: {
          canViewAllTransactions: false,
          canEditTransactions: false,
          canDeleteTransactions: false,
        },
        vehicles: {
          canViewVehicles: false,
          canCreateVehicles: false,
          canEditVehicles: false,
          canDeleteVehicles: false,
        },
        tanks: {
          canViewTankLevels: false,
          canEditTankLevels: false,
          canCreateTanks: false,
          canDeleteTanks: false,
        },
      },
    },
  });

  const systemConfigForm = useForm<z.infer<typeof systemConfigSchema>>({
    resolver: zodResolver(systemConfigSchema),
    defaultValues: {
      sessionTimeout: 1440,
      maxLoginAttempts: 5,
      accountLockoutDuration: 30,
      passwordMinLength: 6,
      requirePasswordComplexity: false,
      enableAuditLogging: true,
      logRetentionDays: 14,
      emailNotifications: false,
      smtpPort: 587,
      smtpEncryption: "tls",
      backupRetentionDays: 30,
      enableRateLimiting: true,
      apiRateLimit: 100,
      enableMaintenanceWindow: false,
      maintenanceStartTime: "02:00",
      maintenanceEndTime: "04:00",
    },
  });

  // Get current settings values
  const welcomeMessage = settings?.find(s => s.key === "welcome_message")?.value || "Welcome to Lee Transport Systems Fleet Management Portal";
  const alertBannerEnabled = settings?.find(s => s.key === "alert_banner_enabled")?.value === "true";
  const alertBannerMessage = settings?.find(s => s.key === "alert_banner_message")?.value || "";
  const companyName = settings?.find(s => s.key === "company_name")?.value || "Lee Transport Systems";
  const maintenanceModeEnabled = settings?.find(s => s.key === "maintenance_mode_enabled")?.value === "true";

  const onWelcomeSubmit = (data: WelcomeMessageFormData) => {
    updateSettingMutation.mutate({
      key: "welcome_message",
      value: data.message,
      description: "Welcome message displayed on login screen"
    });
    setIsWelcomeDialogOpen(false);
  };

  const onAlertSubmit = (data: AlertBannerFormData) => {
    // Update both enabled flag and message
    updateSettingMutation.mutate({
      key: "alert_banner_enabled",
      value: data.enabled.toString(),
      description: "Whether alert banner is enabled on dashboard"
    });
    
    if (data.enabled) {
      updateSettingMutation.mutate({
        key: "alert_banner_message",
        value: data.message,
        description: "Alert banner message displayed on dashboard"
      });
    }
    
    setIsAlertDialogOpen(false);
  };

  const onCompanyNameSubmit = (data: CompanyNameFormData) => {
    updateSettingMutation.mutate({
      key: "company_name",
      value: data.name,
      description: "Company name displayed throughout the application"
    });
    setIsCompanyNameDialogOpen(false);
  };

  const onSystemConfigSubmit = (data: z.infer<typeof systemConfigSchema>) => {
    // Update multiple system configuration settings
    const systemConfigKeys = [
      'session_timeout', 'max_login_attempts', 'account_lockout_duration', 
      'password_min_length', 'require_password_complexity', 'enable_audit_logging',
      'log_retention_days', 'email_notifications', 'smtp_server', 'smtp_port',
      'smtp_username', 'smtp_password', 'smtp_encryption', 'backup_retention_days',
      'enable_rate_limiting', 'api_rate_limit', 'enable_maintenance_window',
      'maintenance_start_time', 'maintenance_end_time'
    ];
    
    const updates = Object.entries(data).map(([key, value]) => ({
      key: key.replace(/([A-Z])/g, '_$1').toLowerCase(),
      value: String(value),
      description: `System configuration setting: ${key}`
    }));
    
    // Submit all updates
    Promise.all(updates.map(update => 
      updateSettingMutation.mutateAsync(update)
    )).then(() => {
      toast({
        title: "System configuration updated",
        description: "All system configuration settings have been updated successfully.",
      });
      setIsSystemConfigDialogOpen(false);
    }).catch((error) => {
      toast({
        title: "Error updating system configuration",
        description: error.message,
        variant: "destructive",
      });
    });
  };

  const handleMaintenanceModeToggle = (enabled: boolean) => {
    updateSettingMutation.mutate({
      key: "maintenance_mode_enabled",
      value: enabled.toString(),
      description: "Whether the system is in maintenance mode - only developers can login"
    });
  };

  const handleWelcomeClick = () => {
    welcomeForm.setValue("message", welcomeMessage);
    setIsWelcomeDialogOpen(true);
  };

  const handleAlertClick = () => {
    alertForm.setValue("enabled", alertBannerEnabled);
    alertForm.setValue("message", alertBannerMessage);
    setIsAlertDialogOpen(true);
  };

  const handleCompanyNameClick = () => {
    companyNameForm.setValue("name", companyName);
    setIsCompanyNameDialogOpen(true);
  };

  const handleUserGroupClick = () => {
    setIsUserGroupDialogOpen(true);
  };

  const handleCreateUserClick = () => {
    createUserForm.reset();
    setIsCreateUserDialogOpen(true);
  };

  const onCreateUserSubmit = (data: CreateUserFormData) => {
    createUserMutation.mutate(data);
  };

  const handleRoleChange = (userId: string, newRole: string) => {
    updateUserRoleMutation.mutate({ userId, role: newRole });
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
      deleteUserMutation.mutate(userId);
    }
  };

  const handleEditRole = (roleKey: string, roleData: RoleTemplate) => {
    setEditingRoleKey(roleKey);
    setEditingRoleData(roleData);
    editRoleForm.setValue("name", roleData.name);
    editRoleForm.setValue("description", roleData.description);
    editRoleForm.setValue("permissions", roleData.permissions);
    setIsEditRoleDialogOpen(true);
  };

  const handleCreateRole = () => {
    createRoleForm.reset();
    setIsCreateRoleDialogOpen(true);
  };

  const onEditRoleSubmit = (data: RoleTemplateFormData) => {
    updateRoleTemplateMutation.mutate({ roleKey: editingRoleKey, roleData: data });
  };

  const onCreateRoleSubmit = (data: RoleTemplateFormData) => {
    createRoleTemplateMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <Settings className="h-5 w-5" />
        <h3 className="text-lg font-semibold">System Settings</h3>
      </div>

      <div className="grid gap-4">
        {/* Configurable Options Menu */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Sliders className="h-5 w-5" />
              <span>Configurable Options</span>
            </CardTitle>
            <CardDescription>
              Access and configure various system options and settings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="w-full justify-between">
                  Select Option to Configure
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-full min-w-[300px]">
                <DropdownMenuItem 
                  onClick={handleCompanyNameClick}
                  disabled={!canEditWelcomeMessage}
                  className="flex items-center space-x-2 cursor-pointer"
                >
                  <Building className="h-4 w-4" />
                  <span>Company Name</span>
                  {!canEditWelcomeMessage && (
                    <span className="text-xs text-muted-foreground ml-auto">No permission</span>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleWelcomeClick}
                  disabled={!canEditWelcomeMessage}
                  className="flex items-center space-x-2 cursor-pointer"
                >
                  <MessageSquare className="h-4 w-4" />
                  <span>Welcome Message</span>
                  {!canEditWelcomeMessage && (
                    <span className="text-xs text-muted-foreground ml-auto">No permission</span>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleAlertClick}
                  disabled={!canEditAlertBanner}
                  className="flex items-center space-x-2 cursor-pointer"
                >
                  <AlertTriangle className="h-4 w-4" />
                  <span>Dashboard Alert Banner</span>
                  {!canEditAlertBanner && (
                    <span className="text-xs text-muted-foreground ml-auto">No permission</span>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleUserGroupClick}
                  disabled={user?.role !== "developer"}
                  className="flex items-center space-x-2 cursor-pointer"
                >
                  <Users className="h-4 w-4" />
                  <span>User Group Settings</span>
                  {user?.role !== "developer" && (
                    <span className="text-xs text-muted-foreground ml-auto">Developer only</span>
                  )}
                </DropdownMenuItem>
                {canEditMaintenanceMode && (
                  <DropdownMenuItem 
                    onClick={() => handleMaintenanceModeToggle(!maintenanceModeEnabled)}
                    className="flex items-center space-x-2 cursor-pointer"
                  >
                    <Shield className="h-4 w-4" />
                    <span>Maintenance Mode</span>
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Current Status Display */}
            <div className="mt-6 space-y-4 pt-4 border-t">
              <h4 className="text-sm font-medium text-gray-700">Current Configuration Status</h4>
              
              {/* Company Name Status */}
              <div className="flex items-start justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <Building className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium">Company Name</span>
                  </div>
                  <p className="text-xs text-gray-600 line-clamp-2">
                    {companyName}
                  </p>
                </div>
                {canEditWelcomeMessage && (
                  <Button onClick={handleCompanyNameClick} size="sm" variant="ghost">
                    Edit
                  </Button>
                )}
              </div>

              {/* Welcome Message Status */}
              <div className="flex items-start justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <MessageSquare className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium">Welcome Message</span>
                  </div>
                  <p className="text-xs text-gray-600 line-clamp-2">
                    {welcomeMessage}
                  </p>
                </div>
                {canEditWelcomeMessage && (
                  <Button onClick={handleWelcomeClick} size="sm" variant="ghost">
                    Edit
                  </Button>
                )}
              </div>

              {/* Alert Banner Status */}
              <div className="flex items-start justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <AlertTriangle className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium">Dashboard Alert Banner</span>
                  </div>
                  <p className="text-xs text-gray-600">
                    Status: <span className={`font-medium ${alertBannerEnabled ? 'text-red-600' : 'text-gray-500'}`}>
                      {alertBannerEnabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </p>
                  {alertBannerEnabled && alertBannerMessage && (
                    <div className="mt-2 bg-red-50 border border-red-200 p-2 rounded text-xs">
                      <p className="text-red-800 font-medium line-clamp-2">{alertBannerMessage}</p>
                    </div>
                  )}
                </div>
                {canEditAlertBanner && (
                  <Button onClick={handleAlertClick} size="sm" variant="ghost">
                    Edit
                  </Button>
                )}
              </div>

              {/* Maintenance Mode Status */}
              {canEditMaintenanceMode && (
                <div className="flex items-start justify-between p-3 bg-gray-50 rounded-md">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <Shield className="h-4 w-4 text-gray-600" />
                      <span className="text-sm font-medium">Maintenance Mode</span>
                    </div>
                    <p className="text-xs text-gray-600">
                      Status: <span className={`font-medium ${maintenanceModeEnabled ? 'text-red-600' : 'text-green-600'}`}>
                        {maintenanceModeEnabled ? 'ENABLED - Only developers can login' : 'Disabled'}
                      </span>
                    </p>
                    {maintenanceModeEnabled && (
                      <div className="mt-2 bg-red-50 border border-red-200 p-2 rounded text-xs">
                        <p className="text-red-800 font-medium">System is in maintenance mode. Regular users cannot login.</p>
                      </div>
                    )}
                  </div>
                  <Switch
                    checked={maintenanceModeEnabled}
                    onCheckedChange={handleMaintenanceModeToggle}
                    className="ml-4"
                  />
                </div>
              )}

              {/* Advanced System Configuration - Developer Only */}
              {user?.role === "developer" && (
                <div className="flex items-start justify-between p-3 bg-blue-50 border border-blue-200 rounded-md">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <Server className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-800">Advanced System Configuration</span>
                    </div>
                    <p className="text-xs text-blue-600 mb-2">
                      Configure security, email, backups, and system behavior settings
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="flex items-center space-x-1">
                        <Key className="h-3 w-3 text-blue-500" />
                        <span>Session & Security</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Mail className="h-3 w-3 text-blue-500" />
                        <span>Email & Notifications</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Database className="h-3 w-3 text-blue-500" />
                        <span>Database & Backups</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3 text-blue-500" />
                        <span>Maintenance Windows</span>
                      </div>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setIsSystemConfigDialogOpen(true)} 
                    size="sm" 
                    variant="outline"
                    className="border-blue-300 text-blue-700 hover:bg-blue-100"
                  >
                    Configure
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Welcome Message Dialog */}
      <Dialog open={isWelcomeDialogOpen} onOpenChange={setIsWelcomeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Welcome Message</DialogTitle>
            <DialogDescription>
              Update the welcome message displayed on the login screen.
            </DialogDescription>
          </DialogHeader>
          <Form {...welcomeForm}>
            <form onSubmit={welcomeForm.handleSubmit(onWelcomeSubmit)} className="space-y-4">
              <FormField
                control={welcomeForm.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Welcome Message</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter welcome message..." 
                        rows={4}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsWelcomeDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateSettingMutation.isPending}
                >
                  {updateSettingMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Message"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Alert Banner Dialog */}
      <Dialog open={isAlertDialogOpen} onOpenChange={setIsAlertDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Configure Dashboard Alert Banner</DialogTitle>
            <DialogDescription>
              Set up an urgent alert banner to display to all users on the dashboard.
            </DialogDescription>
          </DialogHeader>
          <Form {...alertForm}>
            <form onSubmit={alertForm.handleSubmit(onAlertSubmit)} className="space-y-4">
              <FormField
                control={alertForm.control}
                name="enabled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Enable Alert Banner</FormLabel>
                      <div className="text-sm text-muted-foreground">
                        Show urgent alert banner on dashboard
                      </div>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={alertForm.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Alert Message</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter urgent alert message..." 
                        rows={3}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAlertDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateSettingMutation.isPending}
                >
                  {updateSettingMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Save Settings"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Company Name Dialog */}
      <Dialog open={isCompanyNameDialogOpen} onOpenChange={setIsCompanyNameDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Company Name</DialogTitle>
            <DialogDescription>
              Update the company name displayed throughout the application.
            </DialogDescription>
          </DialogHeader>
          <Form {...companyNameForm}>
            <form onSubmit={companyNameForm.handleSubmit(onCompanyNameSubmit)} className="space-y-4">
              <FormField
                control={companyNameForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter company name..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCompanyNameDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateSettingMutation.isPending}
                >
                  {updateSettingMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Name"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* User Group Settings Dialog */}
      <Dialog open={isUserGroupDialogOpen} onOpenChange={setIsUserGroupDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>User Group Settings</span>
            </DialogTitle>
            <DialogDescription>
              Manage user roles, permissions, and group settings. Create, edit, and assign access permissions to users.
            </DialogDescription>
          </DialogHeader>

          {usersLoading || roleTemplatesLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <div className="space-y-6">
              {/* Role Templates Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-semibold">Role Templates</h4>
                  <div className="flex space-x-2">
                    <Button onClick={handleCreateRole} variant="outline" className="flex items-center space-x-2">
                      <Plus className="h-4 w-4" />
                      <span>Add Role</span>
                    </Button>
                    <Button onClick={handleCreateUserClick} className="flex items-center space-x-2">
                      <Plus className="h-4 w-4" />
                      <span>Create User</span>
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {roleTemplates && Object.entries(roleTemplates).map(([roleKey, roleData]) => (
                    <Card key={roleKey} className="border">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-base flex items-center space-x-2">
                            <Shield className="h-4 w-4" />
                            <span>{roleData.name}</span>
                          </CardTitle>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleEditRole(roleKey, roleData)}
                            className="h-8 w-8 p-0"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                        <CardDescription className="text-sm">
                          {roleData.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-xs text-gray-600 space-y-1">
                          <p><strong>Users with this role:</strong> {users?.filter(u => u.role === roleKey).length || 0}</p>
                          <div className="text-xs text-gray-500">
                            <p><strong>Permissions:</strong></p>
                            <ul className="ml-2 space-y-0.5">
                              {roleData.permissions?.systemSettings && (
                                <li>• System Settings: {Object.values(roleData.permissions.systemSettings).some(Boolean) ? "Yes" : "No"}</li>
                              )}
                              {roleData.permissions?.userManagement && (
                                <li>• User Management: {Object.values(roleData.permissions.userManagement).some(Boolean) ? "Yes" : "No"}</li>
                              )}
                              {roleData.permissions?.transactions && (
                                <li>• Transactions: {Object.values(roleData.permissions.transactions).some(Boolean) ? "Yes" : "No"}</li>
                              )}
                              {roleData.permissions?.vehicles && (
                                <li>• Vehicles: {Object.values(roleData.permissions.vehicles).some(Boolean) ? "Yes" : "No"}</li>
                              )}
                              {roleData.permissions?.tanks && (
                                <li>• Tanks: {Object.values(roleData.permissions.tanks).some(Boolean) ? "Yes" : "No"}</li>
                              )}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Users Management Section */}
              <div className="space-y-4">
                <h4 className="text-lg font-semibold">User Management</h4>
                
                <div className="border rounded-lg">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="text-left p-3 font-medium text-sm">User</th>
                          <th className="text-left p-3 font-medium text-sm">Role</th>
                          <th className="text-left p-3 font-medium text-sm">Status</th>
                          <th className="text-left p-3 font-medium text-sm">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {users?.map((userData) => (
                          <tr key={userData.id} className="border-b hover:bg-gray-50">
                            <td className="p-3">
                              <div>
                                <p className="font-medium text-sm">{userData.name}</p>
                                <p className="text-xs text-gray-500">{userData.username} • {userData.email}</p>
                              </div>
                            </td>
                            <td className="p-3">
                              <select
                                value={userData.role}
                                onChange={(e) => handleRoleChange(userData.id, e.target.value)}
                                className="text-sm border rounded px-2 py-1"
                                disabled={userData.role === "developer" && user?.id !== userData.id}
                              >
                                <option value="driver">Driver</option>
                                <option value="administrator">Administrator</option>
                                <option value="developer">Developer</option>
                              </select>
                            </td>
                            <td className="p-3">
                              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                userData.status === "active" 
                                  ? "bg-green-100 text-green-800" 
                                  : "bg-red-100 text-red-800"
                              }`}>
                                {userData.status}
                              </span>
                            </td>
                            <td className="p-3">
                              <div className="flex items-center space-x-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setSelectedUser(userData)}
                                  className="h-8 w-8 p-0"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                {userData.role !== "developer" && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => handleDeleteUser(userData.id)}
                                    className="h-8 w-8 p-0 text-red-600 hover:text-red-800"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create User Dialog */}
      <Dialog open={isCreateUserDialogOpen} onOpenChange={setIsCreateUserDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
            <DialogDescription>
              Create a new user account with assigned role and permissions.
            </DialogDescription>
          </DialogHeader>
          <Form {...createUserForm}>
            <form onSubmit={createUserForm.handleSubmit(onCreateUserSubmit)} className="space-y-4">
              <FormField
                control={createUserForm.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter username..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={createUserForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="Enter password..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={createUserForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter full name..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={createUserForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="Enter email..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={createUserForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <FormControl>
                      <select {...field} className="w-full border rounded px-3 py-2">
                        <option value="driver">Driver</option>
                        <option value="administrator">Administrator</option>
                        <option value="developer">Developer</option>
                      </select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateUserDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createUserMutation.isPending}
                >
                  {createUserMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create User"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Role Dialog */}
      <Dialog open={isEditRoleDialogOpen} onOpenChange={setIsEditRoleDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Role Template: {editingRoleData?.name}</DialogTitle>
            <DialogDescription>
              Modify the role permissions and settings. Changes will apply to all users with this role.
            </DialogDescription>
          </DialogHeader>
          <Form {...editRoleForm}>
            <form onSubmit={editRoleForm.handleSubmit(onEditRoleSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={editRoleForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter role name..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editRoleForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter role description..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Permission Categories */}
              <div className="space-y-6">
                <h4 className="text-lg font-semibold">Permissions</h4>
                
                {/* System Settings Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Settings className="h-4 w-4" />
                    <span>System Settings</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.systemSettings.canAccessSystemSettings"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Access System Settings</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.systemSettings.canEditWelcomeMessage"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Welcome Message</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.systemSettings.canEditAlertBanner"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Alert Banner</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* User Management Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Users className="h-4 w-4" />
                    <span>User Management</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.userManagement.canViewUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View Users</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.userManagement.canCreateUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Create Users</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.userManagement.canEditUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Users</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.userManagement.canDeleteUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Users</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Transaction Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <ClipboardList className="h-4 w-4" />
                    <span>Transactions</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.transactions.canViewAllTransactions"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View All Transactions</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.transactions.canEditTransactions"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Transactions</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.transactions.canDeleteTransactions"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Transactions</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Vehicle Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Truck className="h-4 w-4" />
                    <span>Vehicles</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.vehicles.canViewVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.vehicles.canCreateVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Create Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.vehicles.canEditVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.vehicles.canDeleteVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Tank Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Fuel className="h-4 w-4" />
                    <span>Tank Management</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.tanks.canViewTankLevels"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View Tank Levels</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.tanks.canEditTankLevels"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Tank Levels</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.tanks.canCreateTanks"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Create Tanks</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={editRoleForm.control}
                      name="permissions.tanks.canDeleteTanks"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Tanks</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditRoleDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateRoleTemplateMutation.isPending}
                >
                  {updateRoleTemplateMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Role"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Create Role Dialog */}
      <Dialog open={isCreateRoleDialogOpen} onOpenChange={setIsCreateRoleDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Role Template</DialogTitle>
            <DialogDescription>
              Create a new role with custom permissions. Define what users with this role can access and modify.
            </DialogDescription>
          </DialogHeader>
          <Form {...createRoleForm}>
            <form onSubmit={createRoleForm.handleSubmit(onCreateRoleSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={createRoleForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter role name..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createRoleForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter role description..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Permission Categories - Same structure as Edit Role */}
              <div className="space-y-6">
                <h4 className="text-lg font-semibold">Permissions</h4>
                
                {/* System Settings Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Settings className="h-4 w-4" />
                    <span>System Settings</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.systemSettings.canAccessSystemSettings"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Access System Settings</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.systemSettings.canEditWelcomeMessage"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Welcome Message</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.systemSettings.canEditAlertBanner"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Alert Banner</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* User Management Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Users className="h-4 w-4" />
                    <span>User Management</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.userManagement.canViewUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View Users</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.userManagement.canCreateUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Create Users</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.userManagement.canEditUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Users</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.userManagement.canDeleteUsers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Users</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Transaction Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <ClipboardList className="h-4 w-4" />
                    <span>Transactions</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.transactions.canViewAllTransactions"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View All Transactions</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.transactions.canEditTransactions"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Transactions</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.transactions.canDeleteTransactions"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Transactions</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Vehicle Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Truck className="h-4 w-4" />
                    <span>Vehicles</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.vehicles.canViewVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.vehicles.canCreateVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Create Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.vehicles.canEditVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.vehicles.canDeleteVehicles"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Vehicles</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Tank Permissions */}
                <div className="border rounded-lg p-4">
                  <h5 className="font-medium mb-3 flex items-center space-x-2">
                    <Fuel className="h-4 w-4" />
                    <span>Tank Management</span>
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.tanks.canViewTankLevels"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">View Tank Levels</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.tanks.canEditTankLevels"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Edit Tank Levels</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.tanks.canCreateTanks"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Create Tanks</FormLabel>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createRoleForm.control}
                      name="permissions.tanks.canDeleteTanks"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                          <FormControl>
                            <input type="checkbox" checked={field.value} onChange={field.onChange} />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">Delete Tanks</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateRoleDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createRoleTemplateMutation.isPending}
                >
                  {createRoleTemplateMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create Role"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>


      {/* Advanced System Configuration Dialog - Developer Only */}
      {user?.role === "developer" && (
        <Dialog open={isSystemConfigDialogOpen} onOpenChange={setIsSystemConfigDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Server className="h-5 w-5 text-blue-600" />
                <span>Advanced System Configuration</span>
              </DialogTitle>
              <DialogDescription>
                Configure advanced system settings including security, email notifications, backups, and maintenance windows.
                These settings affect system-wide behavior and should be modified with caution.
              </DialogDescription>
            </DialogHeader>
            <Form {...systemConfigForm}>
              <form onSubmit={systemConfigForm.handleSubmit(onSystemConfigSubmit)} className="space-y-6">
                
                {/* Security & Authentication Section */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b pb-2">
                    <Key className="h-4 w-4 text-blue-600" />
                    <h4 className="text-lg font-medium">Security & Authentication</h4>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={systemConfigForm.control}
                      name="sessionTimeout"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Session Timeout (minutes)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={systemConfigForm.control}
                      name="maxLoginAttempts"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Max Login Attempts</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={systemConfigForm.control}
                      name="accountLockoutDuration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Lockout Duration (minutes)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={systemConfigForm.control}
                      name="passwordMinLength"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Minimum Password Length</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={systemConfigForm.control}
                      name="requirePasswordComplexity"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Require Password Complexity</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Require uppercase, lowercase, numbers, and symbols
                            </div>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={systemConfigForm.control}
                      name="enableRateLimiting"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Enable API Rate Limiting</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Limit API requests per minute per user
                            </div>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {systemConfigForm.watch("enableRateLimiting") && (
                    <FormField
                      control={systemConfigForm.control}
                      name="apiRateLimit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>API Rate Limit (requests per minute)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </div>
                
                {/* Email & Notifications Section */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b pb-2">
                    <Mail className="h-4 w-4 text-blue-600" />
                    <h4 className="text-lg font-medium">Email & Notifications</h4>
                  </div>
                  
                  <FormField
                    control={systemConfigForm.control}
                    name="emailNotifications"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Enable Email Notifications</FormLabel>
                          <div className="text-sm text-muted-foreground">
                            Send system notifications via email
                          </div>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  {systemConfigForm.watch("emailNotifications") && (
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={systemConfigForm.control}
                        name="smtpServer"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Server</FormLabel>
                            <FormControl>
                              <Input placeholder="smtp.gmail.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={systemConfigForm.control}
                        name="smtpPort"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Port</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value) || 587)} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={systemConfigForm.control}
                        name="smtpUsername"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Username</FormLabel>
                            <FormControl>
                              <Input placeholder="your-email@gmail.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={systemConfigForm.control}
                        name="smtpPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="App password or SMTP password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}
                </div>
                
                {/* System Logs & Auditing Section */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b pb-2">
                    <ClipboardList className="h-4 w-4 text-blue-600" />
                    <h4 className="text-lg font-medium">System Logs & Auditing</h4>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={systemConfigForm.control}
                      name="enableAuditLogging"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Enable Audit Logging</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Log all user actions and system events
                            </div>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={systemConfigForm.control}
                      name="logRetentionDays"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Log Retention (days)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                {/* Backup & Maintenance Section */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 border-b pb-2">
                    <Database className="h-4 w-4 text-blue-600" />
                    <h4 className="text-lg font-medium">Backup & Maintenance</h4>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={systemConfigForm.control}
                      name="backupRetentionDays"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Backup Retention (days)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={systemConfigForm.control}
                      name="enableMaintenanceWindow"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Maintenance Window</FormLabel>
                            <div className="text-sm text-muted-foreground">
                              Schedule daily maintenance window
                            </div>
                          </div>
                          <FormControl>
                            <Switch checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {systemConfigForm.watch("enableMaintenanceWindow") && (
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={systemConfigForm.control}
                        name="maintenanceStartTime"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Maintenance Start Time</FormLabel>
                            <FormControl>
                              <Input type="time" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={systemConfigForm.control}
                        name="maintenanceEndTime"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Maintenance End Time</FormLabel>
                            <FormControl>
                              <Input type="time" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}
                </div>
                
                <div className="flex justify-end space-x-2 pt-4 border-t">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsSystemConfigDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={updateSettingMutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {updateSettingMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Updating...
                      </>
                    ) : (
                      "Save Configuration"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      )}

    </div>
  );
}