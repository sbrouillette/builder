import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Fuel, Droplets, ChevronRight, AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { TankWidgetCard } from "@/components/tank-widget";
import { DashboardCustomizer } from "@/components/dashboard-customizer";
import { useAuth } from "@/hooks/use-auth";
import type { Transaction, DashboardWidgets, TankWidget } from "@shared/schema";

interface Stats {
  fuelTransactions: number;
  defTransactions: number;
}

interface TankLevel {
  id: string;
  name: string;
  type: string;
  location: string;
  currentLevel: string;
  capacity: string;
  unit: string;
  lastUpdated: string;
}

export default function Dashboard() {
  const { user } = useAuth();
  
  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ["/api/transactions/stats"],
  });

  const { data: recentTransactions, isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    select: (data) => data.slice(0, 3), // Show only recent 3 transactions
  });

  const { data: tanks = [] } = useQuery<TankLevel[]>({
    queryKey: ["/api/tank-levels/driver"],
  });

  // Fetch public system settings for alert banner (all users can see this)
  const { data: systemSettings = [] } = useQuery<Array<{key: string, value: string}>>({
    queryKey: ["/api/system-settings/public"],
  });

  // Check if alert banner should be shown
  const alertBannerEnabled = systemSettings.find((s) => s.key === "alert_banner_enabled")?.value === "true";
  const alertBannerMessage = systemSettings.find((s) => s.key === "alert_banner_message")?.value || "";

  // Parse dashboard widgets from user data
  const dashboardWidgets = useMemo((): DashboardWidgets => {
    if (!user?.dashboardWidgets) {
      return {
        tankWidgets: [],
        showTransactionStats: true,
        showQuickActions: true,
      };
    }
    
    try {
      return JSON.parse(user.dashboardWidgets);
    } catch (e) {
      console.error("Failed to parse dashboard widgets:", e);
      return {
        tankWidgets: [],
        showTransactionStats: true,
        showQuickActions: true,
      };
    }
  }, [user?.dashboardWidgets]);

  const handleWidgetUpdate = (newWidget: TankWidget) => {
    // This will be handled by the customizer component
    // The dashboard will automatically re-render when user data updates
  };

  const handleRemoveWidget = (tankId: string) => {
    // This will be handled by the customizer component
  };

  return (
    <div className="mobile-grid relative">
      {/* Alert Banner - Show to all users when enabled */}
      {alertBannerEnabled && alertBannerMessage && (
        <div className="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md flex items-start space-x-3">
          <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-bold text-red-800">{alertBannerMessage}</p>
          </div>
        </div>
      )}

      {/* Dashboard Customizer */}
      <DashboardCustomizer 
        currentWidgets={dashboardWidgets}
        onUpdate={() => {
          // Re-fetch user data to get updated widgets
          // This is handled automatically by React Query
        }}
      />

      {/* Tank Widgets */}
      {dashboardWidgets.tankWidgets.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-gray-800">Tank Insights</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {dashboardWidgets.tankWidgets.map((widget) => {
              const tank = tanks.find(t => t.id === widget.tankId);
              if (!tank) return null;
              
              return (
                <TankWidgetCard
                  key={widget.tankId}
                  tank={tank}
                  widget={widget}
                  onUpdateWidget={handleWidgetUpdate}
                  onRemoveWidget={() => handleRemoveWidget(widget.tankId)}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* Quick Stats */}
      {dashboardWidgets.showTransactionStats && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-gray-800">This Month's Stats</h3>
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <div className="mobile-card text-center">
              <Fuel className="h-8 w-8 sm:h-10 sm:w-10 text-lee-primary mx-auto mb-2" />
              {statsLoading ? (
                <Skeleton className="h-8 w-12 mx-auto mb-2" />
              ) : (
                <div className="text-xl sm:text-2xl font-bold text-gray-800">{stats?.fuelTransactions || 0}</div>
              )}
              <div className="text-sm text-gray-600">Fuel Transactions</div>
            </div>

            <div className="mobile-card text-center">
              <Droplets className="h-8 w-8 sm:h-10 sm:w-10 text-lee-secondary mx-auto mb-2" />
              {statsLoading ? (
                <Skeleton className="h-8 w-12 mx-auto mb-2" />
              ) : (
                <div className="text-xl sm:text-2xl font-bold text-gray-800">{stats?.defTransactions || 0}</div>
              )}
              <div className="text-sm text-gray-600">DEF Transactions</div>
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      {dashboardWidgets.showQuickActions && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-gray-800">Quick Actions</h3>
          
          <Link href="/fuel">
            <div className="mobile-button bg-primary text-white flex items-center justify-between text-left hover:bg-blue-700 active:bg-blue-800 cursor-pointer">
              <div className="flex items-center space-x-3">
                <Fuel className="h-6 w-6" />
                <div>
                  <div className="font-semibold">Log Fuel Transaction</div>
                  <div className="text-blue-100 text-sm">Record fuel purchase details</div>
                </div>
              </div>
              <ChevronRight className="h-5 w-5" />
            </div>
          </Link>
        </div>
      )}

      {/* Recent Transactions */}
      <Card>
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Recent Transactions</h3>
          {transactionsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center space-x-3 p-3">
                  <Skeleton className="h-6 w-6 rounded-full" />
                  <div className="space-y-1 flex-1">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          ) : recentTransactions && recentTransactions.length > 0 ? (
            <div className="space-y-3">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {transaction.type === 'fuel' ? (
                      <Fuel className="h-5 w-5 text-lee-primary" />
                    ) : (
                      <Droplets className="h-5 w-5 text-lee-secondary" />
                    )}
                    <div>
                      <div className="font-medium">{transaction.vehicleId.replace('truck-', 'Truck #')}</div>
                      <div className="text-sm text-gray-600">
                        {transaction.gallons} gal - ${transaction.cost}
                      </div>
                      <div className="text-xs text-gray-500">
                        {transaction.location} - {new Date(transaction.submittedAt!).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-green-600">Submitted</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No transactions yet</p>
              <p className="text-sm">Start by logging your first transaction</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
