import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileArchive, AlertTriangle, CheckCircle, X, RefreshCw, Database, Shield, Play, RotateCcw, Loader2 } from "lucide-react";
import { useLocation } from "wouter";

interface UpdateFile {
  name: string;
  size: number;
  type: string;
}

interface UpdateStatus {
  status: 'idle' | 'uploading' | 'processing' | 'success' | 'error';
  progress: number;
  message: string;
  logs: string[];
}

interface MigrationStatus {
  appliedCount: number;
  pendingCount: number;
  lastMigration?: string;
  canRollback: boolean;
}

export default function SystemUpdate() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<UpdateFile | null>(null);
  const [updateStatus, setUpdateStatus] = useState<UpdateStatus>({
    status: 'idle',
    progress: 0,
    message: '',
    logs: []
  });
  const [migrationStatus, setMigrationStatus] = useState<MigrationStatus | null>(null);
  const [isBackupLoading, setIsBackupLoading] = useState(false);
  const [isMigrationLoading, setIsMigrationLoading] = useState(false);

  // Redirect if not developer
  if (user?.role !== "developer") {
    setLocation("/admin");
    return null;
  }

  // Load migration status on component mount
  useEffect(() => {
    fetchMigrationStatus();
  }, []);

  const fetchMigrationStatus = async () => {
    try {
      const response = await fetch('/api/system-update/migrations/status');
      if (response.ok) {
        const status = await response.json();
        setMigrationStatus(status);
      }
    } catch (error) {
      console.error('Failed to fetch migration status:', error);
    }
  };

  const handleCreateBackup = async () => {
    setIsBackupLoading(true);
    try {
      const response = await fetch('/api/system-update/backup', {
        method: 'POST',
      });
      
      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Backup Created",
          description: result.backupPath ? `Backup saved to: ${result.backupPath}` : "Database backup created successfully",
        });
      } else {
        throw new Error('Failed to create backup');
      }
    } catch (error) {
      toast({
        title: "Backup Failed",
        description: error instanceof Error ? error.message : "Failed to create database backup",
        variant: "destructive"
      });
    } finally {
      setIsBackupLoading(false);
    }
  };

  const handleApplyMigrations = async () => {
    setIsMigrationLoading(true);
    try {
      const response = await fetch('/api/system-update/migrations/apply', {
        method: 'POST',
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          toast({
            title: "Migrations Applied",
            description: `Successfully applied ${result.appliedMigrations.length} migrations`,
          });
          fetchMigrationStatus(); // Refresh status
        } else {
          throw new Error(result.errors.join(', '));
        }
      } else {
        throw new Error('Failed to apply migrations');
      }
    } catch (error) {
      toast({
        title: "Migration Failed",
        description: error instanceof Error ? error.message : "Failed to apply migrations",
        variant: "destructive"
      });
    } finally {
      setIsMigrationLoading(false);
    }
  };

  const handleRollbackMigration = async () => {
    setIsMigrationLoading(true);
    try {
      const response = await fetch('/api/system-update/migrations/rollback', {
        method: 'POST',
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          toast({
            title: "Migration Rolled Back",
            description: "Last migration has been successfully rolled back",
          });
          fetchMigrationStatus(); // Refresh status
        } else {
          throw new Error(result.error || 'Rollback failed');
        }
      } else {
        throw new Error('Failed to rollback migration');
      }
    } catch (error) {
      toast({
        title: "Rollback Failed",
        description: error instanceof Error ? error.message : "Failed to rollback migration",
        variant: "destructive"
      });
    } finally {
      setIsMigrationLoading(false);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type (only allow .zip, .tar.gz, .tgz files)
      const allowedTypes = [
        'application/zip',
        'application/x-zip-compressed',
        'application/gzip',
        'application/x-gzip',
        'application/x-tar',
        'application/x-compressed-tar'
      ];
      
      const allowedExtensions = ['.zip', '.tar.gz', '.tgz'];
      const hasValidExtension = allowedExtensions.some(ext => file.name.toLowerCase().endsWith(ext));
      
      if (!allowedTypes.includes(file.type) && !hasValidExtension) {
        toast({
          title: "Invalid File Type",
          description: "Only ZIP, TAR.GZ, and TGZ files are allowed.",
          variant: "destructive"
        });
        return;
      }

      // Validate file size (max 100MB)
      const maxSize = 100 * 1024 * 1024; // 100MB
      if (file.size > maxSize) {
        toast({
          title: "File Too Large",
          description: "Maximum file size is 100MB.",
          variant: "destructive"
        });
        return;
      }

      setSelectedFile({
        name: file.name,
        size: file.size,
        type: file.type
      });
      setUpdateStatus({
        status: 'idle',
        progress: 0,
        message: '',
        logs: []
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleUpload = async () => {
    if (!selectedFile || !fileInputRef.current?.files?.[0]) return;

    const file = fileInputRef.current.files[0];
    const formData = new FormData();
    formData.append('updateFile', file);

    setUpdateStatus({
      status: 'uploading',
      progress: 0,
      message: 'Uploading update file...',
      logs: ['Starting file upload...']
    });

    try {
      const xhr = new XMLHttpRequest();
      
      // Track upload progress
      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          const progress = Math.round((e.loaded / e.total) * 50); // Upload is 50% of total
          setUpdateStatus(prev => ({
            ...prev,
            progress,
            message: `Uploading... ${progress}%`,
            logs: [...prev.logs, `Upload progress: ${progress}%`]
          }));
        }
      });

      xhr.addEventListener('load', () => {
        if (xhr.status === 200) {
          try {
            const response = JSON.parse(xhr.responseText);
            setUpdateStatus(prev => ({
              ...prev,
              status: 'processing',
              progress: 50,
              message: 'Processing update...',
              logs: [...prev.logs, 'Upload complete, processing update...']
            }));
            
            // Simulate processing steps
            simulateProcessing(response);
          } catch (e) {
            throw new Error('Invalid response from server');
          }
        } else {
          throw new Error(`Upload failed with status ${xhr.status}`);
        }
      });

      xhr.addEventListener('error', () => {
        throw new Error('Network error during upload');
      });

      xhr.open('POST', '/api/system-update/upload');
      xhr.send(formData);

    } catch (error) {
      setUpdateStatus({
        status: 'error',
        progress: 0,
        message: 'Upload failed',
        logs: [`Error: ${error instanceof Error ? error.message : 'Unknown error'}`]
      });
      
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive"
      });
    }
  };

  const simulateProcessing = (response: any) => {
    const steps = [
      'Extracting update package...',
      'Validating update contents...',
      'Backing up current files...',
      'Applying file updates...',
      'Running update scripts...',
      'Restarting services...',
      'Update completed successfully!'
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        const progress = 50 + Math.round((currentStep / steps.length) * 50);
        setUpdateStatus(prev => ({
          ...prev,
          progress,
          message: steps[currentStep],
          logs: [...prev.logs, steps[currentStep]]
        }));
        currentStep++;
      } else {
        clearInterval(interval);
        setUpdateStatus(prev => ({
          ...prev,
          status: 'success',
          progress: 100,
          message: 'System update completed successfully!',
          logs: [...prev.logs, 'All steps completed. System is ready.']
        }));
        
        toast({
          title: "Update Successful",
          description: "System has been updated successfully.",
        });
      }
    }, 1000);
  };

  const resetForm = () => {
    setSelectedFile(null);
    setUpdateStatus({
      status: 'idle',
      progress: 0,
      message: '',
      logs: []
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getStatusColor = () => {
    switch (updateStatus.status) {
      case 'success': return 'text-green-600';
      case 'error': return 'text-red-600';
      case 'uploading':
      case 'processing': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = () => {
    switch (updateStatus.status) {
      case 'success': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'error': return <X className="h-5 w-5 text-red-600" />;
      case 'uploading':
      case 'processing': return <RefreshCw className="h-5 w-5 text-blue-600 animate-spin" />;
      default: return <Upload className="h-5 w-5 text-gray-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">System Update</h1>
            <p className="text-gray-600">Upload and apply system updates</p>
          </div>
          <Button
            variant="outline"
            onClick={() => window.close()}
          >
            Close Window
          </Button>
        </div>

        {/* Warning Alert */}
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Important:</strong> System updates should only be performed during maintenance windows. 
            Always backup your system before applying updates. This process may temporarily interrupt service.
          </AlertDescription>
        </Alert>

        {/* Database Migration Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5" />
              <span>Database Management</span>
            </CardTitle>
            <CardDescription>
              Manage database migrations and create backups before applying updates
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                onClick={handleCreateBackup}
                disabled={isBackupLoading}
                variant="outline"
                className="w-full"
              >
                {isBackupLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Shield className="h-4 w-4 mr-2" />
                )}
                Create Backup
              </Button>

              <Button
                onClick={handleApplyMigrations}
                disabled={isMigrationLoading || (migrationStatus?.pendingCount === 0)}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400"
              >
                {isMigrationLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Play className="h-4 w-4 mr-2" />
                )}
                Apply Migrations ({migrationStatus?.pendingCount || 0})
              </Button>

              <Button
                onClick={handleRollbackMigration}
                disabled={isMigrationLoading || !migrationStatus?.canRollback}
                variant="destructive"
                className="w-full disabled:bg-gray-400"
              >
                {isMigrationLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <RotateCcw className="h-4 w-4 mr-2" />
                )}
                Rollback Last
              </Button>
            </div>

            {migrationStatus && (
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 border">
                <h4 className="font-medium mb-3 text-gray-900 dark:text-white">Migration Status</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Applied:</span>
                    <div className="font-semibold text-green-600 dark:text-green-400">{migrationStatus.appliedCount}</div>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Pending:</span>
                    <div className={`font-semibold ${migrationStatus.pendingCount > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-gray-600 dark:text-gray-400'}`}>
                      {migrationStatus.pendingCount}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Last Migration:</span>
                    <div className="font-semibold text-xs text-gray-900 dark:text-gray-100">
                      {migrationStatus.lastMigration || 'None'}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Can Rollback:</span>
                    <div className={`font-semibold ${migrationStatus.canRollback ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                      {migrationStatus.canRollback ? 'Yes' : 'No'}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upload Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileArchive className="h-5 w-5" />
              <span>Upload Update Package</span>
            </CardTitle>
            <CardDescription>
              Select a ZIP, TAR.GZ, or TGZ file containing the system update
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* File Input */}
            <div className="space-y-4">
              <input
                ref={fileInputRef}
                type="file"
                accept=".zip,.tar.gz,.tgz"
                onChange={handleFileSelect}
                className="hidden"
                disabled={updateStatus.status === 'uploading' || updateStatus.status === 'processing'}
              />
              
              {!selectedFile ? (
                <div
                  className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-gray-400 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-600">Click to select update file</p>
                  <p className="text-sm text-gray-400">ZIP, TAR.GZ, or TGZ files up to 100MB</p>
                </div>
              ) : (
                <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <FileArchive className="h-8 w-8 text-blue-600" />
                      <div>
                        <p className="font-medium text-gray-900">{selectedFile.name}</p>
                        <p className="text-sm text-gray-500">{formatFileSize(selectedFile.size)}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">
                        {selectedFile.name.endsWith('.zip') ? 'ZIP' : 
                         selectedFile.name.endsWith('.tar.gz') ? 'TAR.GZ' : 'TGZ'}
                      </Badge>
                      {updateStatus.status === 'idle' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={resetForm}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Upload Button */}
            {selectedFile && updateStatus.status === 'idle' && (
              <Button
                onClick={handleUpload}
                className="w-full"
                size="lg"
              >
                <Upload className="h-4 w-4 mr-2" />
                Apply System Update
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Progress Section */}
        {updateStatus.status !== 'idle' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                {getStatusIcon()}
                <span>Update Progress</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className={getStatusColor()}>{updateStatus.message}</span>
                  <span className="text-gray-500">{updateStatus.progress}%</span>
                </div>
                <Progress value={updateStatus.progress} className="h-2" />
              </div>

              {/* Status Actions */}
              <div className="flex space-x-2">
                {updateStatus.status === 'success' && (
                  <Button onClick={resetForm} variant="outline">
                    Apply Another Update
                  </Button>
                )}
                {updateStatus.status === 'error' && (
                  <Button onClick={resetForm} variant="outline">
                    Try Again
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Logs Section */}
        {updateStatus.logs.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Update Logs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm max-h-64 overflow-y-auto">
                {updateStatus.logs.map((log, index) => (
                  <div key={index} className="mb-1">
                    <span className="text-gray-500">[{new Date().toLocaleTimeString()}]</span> {log}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>Update Package Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm text-gray-600 space-y-2">
              <p><strong>To create an update package:</strong></p>
              <ol className="list-decimal list-inside space-y-1 ml-4">
                <li>Make your changes to the codebase locally</li>
                <li>Create any necessary database migration files (format: YYYYMMDD_HHMMSS_description.sql)</li>
                <li>Create a compressed archive (ZIP, TAR.GZ, or TGZ) containing your updated files</li>
                <li>Include migration files in a 'migrations' folder within the archive</li>
                <li>Ensure the archive maintains the proper directory structure</li>
                <li>Upload the package using this interface</li>
                <li>Apply database migrations using the migration controls above</li>
              </ol>
              
              <p className="mt-3"><strong>Database Migration Files:</strong></p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-sm">
                <li>Use format: YYYYMMDD_HHMMSS_description.sql (e.g., 20250127_143000_add_user_permissions.sql)</li>
                <li>Include both UP migration (schema changes) and DOWN migration (rollback instructions)</li>
                <li>Separate UP and DOWN sections with "-- DOWN MIGRATION" or "-- ROLLBACK" comment</li>
                <li>Test migrations thoroughly before deployment</li>
              </ul>
              <p className="mt-3">
                <strong>Supported formats:</strong> ZIP (.zip), Gzipped TAR (.tar.gz), TGZ (.tgz)
              </p>
              <p>
                <strong>Maximum file size:</strong> 100MB
              </p>
              
              <div className="mt-4 p-3 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <p className="font-medium text-sm mb-2">Example Migration File (20250127_143000_add_permissions.sql):</p>
                <pre className="text-xs text-gray-700 dark:text-gray-300 overflow-x-auto">
{`-- UP MIGRATION
ALTER TABLE users ADD COLUMN permissions JSONB DEFAULT '{}';
CREATE INDEX IF NOT EXISTS idx_users_permissions ON users USING gin(permissions);

-- DOWN MIGRATION  
DROP INDEX IF EXISTS idx_users_permissions;
ALTER TABLE users DROP COLUMN IF EXISTS permissions;`}
                </pre>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}