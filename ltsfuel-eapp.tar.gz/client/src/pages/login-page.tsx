import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Truck, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { loginSchema, type LoginData } from "@shared/schema";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function LoginPage() {
  const { user, loginMutation, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  // Fetch welcome message from system settings
  const { data: systemSettings = [] } = useQuery<Array<{key: string, value: string}>>({
    queryKey: ["/api/system-settings/public"],
  });

  const welcomeMessage = systemSettings.find((s) => s.key === "welcome_message")?.value || "Sign in to access the fleet management system";
  const companyName = systemSettings.find((s) => s.key === "company_name")?.value || "Lee Transport Systems";
  const maintenanceModeEnabled = systemSettings.find((s) => s.key === "maintenance_mode_enabled")?.value === "true";
  
  const form = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      stayLoggedIn: false,
    },
  });

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      if (user.role === "administrator" || user.role === "developer") {
        setLocation("/admin");
      } else {
        setLocation("/");
      }
    }
  }, [user, setLocation]);

  const onSubmit = (data: LoginData) => {
    loginMutation.mutate(data, {
      onSuccess: (user) => {
        if (user.role === "administrator" || user.role === "developer") {
          setLocation("/admin");
        } else {
          setLocation("/");
        }
      },
      onError: (error: any) => {
        // Handle locked out users specifically
        if (error.message?.includes("locked out")) {
          form.setError("root", {
            message: "Your account has been locked out. Please contact your terminal manager for assistance."
          });
        } else if (error.message?.includes("System under maintenance")) {
          form.setError("root", {
            message: "System under maintenance"
          });
        }
      }
    });
  };

  // Show loading state while checking authentication to prevent navigation flash
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }
  
  if (user) return null; // Prevent flash while redirecting

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 flex flex-col items-center justify-center p-4">
      {/* Maintenance Mode Banner */}
      {maintenanceModeEnabled && (
        <div className="w-full max-w-4xl mb-4">
          <div className="bg-red-600 text-white px-6 py-4 rounded-lg shadow-lg border border-red-700">
            <div className="flex items-center justify-center space-x-2">
              <div className="flex-shrink-0">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold">System Down for Maintenance</p>
                <p className="text-sm">Please check back later</p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="w-full max-w-md">
          <Card className="shadow-2xl border-0">
            <CardHeader className="text-center space-y-2 pb-8">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <Truck className="h-10 w-10 text-blue-600" />
                <div className="text-left">
                  <h1 className="text-2xl font-bold text-gray-900">{companyName}</h1>
                  <p className="text-sm text-gray-600">Fleet Management Portal</p>
                </div>
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">Welcome Back</CardTitle>
              <CardDescription className="text-gray-600">
                {welcomeMessage}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">Username</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your username"
                            className="h-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            placeholder="Enter your password"
                            className="h-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="stayLoggedIn"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Stay logged in
                          </FormLabel>
                          <div className="text-sm text-gray-600">
                            Keep me signed in until I choose to log out
                          </div>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {loginMutation.error && (
                    <div className="p-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded-md">
                      {loginMutation.error.message}
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white font-medium"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Signing in...
                      </>
                    ) : (
                      "Sign In"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          

        </div>
    </div>
  );
}