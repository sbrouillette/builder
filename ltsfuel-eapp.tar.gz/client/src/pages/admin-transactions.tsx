import { useQuery, useMutation } from "@tanstack/react-query";
import { Fuel, Droplets, ArrowLeft, Download, Filter, Search, Edit, Trash2, Save, X } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { updateTransactionSchema } from "@shared/schema";

interface TransactionWithDetails {
  id: string;
  employeeId: string;
  vehicleId: string;
  type: string;
  fuelType?: string;
  gallons: string;
  cost: string;
  location: string;
  odometer: number;
  date: string;
  time: string;
  notes?: string;
  submittedAt: string;
  employeeName: string;
  vehicleName: string;
}

export default function AdminTransactions() {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [timeRange, setTimeRange] = useState("30");
  const [editingTransaction, setEditingTransaction] = useState<TransactionWithDetails | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: transactions, isLoading } = useQuery<TransactionWithDetails[]>({
    queryKey: ["/api/transactions", { admin: true }],
    queryFn: () =>
      fetch("/api/transactions?admin=true").then((res) => res.json()),
    select: (data) => {
      let filtered = [...data];
      
      // Apply search filter
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        filtered = filtered.filter(t => 
          t.employeeName.toLowerCase().includes(term) ||
          t.vehicleName.toLowerCase().includes(term) ||
          t.location.toLowerCase().includes(term)
        );
      }
      
      // Apply transaction type filter
      if (typeFilter !== "all") {
        filtered = filtered.filter(t => t.type === typeFilter);
      }
      
      // Apply time range filter
      const daysAgo = parseInt(timeRange);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
      
      filtered = filtered.filter(t => 
        new Date(t.submittedAt) >= cutoffDate
      );
      
      return filtered;
    },
  });

  const updateTransactionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("PUT", `/api/transactions/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setIsEditDialogOpen(false);
      setEditingTransaction(null);
      toast({
        title: "Transaction updated",
        description: "Transaction has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating transaction",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTransactionMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Transaction deleted",
        description: "Transaction has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting transaction",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const editForm = useForm({
    resolver: zodResolver(updateTransactionSchema),
    defaultValues: {
      gallons: "",
      cost: "",
      location: "",
      odometer: "",
      notes: "",
    },
  });

  const handleEditTransaction = (transaction: TransactionWithDetails) => {
    setEditingTransaction(transaction);
    editForm.reset({
      gallons: transaction.gallons,
      cost: transaction.cost,
      location: transaction.location,
      odometer: transaction.odometer.toString(),
      notes: transaction.notes || "",
    });
    setIsEditDialogOpen(true);
  };

  const handleDeleteTransaction = (transaction: TransactionWithDetails) => {
    if (confirm(`Are you sure you want to delete this ${transaction.type} transaction by ${transaction.employeeName}?`)) {
      deleteTransactionMutation.mutate(transaction.id);
    }
  };

  const onEditSubmit = (data: any) => {
    if (!editingTransaction) return;
    updateTransactionMutation.mutate({ id: editingTransaction.id, data });
  };

  const exportTransactions = () => {
    if (!transactions || transactions.length === 0) return;
    
    const csvContent = [
      // CSV Headers
      ['Date', 'Time', 'Employee', 'Vehicle', 'Type', 'Fuel Type', 'Gallons', 'Cost', 'Location', 'Odometer', 'Notes'].join(','),
      // CSV Data
      ...transactions.map(t => [
        t.date,
        t.time,
        t.employeeName,
        t.vehicleName,
        t.type.toUpperCase(),
        t.fuelType || 'N/A',
        t.gallons,
        `$${t.cost}`,
        `"${t.location}"`,
        t.odometer,
        `"${t.notes || ''}"`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fleet-transactions-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Link href="/admin">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
        <Button 
          onClick={exportTransactions}
          disabled={!transactions || transactions.length === 0}
          className="bg-green-600 hover:bg-green-700 text-white"
        >
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="p-4 border-b">
            <h2 className="text-xl font-bold text-gray-800">All Fleet Transactions</h2>
            <p className="text-gray-600 text-sm">Review and manage employee transaction submissions</p>
          </div>

          {/* Filter and Search Options */}
          <div className="p-4 border-b bg-gray-50">
            <div className="space-y-3">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search by employee, vehicle, or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lee-primary focus:border-transparent"
                />
              </div>
              
              {/* Filter Controls */}
              <div className="grid grid-cols-2 gap-3">
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lee-primary focus:border-transparent">
                    <SelectValue placeholder="Transaction Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Transactions</SelectItem>
                    <SelectItem value="fuel">Fuel Only</SelectItem>
                    <SelectItem value="def">DEF Only</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lee-primary focus:border-transparent">
                    <SelectValue placeholder="Time Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 Days</SelectItem>
                    <SelectItem value="30">Last 30 Days</SelectItem>
                    <SelectItem value="60">Last 60 Days</SelectItem>
                    <SelectItem value="90">Last 90 Days</SelectItem>
                    <SelectItem value="365">Last Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Transaction List */}
          <div className="divide-y divide-gray-200">
            {isLoading ? (
              <div className="space-y-0">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                  <div key={i} className="p-4">
                    <div className="flex items-start space-x-3">
                      <Skeleton className="h-10 w-10 rounded-lg" />
                      <div className="space-y-2 flex-1">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/2" />
                        <Skeleton className="h-3 w-2/3" />
                      </div>
                      <Skeleton className="h-6 w-16" />
                    </div>
                  </div>
                ))}
              </div>
            ) : transactions && transactions.length > 0 ? (
              <>
                <div className="p-4 bg-blue-50 border-b">
                  <div className="text-sm font-medium text-blue-800">
                    Showing {transactions.length} transaction{transactions.length !== 1 ? 's' : ''}
                  </div>
                </div>
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <div className={`p-2 rounded-lg ${
                          transaction.type === 'fuel' 
                            ? 'bg-blue-50' 
                            : 'bg-blue-50'
                        }`}>
                          {transaction.type === 'fuel' ? (
                            <Fuel className="h-5 w-5 text-lee-primary" />
                          ) : (
                            <Droplets className="h-5 w-5 text-lee-secondary" />
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="font-semibold text-gray-800">
                            {transaction.employeeName}
                          </div>
                          <div className="text-sm text-gray-600">
                            {transaction.vehicleName} • {transaction.type.toUpperCase()}
                            {transaction.fuelType && ` (${transaction.fuelType})`}
                          </div>
                          <div className="text-sm text-gray-600">
                            <span className="font-medium">{transaction.gallons} gallons</span> • 
                            <span className="font-medium text-green-600"> ${transaction.cost}</span> • 
                            <span className="font-medium">{transaction.odometer.toLocaleString()} miles</span>
                          </div>
                          <div className="text-sm text-gray-500">
                            📍 {transaction.location}
                          </div>
                          {transaction.notes && (
                            <div className="text-xs text-gray-500 italic">
                              Note: {transaction.notes}
                            </div>
                          )}
                          <div className="text-xs text-gray-400">
                            Submitted: {new Date(transaction.submittedAt).toLocaleDateString()} at{' '}
                            {new Date(transaction.submittedAt).toLocaleTimeString([], { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="text-right mr-4">
                          <div className="text-lg font-bold text-gray-800">
                            ${transaction.cost}
                          </div>
                          <div className="text-xs text-gray-500">
                            {transaction.date}
                          </div>
                        </div>
                        <div className="flex space-x-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditTransaction(transaction)}
                            className="h-8 w-8 p-0"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteTransaction(transaction)}
                            className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </>
            ) : (
              <div className="p-8 text-center text-gray-500">
                <Filter className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium">No transactions found</p>
                <p className="text-sm">
                  {searchTerm ? 
                    `No transactions match "${searchTerm}" in the selected filters.` :
                    typeFilter !== "all" ? 
                      `No ${typeFilter} transactions in the selected time range.` :
                      "No transactions in the selected time range."
                  }
                </p>
                {(searchTerm || typeFilter !== "all" || timeRange !== "30") && (
                  <Button 
                    variant="ghost" 
                    className="mt-3 text-lee-primary"
                    onClick={() => {
                      setSearchTerm("");
                      setTypeFilter("all");
                      setTimeRange("30");
                    }}
                  >
                    Clear all filters
                  </Button>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Transaction Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Transaction</DialogTitle>
            <DialogDescription>
              Update transaction details for {editingTransaction?.employeeName}
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="gallons"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Gallons</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="Enter gallons"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="cost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cost ($)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Enter cost"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select location" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Tampa Yard">Tampa Yard</SelectItem>
                          <SelectItem value="Elmer Yard">Elmer Yard</SelectItem>
                          <SelectItem value="Pilot Travel Center">Pilot Travel Center</SelectItem>
                          <SelectItem value="Love's Travel Stop">Love's Travel Stop</SelectItem>
                          <SelectItem value="TA Travel Center">TA Travel Center</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="odometer"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Odometer Reading</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="Enter odometer reading"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add any additional notes..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex space-x-2">
                <Button
                  type="submit"
                  disabled={updateTransactionMutation.isPending}
                  className="flex-1"
                >
                  {updateTransactionMutation.isPending ? (
                    <>
                      <Save className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Update Transaction
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  <X className="mr-2 h-4 w-4" />
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      

    </div>
  );
}