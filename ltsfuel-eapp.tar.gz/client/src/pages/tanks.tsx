import { useQuery } from "@tanstack/react-query";
import { Fuel, Droplets, AlertTriangle, Plus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

interface TankLevel {
  id: string;
  name: string;
  type: string;
  currentLevel: string;
  capacity: string;
  unit: string;
  lastUpdated: string;
}

export default function Tanks() {
  const { data: tanks = [], isLoading } = useQuery<TankLevel[]>({
    queryKey: ["/api/tank-levels/driver"],
  });

  const getTankIcon = (type: string) => {
    return type === "diesel" ? Fuel : Droplets;
  };

  const getTankColor = (percentage: number) => {
    if (percentage < 25) return "bg-red-500";
    if (percentage < 50) return "bg-yellow-500";
    return "bg-green-500";
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-lee-primary mb-2">Tank Levels</h1>
        </div>
        <div className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-lee-primary mb-2">Tank Levels</h1>
        <p className="text-gray-600">Current fuel and DEF tank information</p>
      </div>

      {/* Warning Banner */}
      <Alert className="border-red-500 bg-red-50 dark:bg-red-950 dark:border-red-800">
        <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
        <AlertDescription className="text-red-800 dark:text-red-200 font-bold">
          <div className="text-base font-bold">
            THIS IS FOR ESTIMATE PURPOSES ONLY, EACH OPERATOR SHOULD VERIFY TANK MEASUREMENTS BEFORE FILLING
          </div>
        </AlertDescription>
      </Alert>

      {/* Tank Cards */}
      <div className="space-y-4">
        {tanks.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-gray-500">No tank information available for your account.</p>
            </CardContent>
          </Card>
        ) : (
          tanks.map((tank) => {
            const currentLevel = parseFloat(tank.currentLevel);
            const capacity = parseFloat(tank.capacity);
            const percentage = Math.round((currentLevel / capacity) * 100);
            const Icon = getTankIcon(tank.type);
            
            return (
              <Card key={tank.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-3">
                    <Icon className="h-6 w-6 text-lee-primary" />
                    <div>
                      <div className="text-lg font-bold">{tank.name}</div>
                      <div className="text-sm text-gray-500 font-normal">
                        {tank.type.toUpperCase()} Tank
                      </div>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Current Level</span>
                      <span className="text-sm font-bold">{percentage}%</span>
                    </div>
                    <Progress 
                      value={percentage} 
                      className="h-3"
                      style={{
                        background: `linear-gradient(to right, ${getTankColor(percentage)} 0%, ${getTankColor(percentage)} ${percentage}%, #e5e7eb ${percentage}%, #e5e7eb 100%)`
                      }}
                    />
                  </div>

                  {/* Tank Details */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Current:</span>
                      <div className="font-bold text-base">
                        {currentLevel.toLocaleString()} {tank.unit}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-500">Capacity:</span>
                      <div className="font-bold text-base">
                        {capacity.toLocaleString()} {tank.unit}
                      </div>
                    </div>
                  </div>

                  {/* Last Updated */}
                  <div className="text-xs text-gray-400 border-t pt-2">
                    Last updated: {new Date(tank.lastUpdated).toLocaleString()}
                  </div>

                  {/* Low Level Warning */}
                  {percentage < 25 && (
                    <div className="bg-red-100 border border-red-300 rounded-md p-2">
                      <div className="flex items-center gap-2 text-red-800 text-sm font-medium">
                        <AlertTriangle className="h-4 w-4" />
                        LOW LEVEL WARNING
                      </div>
                    </div>
                  )}

                  {/* Make Delivery Button */}
                  <Button 
                    className="w-full mt-4"
                    variant="outline"
                    onClick={() => {
                      // For now, alert that this feature will be implemented
                      alert(`Make Delivery/Update Level feature for ${tank.name} will be implemented soon.`);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Make Delivery/Update Level
                  </Button>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>


    </div>
  );
}