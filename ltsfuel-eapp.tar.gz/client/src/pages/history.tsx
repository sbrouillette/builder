import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Fuel, Droplets, CheckCircle } from "lucide-react";

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { Transaction } from "@shared/schema";

export default function History() {
  const [filter, setFilter] = useState("all");
  const [timeRange, setTimeRange] = useState("30");

  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    select: (data) => {
      let filtered = [...data];
      
      // Apply transaction type filter
      if (filter !== "all") {
        filtered = filtered.filter(t => t.type === filter);
      }
      
      // Apply time range filter
      const daysAgo = parseInt(timeRange);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
      
      filtered = filtered.filter(t => 
        new Date(t.submittedAt!) >= cutoffDate
      );
      
      return filtered;
    },
  });

  return (
    <div className="mobile-card">
      <div className="mb-4 sm:mb-6">
        <h2 className="text-lg sm:text-xl font-bold text-gray-800">Transaction History</h2>
        <p className="text-gray-600 text-sm">Your submitted fuel and DEF transactions</p>
      </div>

      {/* Filter Options */}
      <div className="mb-4 sm:mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="mobile-input">
              <SelectValue placeholder="Transaction Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Transactions</SelectItem>
              <SelectItem value="fuel">Fuel Only</SelectItem>
              <SelectItem value="def">DEF Only</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="mobile-input">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="30">Last 30 Days</SelectItem>
              <SelectItem value="60">Last 60 Days</SelectItem>
              <SelectItem value="90">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Transaction List */}
      <div className="divide-y divide-gray-200 border rounded-lg overflow-hidden bg-white">
        {isLoading ? (
          <div className="space-y-0">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="p-4">
                <div className="flex items-start space-x-3">
                  <Skeleton className="h-10 w-10 rounded-lg" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                    <Skeleton className="h-3 w-2/3" />
                  </div>
                  <Skeleton className="h-6 w-16" />
                </div>
              </div>
            ))}
          </div>
        ) : transactions && transactions.length > 0 ? (
          <>
            {transactions.map((transaction) => (
              <div key={transaction.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg ${
                      transaction.type === 'fuel' 
                        ? 'bg-blue-50' 
                        : 'bg-blue-50'
                    }`}>
                      {transaction.type === 'fuel' ? (
                        <Fuel className="h-5 w-5 text-lee-primary" />
                      ) : (
                        <Droplets className="h-5 w-5 text-lee-secondary" />
                      )}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">
                        {transaction.type === 'fuel' ? 'Fuel Transaction' : 'DEF Transaction'}
                      </div>
                      <div className="text-sm text-gray-600">
                        {transaction.vehicleId.replace('truck-', 'Truck #')}
                      </div>
                      <div className="text-sm text-gray-500">
                        {transaction.gallons} gal • ${transaction.cost} • {transaction.location}
                      </div>
                      <div className="text-xs text-gray-400 mt-1">
                        {new Date(transaction.submittedAt!).toLocaleDateString()} at{' '}
                        {new Date(transaction.submittedAt!).toLocaleTimeString([], { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      Submitted
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {transactions.length > 0 && (
              <div className="p-4 text-center border-t">
                <Button 
                  variant="ghost" 
                  className="text-lee-primary font-medium hover:text-blue-700"
                  disabled
                >
                  All transactions loaded
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="p-8 text-center text-gray-500">
            <p className="text-lg font-medium">No transactions found</p>
            <p className="text-sm">
              {filter !== "all" ? 
                `No ${filter} transactions in the selected time range.` :
                "No transactions in the selected time range."
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}