import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { X, Send } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { VehicleAutocomplete } from "@/components/vehicle-autocomplete";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertTransactionSchema } from "@shared/schema";
import type { Employee } from "@shared/schema";
import { z } from "zod";

const defTransactionSchema = insertTransactionSchema.extend({
  type: z.literal("def"),
  vehicleId: z.string().min(1, "Truck number is required"),
  gallons: z.string().min(1, "Gallons is required")
    .transform(val => parseFloat(val))
    .refine(val => !isNaN(val) && val > 0, "Gallons must be a positive number")
    .refine(val => val <= 30, "DEF maximum is 30 gallons"),
  odometer: z.string().min(1, "Odometer reading is required")
    .transform(val => parseInt(val))
    .refine(val => !isNaN(val) && val > 0, "Odometer must be a positive number"),
}).omit({ fuelType: true }).transform((data) => ({
  ...data,
  cost: 0, // Always set cost to 0
}));

type DefTransactionFormData = z.input<typeof defTransactionSchema>;

export default function DefForm() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [pendingFormData, setPendingFormData] = useState<DefTransactionFormData | null>(null);

  const { data: employee } = useQuery<Employee>({
    queryKey: ["/api/employee/current"],
  });

  const form = useForm<DefTransactionFormData>({
    resolver: zodResolver(defTransactionSchema),
    defaultValues: {
      type: "def",
      employeeId: "",
      vehicleId: "",
      gallons: "",
      location: "Tampa Yard",
      odometer: "",
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().slice(0, 5),
      notes: "",
    },
  });

  // Update employeeId when employee data loads
  useEffect(() => {
    if (employee && form.getValues().employeeId !== employee.id) {
      form.setValue("employeeId", employee.id);
    }
  }, [employee, form]);

  const submitTransaction = useMutation({
    mutationFn: async (data: DefTransactionFormData) => {
      const response = await apiRequest("POST", "/api/transactions", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Transaction Submitted Successfully!",
        description: "Your DEF transaction has been emailed to the office.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/stats"] });
      setLocation("/");
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: "Please check your information and try again.",
        variant: "destructive",
      });
      console.error("Transaction submission error:", error);
    },
  });

  const onSubmit = (data: DefTransactionFormData) => {
    console.log("DEF Form submitted with data:", data);
    console.log("DEF Form errors:", form.formState.errors);
    setPendingFormData(data);
    setShowConfirmDialog(true);
  };

  const handleConfirmSubmit = () => {
    if (pendingFormData) {
      submitTransaction.mutate(pendingFormData);
      setShowConfirmDialog(false);
      setPendingFormData(null);
    }
  };

  const handleCancelSubmit = () => {
    setShowConfirmDialog(false);
    setPendingFormData(null);
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-800">DEF Transaction</h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Vehicle Selection */}
            <FormField
              control={form.control}
              name="vehicleId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Unit Number</FormLabel>
                  <FormControl>
                    <VehicleAutocomplete
                      value={field.value}
                      onChange={field.onChange}
                      placeholder="Enter unit number (e.g., 247, truck-247)"
                      className="w-full p-4 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-lee-secondary focus:border-transparent"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Location */}
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Location</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="w-full p-4 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-lee-secondary focus:border-transparent">
                        <SelectValue placeholder="Select Location" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Tampa Yard">Tampa Yard</SelectItem>
                      <SelectItem value="Elmer Yard">Elmer Yard</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* DEF Gallons */}
            <FormField
              control={form.control}
              name="gallons"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">DEF Gallons</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0.0"
                      className="w-full p-4 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-lee-secondary focus:border-transparent"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Odometer Reading */}
            <FormField
              control={form.control}
              name="odometer"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Odometer Reading</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="Current mileage"
                      className="w-full p-4 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-lee-secondary focus:border-transparent"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Date and Time */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Date</FormLabel>
                    <FormControl>
                      <Input
                        type="date"
                        className="w-full p-4 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-lee-secondary focus:border-transparent"
                        disabled={user?.role !== "administrator"}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Time</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        className="w-full p-4 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-lee-secondary focus:border-transparent"
                        disabled={user?.role !== "administrator"}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="Additional notes or comments"
                      className="w-full p-4 border border-gray-300 rounded-lg text-lg focus:ring-2 focus:ring-lee-secondary focus:border-transparent"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={submitTransaction.isPending}
              className="w-full bg-secondary text-white py-4 px-6 rounded-lg font-semibold text-lg hover:bg-blue-600 transition-colors focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              {submitTransaction.isPending ? (
                "Submitting..."
              ) : (
                <>
                  <Send className="mr-2 h-5 w-5" />
                  Submit DEF Transaction
                </>
              )}
            </Button>
          </form>
        </Form>

        {/* Confirmation Dialog */}
        <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirm Transaction Details</AlertDialogTitle>
              <AlertDialogDescription>
                Please verify your DEF transaction information is correct:
                {pendingFormData && (
                  <div className="mt-4 space-y-2 text-sm">
                    <div><strong>Truck:</strong> {pendingFormData.vehicleId}</div>
                    <div><strong>Type:</strong> DEF</div>
                    <div><strong>Gallons:</strong> {pendingFormData.gallons}</div>
                    <div><strong>Odometer:</strong> {pendingFormData.odometer}</div>
                    <div><strong>Location:</strong> {pendingFormData.location}</div>
                    <div><strong>Date:</strong> {pendingFormData.date}</div>
                    <div><strong>Time:</strong> {pendingFormData.time}</div>
                    {pendingFormData.notes && <div><strong>Notes:</strong> {pendingFormData.notes}</div>}
                  </div>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={handleCancelSubmit}>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleConfirmSubmit}>
                Confirm & Submit
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  );
}
