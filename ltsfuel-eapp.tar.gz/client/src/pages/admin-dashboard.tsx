import { useQuery } from "@tanstack/react-query";
import { Users, Truck, Fuel, Droplets, TrendingUp, FileText, AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface AdminStats {
  fuelTransactions: number;
  defTransactions: number;
  totalEmployees: number;
  totalVehicles: number;
  totalTransactions: number;
}

interface TransactionWithDetails {
  id: string;
  employeeId: string;
  vehicleId: string;
  type: string;
  fuelType?: string;
  gallons: string;
  cost: string;
  location: string;
  odometer: number;
  date: string;
  time: string;
  notes?: string;
  submittedAt: string;
  employeeName: string;
  vehicleName: string;
}

interface TankLevel {
  id: string;
  name: string;
  type: string;
  currentLevel: string;
  capacity: string;
  unit: string;
  lastUpdated: string;
}

export default function AdminDashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ["/api/transactions/stats", { admin: true }],
    queryFn: () =>
      fetch("/api/transactions/stats?admin=true").then((res) => res.json()),
  });

  const { data: recentTransactions, isLoading: transactionsLoading } = useQuery<TransactionWithDetails[]>({
    queryKey: ["/api/transactions", { admin: true }],
    queryFn: () =>
      fetch("/api/transactions?admin=true").then((res) => res.json()),
    select: (data) => data.slice(0, 5), // Show only recent 5 transactions
  });

  const { data: tanks = [], isLoading: tanksLoading } = useQuery<TankLevel[]>({
    queryKey: ["/api/tank-levels"],
  });

  // Fetch public system settings for alert banner
  const { data: systemSettings = [] } = useQuery<Array<{key: string, value: string}>>({
    queryKey: ["/api/system-settings/public"],
  });

  // Check if alert banner should be shown
  const alertBannerEnabled = systemSettings.find((s) => s.key === "alert_banner_enabled")?.value === "true";
  const alertBannerMessage = systemSettings.find((s) => s.key === "alert_banner_message")?.value || "";

  // Calculate low tank alerts (below 25%)
  const lowTankAlerts = tanks.filter(tank => {
    const currentLevel = parseFloat(tank.currentLevel);
    const capacity = parseFloat(tank.capacity);
    const percentage = (currentLevel / capacity) * 100;
    return percentage < 25;
  });

  return (
    <div className="space-y-6">
      {/* Alert Banner - Show to all users when enabled */}
      {alertBannerEnabled && alertBannerMessage && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md flex items-start space-x-3">
          <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-bold text-red-800">{alertBannerMessage}</p>
          </div>
        </div>
      )}

      {/* Low Tank Alert Banner */}
      {lowTankAlerts.length > 0 && (
        <Alert className="border-red-500 bg-red-50 dark:bg-red-950 dark:border-red-800">
          <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
          <AlertDescription className="text-red-800 dark:text-red-200 font-bold">
            <div className="text-lg font-bold mb-3">
              URGENT: LOW TANK LEVELS DETECTED
            </div>
            <div className="space-y-2">
              {lowTankAlerts.map(tank => {
                const currentLevel = parseFloat(tank.currentLevel);
                const capacity = parseFloat(tank.capacity);
                const percentage = Math.round((currentLevel / capacity) * 100);
                return (
                  <div key={tank.id} className="text-base font-bold">
                    • <span className="font-extrabold">{tank.name}</span> - <span className="font-extrabold">{percentage}%</span> remaining 
                    ({currentLevel.toLocaleString()} / {capacity.toLocaleString()} {tank.unit})
                  </div>
                );
              })}
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Admin Header */}
      <div className="bg-gradient-to-r from-primary to-secondary p-6 rounded-lg text-white">
        <h1 className="text-2xl font-bold mb-2">Fleet Management Dashboard</h1>
        <p className="text-blue-100">Administrative overview of all fleet operations</p>
      </div>

      {/* Admin Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="text-center">
          <CardContent className="p-4">
            <Fuel className="h-8 w-8 text-lee-primary mx-auto mb-2" />
            {statsLoading ? (
              <Skeleton className="h-8 w-12 mx-auto mb-2" />
            ) : (
              <div className="text-2xl font-bold text-gray-800">{stats?.fuelTransactions || 0}</div>
            )}
            <div className="text-sm text-gray-600">Fuel Transactions</div>
            <div className="text-xs text-gray-500">This Month</div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="p-4">
            <Droplets className="h-8 w-8 text-lee-secondary mx-auto mb-2" />
            {statsLoading ? (
              <Skeleton className="h-8 w-12 mx-auto mb-2" />
            ) : (
              <div className="text-2xl font-bold text-gray-800">{stats?.defTransactions || 0}</div>
            )}
            <div className="text-sm text-gray-600">DEF Transactions</div>
            <div className="text-xs text-gray-500">This Month</div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="p-4">
            <Users className="h-8 w-8 text-green-600 mx-auto mb-2" />
            {statsLoading ? (
              <Skeleton className="h-8 w-12 mx-auto mb-2" />
            ) : (
              <div className="text-2xl font-bold text-gray-800">{stats?.totalEmployees || 0}</div>
            )}
            <div className="text-sm text-gray-600">Active Drivers</div>
            <div className="text-xs text-gray-500">Total</div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="p-4">
            <Truck className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            {statsLoading ? (
              <Skeleton className="h-8 w-12 mx-auto mb-2" />
            ) : (
              <div className="text-2xl font-bold text-gray-800">{stats?.totalVehicles || 0}</div>
            )}
            <div className="text-sm text-gray-600">Fleet Vehicles</div>
            <div className="text-xs text-gray-500">Total</div>
          </CardContent>
        </Card>
      </div>

      {/* Tank Levels */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Tank Levels</h2>
          <Link href="/admin/tanks">
            <Button variant="outline" size="sm">
              Manage Tanks
            </Button>
          </Link>
        </div>
        
        {tanksLoading ? (
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="h-12 w-12 rounded" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-2 w-full" />
                </div>
              </div>
            ))}
          </div>
        ) : tanks.length > 0 ? (
          <div className="space-y-4">
            {tanks.map((tank) => {
              const percentage = (parseFloat(tank.currentLevel) / parseFloat(tank.capacity)) * 100;
              const Icon = tank.type === "fuel" ? Fuel : Droplets;
              const color = tank.type === "fuel" ? "text-blue-600" : "text-green-600";
              
              return (
                <div key={tank.id} className="flex items-center space-x-4">
                  <div className={`${color} p-2 rounded-lg bg-gray-50`}>
                    <Icon className="h-8 w-8" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">{tank.name}</span>
                      <span className="text-sm text-gray-600">
                        {parseFloat(tank.currentLevel).toLocaleString()} / {parseFloat(tank.capacity).toLocaleString()} {tank.unit}
                      </span>
                    </div>
                    <Progress 
                      value={percentage} 
                      className="h-2"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>{percentage.toFixed(1)}% full</span>
                      <div className="text-right">
                        <div>90% Ullage: {Math.max(0, (parseFloat(tank.capacity) * 0.9) - parseFloat(tank.currentLevel)).toLocaleString()} {tank.unit}</div>
                        <div>Updated: {new Date(tank.lastUpdated).toLocaleDateString()}</div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center text-gray-500 py-8">
            <Fuel className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No tank levels configured</p>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Administrative Actions</h3>
        
        <Link href="/admin/transactions">
          <Button className="w-full bg-primary text-white py-4 px-6 rounded-lg shadow-sm flex items-center justify-between text-left hover:bg-blue-700 transition-colors h-auto">
            <div className="flex items-center space-x-3">
              <FileText className="h-6 w-6" />
              <div>
                <div className="font-semibold">View All Transactions</div>
                <div className="text-blue-100 text-sm">Review and manage employee submissions</div>
              </div>
            </div>
            <TrendingUp className="h-5 w-5" />
          </Button>
        </Link>

        <Link href="/admin/reports">
          <Button className="w-full bg-secondary text-white py-4 px-6 rounded-lg shadow-sm flex items-center justify-between text-left hover:bg-blue-600 transition-colors h-auto">
            <div className="flex items-center space-x-3">
              <TrendingUp className="h-6 w-6" />
              <div>
                <div className="font-semibold">Generate Reports</div>
                <div className="text-blue-100 text-sm">View analytics and export data</div>
              </div>
            </div>
            <TrendingUp className="h-5 w-5" />
          </Button>
        </Link>

        <Link href="/admin/tanks">
          <Button className="w-full bg-green-600 text-white py-4 px-6 rounded-lg shadow-sm flex items-center justify-between text-left hover:bg-green-700 transition-colors h-auto">
            <div className="flex items-center space-x-3">
              <Fuel className="h-6 w-6" />
              <div>
                <div className="font-semibold">Manage Tank Levels</div>
                <div className="text-green-100 text-sm">Monitor and update fuel & DEF tanks</div>
              </div>
            </div>
            <Droplets className="h-5 w-5" />
          </Button>
        </Link>
      </div>

      {/* Recent Transactions */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-semibold text-gray-800">Recent Transactions</h3>
            <Link href="/admin/transactions">
              <Button variant="ghost" size="sm" className="text-lee-primary hover:text-blue-700">
                View All
              </Button>
            </Link>
          </div>
          
          {transactionsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex items-center space-x-3 p-3">
                  <Skeleton className="h-6 w-6 rounded-full" />
                  <div className="space-y-1 flex-1">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          ) : recentTransactions && recentTransactions.length > 0 ? (
            <div className="space-y-3">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {transaction.type === 'fuel' ? (
                      <Fuel className="h-5 w-5 text-lee-primary" />
                    ) : (
                      <Droplets className="h-5 w-5 text-lee-secondary" />
                    )}
                    <div>
                      <div className="font-medium">{transaction.employeeName}</div>
                      <div className="text-sm text-gray-600">
                        {transaction.vehicleName} • {transaction.gallons} gal • ${transaction.cost}
                      </div>
                      <div className="text-xs text-gray-500">
                        {transaction.location} • {new Date(transaction.submittedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-green-600">Submitted</div>
                    <div className="text-xs text-gray-500">
                      {new Date(transaction.submittedAt).toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No transactions yet</p>
              <p className="text-sm">Transactions will appear here as they are submitted</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}