import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { X, Send } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { VehicleAutocomplete } from "@/components/vehicle-autocomplete";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertTransactionSchema } from "@shared/schema";
import type { Employee } from "@shared/schema";
import { z } from "zod";

const fuelTransactionSchema = insertTransactionSchema.extend({
  type: z.literal("fuel"),
  fuelType: z.string().min(1, "Fuel type is required"),
  vehicleId: z.string().min(1, "Truck number is required"),
  gallons: z.string().min(1, "Gallons is required")
    .transform(val => parseFloat(val))
    .refine(val => !isNaN(val) && val > 0, "Gallons must be a positive number"),
  odometer: z.string().min(1, "Odometer reading is required")
    .transform(val => parseInt(val))
    .refine(val => !isNaN(val) && val > 0, "Odometer must be a positive number"),
}).refine((data) => {
  if (data.fuelType === "def" && data.gallons > 30) {
    return false;
  }
  if (data.fuelType === "diesel" && data.gallons > 160) {
    return false;
  }
  return true;
}, (data) => ({
  message: data.fuelType === "def" ? "DEF maximum is 30 gallons" : "Diesel maximum is 160 gallons",
  path: ["gallons"]
})).transform((data) => ({
  ...data,
  cost: 0, // Always set cost to 0
}));

type FuelTransactionFormData = z.input<typeof fuelTransactionSchema>;

export default function FuelForm() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [pendingFormData, setPendingFormData] = useState<FuelTransactionFormData | null>(null);

  const { data: employee } = useQuery<Employee>({
    queryKey: ["/api/employee/current"],
  });

  const form = useForm<FuelTransactionFormData>({
    resolver: zodResolver(fuelTransactionSchema),
    defaultValues: {
      type: "fuel",
      employeeId: "",
      vehicleId: "",
      fuelType: "",
      gallons: "",
      location: "Tampa Yard",
      odometer: "",
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().slice(0, 5),
      notes: "",
    },
  });

  // Update employeeId when employee data loads
  useEffect(() => {
    if (employee && form.getValues().employeeId !== employee.id) {
      form.setValue("employeeId", employee.id);
    }
  }, [employee, form]);

  const submitTransaction = useMutation({
    mutationFn: async (data: FuelTransactionFormData) => {
      const response = await apiRequest("POST", "/api/transactions", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Transaction Submitted Successfully!",
        description: "Your fuel transaction has been emailed to the office.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/stats"] });
      setLocation("/");
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: "Please check your information and try again.",
        variant: "destructive",
      });
      console.error("Transaction submission error:", error);
    },
  });

  const onSubmit = (data: FuelTransactionFormData) => {
    console.log("Form submitted with data:", data);
    console.log("Form errors:", form.formState.errors);
    setPendingFormData(data);
    setShowConfirmDialog(true);
  };

  const handleConfirmSubmit = () => {
    if (pendingFormData) {
      submitTransaction.mutate(pendingFormData);
      setShowConfirmDialog(false);
      setPendingFormData(null);
    }
  };

  const handleCancelSubmit = () => {
    setShowConfirmDialog(false);
    setPendingFormData(null);
  };

  return (
    <div className="mobile-card">
      <div className="flex items-center justify-between mb-4 sm:mb-6">
        <h2 className="text-lg sm:text-xl font-bold text-gray-800">Fuel Transaction</h2>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocation("/")}
          className="text-gray-500 hover:text-gray-700 min-h-[44px] min-w-[44px]"
        >
          <X className="h-5 w-5" />
        </Button>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 sm:space-y-6">
            {/* Vehicle Selection */}
            <FormField
              control={form.control}
              name="vehicleId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Unit Number</FormLabel>
                  <FormControl>
                    <VehicleAutocomplete
                      value={field.value}
                      onChange={field.onChange}
                      placeholder="Enter unit number (e.g., 247, truck-247)"
                      className="mobile-input"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Fuel Type */}
            <FormField
              control={form.control}
              name="fuelType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Fuel Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="mobile-input">
                        <SelectValue placeholder="Select Fuel Type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="diesel">Diesel</SelectItem>
                      <SelectItem value="def">DEF</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Location */}
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Location</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="mobile-input">
                        <SelectValue placeholder="Select Location" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Tampa Yard">Tampa Yard</SelectItem>
                      <SelectItem value="Elmer Yard">Elmer Yard</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Gallons */}
            <FormField
              control={form.control}
              name="gallons"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Gallons</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0.0"
                      className="mobile-input"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Odometer Reading */}
            <FormField
              control={form.control}
              name="odometer"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Odometer Reading</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="Current mileage"
                      className="mobile-input"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Date and Time */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Date</FormLabel>
                    <FormControl>
                      <Input
                        type="date"
                        className="mobile-input"
                        disabled={user?.role !== "administrator"}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Time</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        className="mobile-input"
                        disabled={user?.role !== "administrator"}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="block text-sm font-medium text-gray-700 mb-2">Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="Additional notes or comments"
                      className="mobile-input"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={submitTransaction.isPending}
              className="mobile-button bg-primary text-white font-semibold text-lg hover:bg-blue-700 active:bg-blue-800 transition-colors focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              {submitTransaction.isPending ? (
                "Submitting..."
              ) : (
                <>
                  <Send className="mr-2 h-5 w-5" />
                  Submit Fuel Transaction
                </>
              )}
            </Button>
        </form>
      </Form>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Transaction Details</AlertDialogTitle>
            <AlertDialogDescription>
              Please verify your transaction information is correct:
              
              {pendingFormData && (
                <div className="mt-4 space-y-2 text-sm">
                  <div><strong>Truck:</strong> {pendingFormData.vehicleId}</div>
                  <div><strong>Fuel Type:</strong> {pendingFormData.fuelType}</div>
                  <div><strong>Gallons:</strong> {pendingFormData.gallons}</div>
                  <div><strong>Odometer:</strong> {pendingFormData.odometer}</div>
                  <div><strong>Location:</strong> {pendingFormData.location}</div>
                  <div><strong>Date:</strong> {pendingFormData.date}</div>
                  <div><strong>Time:</strong> {pendingFormData.time}</div>
                  {pendingFormData.notes && <div><strong>Notes:</strong> {pendingFormData.notes}</div>}
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCancelSubmit}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmSubmit}>
              Confirm & Submit
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
