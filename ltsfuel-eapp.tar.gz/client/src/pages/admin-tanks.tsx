import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Fuel, Droplets, Edit3, Save, X, MapPin } from "lucide-react";

interface TankLevel {
  id: string;
  name: string;
  type: string;
  location: string;
  currentLevel: string;
  capacity: string;
  unit: string;
  lastUpdated: string;
}

export default function AdminTanks() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingTank, setEditingTank] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<{ currentLevel: string; capacity: string }>({
    currentLevel: "",
    capacity: "",
  });

  const { data: tanks = [], isLoading } = useQuery<TankLevel[]>({
    queryKey: ["/api/tank-levels"],
  });

  const updateTankMutation = useMutation({
    mutationFn: async (data: { id: string; currentLevel: string; capacity: string }) => {
      return await fetch(`/api/tank-levels/${data.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          currentLevel: data.currentLevel,
          capacity: data.capacity,
        }),
      }).then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tank-levels"] });
      setEditingTank(null);
      toast({
        title: "Tank Updated",
        description: "Tank levels have been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update tank levels. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (tank: TankLevel) => {
    setEditingTank(tank.id);
    setEditValues({
      currentLevel: tank.currentLevel,
      capacity: tank.capacity,
    });
  };

  const handleSave = () => {
    if (editingTank) {
      updateTankMutation.mutate({
        id: editingTank,
        currentLevel: editValues.currentLevel,
        capacity: editValues.capacity,
      });
    }
  };

  const handleCancel = () => {
    setEditingTank(null);
    setEditValues({ currentLevel: "", capacity: "" });
  };

  const getTankIcon = (type: string) => {
    return type === "diesel" ? <Fuel className="h-5 w-5" /> : <Droplets className="h-5 w-5" />;
  };

  const getTankColor = (type: string) => {
    return type === "diesel" ? "text-blue-600" : "text-green-600";
  };

  const getPercentage = (current: string, capacity: string) => {
    const currentNum = parseFloat(current);
    const capacityNum = parseFloat(capacity);
    return capacityNum > 0 ? (currentNum / capacityNum) * 100 : 0;
  };

  const getStatusColor = (percentage: number) => {
    if (percentage >= 70) return "bg-green-500";
    if (percentage >= 30) return "bg-yellow-500";
    return "bg-red-500";
  };

  const getStatusText = (percentage: number) => {
    if (percentage >= 70) return "Good";
    if (percentage >= 30) return "Medium";
    return "Low";
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Tank Management</h1>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {[1, 2].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-0 pb-4">
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/3 mt-2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-2 bg-gray-200 rounded w-full"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Tank Management</h1>
          <p className="text-muted-foreground">Monitor and manage fuel and DEF tank levels</p>
        </div>
      </div>

      {/* Group tanks by location */}
      <div className="space-y-8">
        {['Tampa Yard', 'Elmer Yard'].map((location) => {
          const locationTanks = tanks.filter(tank => tank.location === location);
          
          if (locationTanks.length === 0) return null;

          return (
            <div key={location} className="space-y-4">
              <div className="flex items-center space-x-2 border-b pb-2">
                <MapPin className="h-5 w-5 text-lee-primary" />
                <h2 className="text-xl font-semibold text-gray-800">{location}</h2>
                <span className="text-sm text-gray-500">({locationTanks.length} tanks)</span>
              </div>
              
              <div className="grid gap-6 md:grid-cols-2">
                {locationTanks.map((tank) => {
                  const percentage = getPercentage(tank.currentLevel, tank.capacity);
                  const isEditing = editingTank === tank.id;

                  return (
                    <Card key={tank.id} className="relative">
                      <CardHeader className="space-y-0 pb-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className={getTankColor(tank.type)}>
                              {getTankIcon(tank.type)}
                            </div>
                            <CardTitle className="text-lg">
                              {tank.type === 'diesel' ? 'Diesel Tank' : 'DEF Tank'}
                            </CardTitle>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge 
                              variant={percentage >= 70 ? "default" : percentage >= 30 ? "secondary" : "destructive"}
                            >
                              {getStatusText(percentage)}
                            </Badge>
                            {!isEditing && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEdit(tank)}
                                className="h-8 w-8 p-0"
                              >
                                <Edit3 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                        <CardDescription className="capitalize">
                          {tank.type} Storage • Last updated: {new Date(tank.lastUpdated).toLocaleString()}
                        </CardDescription>
                      </CardHeader>

                      <CardContent className="space-y-4">
                        {isEditing ? (
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor={`current-${tank.id}`}>Current Level</Label>
                                <Input
                                  id={`current-${tank.id}`}
                                  type="number"
                                  value={editValues.currentLevel}
                                  onChange={(e) =>
                                    setEditValues((prev) => ({
                                      ...prev,
                                      currentLevel: e.target.value,
                                    }))
                                  }
                                  placeholder="Current level"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor={`capacity-${tank.id}`}>Capacity</Label>
                                <Input
                                  id={`capacity-${tank.id}`}
                                  type="number"
                                  value={editValues.capacity}
                                  onChange={(e) =>
                                    setEditValues((prev) => ({
                                      ...prev,
                                      capacity: e.target.value,
                                    }))
                                  }
                                  placeholder="Total capacity"
                                />
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                onClick={handleSave}
                                disabled={updateTankMutation.isPending}
                                size="sm"
                              >
                                <Save className="h-4 w-4 mr-1" />
                                Save
                              </Button>
                              <Button
                                variant="outline"
                                onClick={handleCancel}
                                size="sm"
                              >
                                <X className="h-4 w-4 mr-1" />
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span>Level</span>
                                <span className="font-medium">
                                  {parseFloat(tank.currentLevel).toLocaleString()} / {parseFloat(tank.capacity).toLocaleString()} {tank.unit}
                                </span>
                              </div>
                              <Progress 
                                value={percentage} 
                                className="h-3"
                              />
                              <div className="flex justify-between text-xs text-muted-foreground">
                                <span>0%</span>
                                <span className="font-medium">{percentage.toFixed(1)}%</span>
                                <span>100%</span>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 pt-2 text-sm">
                              <div>
                                <div className="text-muted-foreground">Available</div>
                                <div className="font-medium">
                                  {parseFloat(tank.currentLevel).toLocaleString()} {tank.unit}
                                </div>
                              </div>
                              <div>
                                <div className="text-muted-foreground">90% Ullage</div>
                                <div className="font-medium">
                                  {Math.max(0, (parseFloat(tank.capacity) * 0.9) - parseFloat(tank.currentLevel)).toLocaleString()} {tank.unit}
                                </div>
                              </div>
                            </div>
                          </>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {tanks.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <div className="text-muted-foreground">
              <Fuel className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No tank levels configured</p>
              <p className="text-sm mt-1">Tank levels will appear here once configured</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}