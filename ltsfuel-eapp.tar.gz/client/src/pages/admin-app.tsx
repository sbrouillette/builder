import { Switch, Route } from "wouter";
import { AdminHeader } from "@/components/admin-header";
import { AdminNavigationTabs } from "@/components/admin-navigation-tabs";
import { MaintenanceBanner } from "@/components/maintenance-banner";
import AdminDashboard from "@/pages/admin-dashboard";
import AdminTransactions from "@/pages/admin-transactions";
import AdminReports from "@/pages/admin-reports";
import AdminTanks from "@/pages/admin-tanks";
import AdminSettings from "@/pages/admin-settings";
import UserManagement from "@/pages/user-management";
import VehicleManagement from "@/pages/vehicle-management";
import AdminSystemLogs from "@/pages/admin-system-logs";
import AdminTankOptions from "@/pages/admin-tank-options";
import AdminSystemSettings from "@/pages/admin-system-settings";
import SystemUpdate from "@/pages/system-update";
import NotFound from "@/pages/not-found";

function AdminRouter() {
  return (
    <Switch>
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/transactions" component={AdminTransactions} />
      <Route path="/admin/reports" component={AdminReports} />
      <Route path="/admin/tanks" component={AdminTanks} />
      <Route path="/admin/settings" component={AdminSettings} />
      <Route path="/admin/users" component={UserManagement} />
      <Route path="/admin/vehicles" component={VehicleManagement} />
      <Route path="/admin/tank-options" component={AdminTankOptions} />
      <Route path="/admin/system-settings" component={AdminSystemSettings} />
      <Route path="/admin/system-logs" component={AdminSystemLogs} />
      <Route path="/admin/system-update" component={SystemUpdate} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function AdminApp() {
  return (
    <div className="min-h-screen bg-gray-50">
      <MaintenanceBanner />
      <AdminHeader />
      <div className="mobile-container py-4 sm:py-6">
        <AdminNavigationTabs />
        <AdminRouter />
      </div>

    </div>
  );
}