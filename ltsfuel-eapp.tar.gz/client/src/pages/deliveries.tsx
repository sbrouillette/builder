import { Truck, Package, MapPin, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Deliveries() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-lee-primary mb-2">Deliveries</h1>
        <p className="text-gray-600">Delivery management and tracking</p>
      </div>

      {/* Tank Levels Section */}
      <div className="grid grid-cols-1 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Truck className="h-6 w-6 text-lee-primary" />
              Tank Levels
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Monitor current fuel and DEF tank levels</p>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => window.location.href = '/tanks'}
            >
              View Tank Levels
            </Button>
          </CardContent>
        </Card>
      </div>


    </div>
  );
}