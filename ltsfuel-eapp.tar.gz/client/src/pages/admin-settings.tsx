import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

import { Users, Truck, FileText, Fuel, Settings2, Upload } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function AdminSettings() {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      <div className="grid gap-6">
        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Management Options</CardTitle>
            <CardDescription>
              Quick access to system management features
            </CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/admin/users">
              <Button variant="outline" className="h-20 w-full flex-col space-y-2">
                <Users className="h-6 w-6" />
                <span>User Management</span>
              </Button>
            </Link>
            <Link href="/admin/vehicles">
              <Button variant="outline" className="h-20 w-full flex-col space-y-2">
                <Truck className="h-6 w-6" />
                <span>Fleet Vehicles</span>
              </Button>
            </Link>
            {user?.role === "developer" && (
              <Link href="/admin/tank-options">
                <Button variant="outline" className="h-20 w-full flex-col space-y-2">
                  <Fuel className="h-6 w-6" />
                  <span>Tank Options</span>
                </Button>
              </Link>
            )}
            {user?.role === "developer" && (
              <Link href="/admin/system-settings">
                <Button variant="outline" className="h-20 w-full flex-col space-y-2">
                  <Settings2 className="h-6 w-6" />
                  <span>System Settings</span>
                </Button>
              </Link>
            )}
            {user?.role === "developer" && (
              <Link href="/admin/system-logs">
                <Button variant="outline" className="h-20 w-full flex-col space-y-2">
                  <FileText className="h-6 w-6" />
                  <span>System Logs</span>
                </Button>
              </Link>
            )}
            {user?.role === "developer" && (
              <Button 
                variant="outline" 
                className="h-20 w-full flex-col space-y-2"
                onClick={() => window.open('/admin/system-update', '_blank')}
              >
                <Upload className="h-6 w-6" />
                <span>Update System</span>
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}