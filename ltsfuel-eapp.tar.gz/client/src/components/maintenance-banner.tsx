import { useQuery } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";

export function MaintenanceBanner() {
  // Fetch public system settings to check maintenance mode with real-time updates
  const { data: systemSettings = [] } = useQuery<Array<{key: string, value: string}>>({
    queryKey: ["/api/system-settings/public"],
    refetchInterval: 5000, // Check every 5 seconds for real-time updates
    refetchOnWindowFocus: true,
  });

  const maintenanceModeEnabled = systemSettings.find((s) => s.key === "maintenance_mode_enabled")?.value === "true";



  if (!maintenanceModeEnabled) {
    return null;
  }

  return (
    <div className="bg-yellow-500 text-yellow-900 px-4 py-3 border-b border-yellow-600">
      <div className="flex items-center justify-center space-x-2 max-w-7xl mx-auto">
        <AlertTriangle className="h-5 w-5 flex-shrink-0" />
        <p className="text-sm font-bold text-center">
          Maintenance Mode Enabled
        </p>
      </div>
    </div>
  );
}