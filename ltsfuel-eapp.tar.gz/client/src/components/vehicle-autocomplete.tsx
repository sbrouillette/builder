import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Truck, Check } from "lucide-react";
import type { Vehicle } from "@shared/schema";

interface VehicleAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export function VehicleAutocomplete({ value, onChange, placeholder, className }: VehicleAutocompleteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [filteredVehicles, setFilteredVehicles] = useState<Vehicle[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const { data: vehicles } = useQuery<Vehicle[]>({
    queryKey: ["/api/vehicles"],
  });

  useEffect(() => {
    if (!vehicles || !value) {
      setFilteredVehicles([]);
      return;
    }

    const filtered = vehicles.filter(vehicle => 
      vehicle.id.toLowerCase().includes(value.toLowerCase()) ||
      vehicle.name.toLowerCase().includes(value.toLowerCase())
    ).slice(0, 5); // Limit to 5 suggestions

    setFilteredVehicles(filtered);
    setIsOpen(filtered.length > 0 && value.length > 0);
  }, [value, vehicles]);

  const handleSelectVehicle = (vehicle: Vehicle) => {
    onChange(vehicle.id);
    setIsOpen(false);
    inputRef.current?.blur();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
  };

  const handleInputBlur = () => {
    // Delay closing to allow clicking on suggestions
    setTimeout(() => setIsOpen(false), 150);
  };

  return (
    <div className="relative">
      <Input
        ref={inputRef}
        value={value}
        onChange={handleInputChange}
        onFocus={() => value && setIsOpen(filteredVehicles.length > 0)}
        onBlur={handleInputBlur}
        placeholder={placeholder}
        className={className}
      />
      
      {isOpen && filteredVehicles.length > 0 && (
        <div
          ref={dropdownRef}
          className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-auto"
        >
          {filteredVehicles.map((vehicle) => (
            <Button
              key={vehicle.id}
              variant="ghost"
              className="w-full justify-start px-3 py-2 h-auto hover:bg-gray-50"
              onClick={() => handleSelectVehicle(vehicle)}
            >
              <div className="flex items-center space-x-3">
                <Truck className="h-4 w-4 text-gray-400" />
                <div className="flex flex-col items-start">
                  <span className="font-medium text-sm">{vehicle.id}</span>
                  <span className="text-xs text-gray-500">{vehicle.name} - {vehicle.model}</span>
                </div>
                {value === vehicle.id && (
                  <Check className="h-4 w-4 text-green-500 ml-auto" />
                )}
              </div>
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}