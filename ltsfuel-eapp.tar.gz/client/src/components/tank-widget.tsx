import { useState } from "react";
import { Fuel, Droplets, AlertTriangle, Settings, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import type { TankWidget } from "@shared/schema";

interface TankLevel {
  id: string;
  name: string;
  type: string;
  location: string;
  currentLevel: string;
  capacity: string;
  unit: string;
  lastUpdated: string;
}

interface TankWidgetProps {
  tank: TankLevel;
  widget: TankWidget;
  onUpdateWidget: (widget: TankWidget) => void;
  onRemoveWidget: () => void;
  isCustomizing?: boolean;
}

export function TankWidgetCard({ tank, widget, onUpdateWidget, onRemoveWidget, isCustomizing = false }: TankWidgetProps) {
  const [showSettings, setShowSettings] = useState(false);
  
  const currentLevel = parseFloat(tank.currentLevel);
  const capacity = parseFloat(tank.capacity);
  const percentage = Math.round((currentLevel / capacity) * 100);
  const Icon = tank.type === "diesel" ? Fuel : Droplets;
  
  const isLowLevel = percentage <= widget.alertThreshold;
  
  const getTankColor = (percentage: number) => {
    if (percentage <= widget.alertThreshold) return "bg-red-500";
    if (percentage < 50) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <>
      <Card className={`relative ${isLowLevel ? 'border-red-500 border-2' : ''}`}>
        {isCustomizing && (
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 z-10 h-8 w-8 p-0"
            onClick={onRemoveWidget}
          >
            <X className="h-4 w-4" />
          </Button>
        )}
        
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Icon className="h-4 w-4 text-lee-primary" />
              <span className="font-medium">{tank.name}</span>
            </div>
            {isCustomizing && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(true)}
                className="h-6 w-6 p-0"
              >
                <Settings className="h-3 w-3" />
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-3 pt-0">
          {widget.showPercentage && (
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">Fill Level</span>
                <span className={`text-xs font-bold ${isLowLevel ? 'text-red-600' : ''}`}>
                  {percentage}%
                </span>
              </div>
              <Progress 
                value={percentage} 
                className="h-2"
                style={{
                  background: `linear-gradient(to right, ${getTankColor(percentage)} 0%, ${getTankColor(percentage)} ${percentage}%, #e5e7eb ${percentage}%, #e5e7eb 100%)`
                }}
              />
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            {widget.showLevel && (
              <div>
                <span className="text-gray-500">Current:</span>
                <div className="font-bold">
                  {currentLevel.toLocaleString()} {tank.unit}
                </div>
              </div>
            )}
            {widget.showCapacity && (
              <div>
                <span className="text-gray-500">Capacity:</span>
                <div className="font-bold">
                  {capacity.toLocaleString()} {tank.unit}
                </div>
              </div>
            )}
          </div>
          
          {isLowLevel && (
            <div className="bg-red-50 border border-red-200 rounded-md p-2">
              <div className="flex items-center gap-1 text-red-800 text-xs font-medium">
                <AlertTriangle className="h-3 w-3" />
                LOW LEVEL ALERT
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Widget Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Tank Widget Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="showLevel"
                  checked={widget.showLevel}
                  onCheckedChange={(checked) => 
                    onUpdateWidget({ ...widget, showLevel: !!checked })
                  }
                />
                <Label htmlFor="showLevel">Show current level</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="showPercentage"
                  checked={widget.showPercentage}
                  onCheckedChange={(checked) => 
                    onUpdateWidget({ ...widget, showPercentage: !!checked })
                  }
                />
                <Label htmlFor="showPercentage">Show percentage bar</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="showCapacity"
                  checked={widget.showCapacity}
                  onCheckedChange={(checked) => 
                    onUpdateWidget({ ...widget, showCapacity: !!checked })
                  }
                />
                <Label htmlFor="showCapacity">Show tank capacity</Label>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Alert Threshold: {widget.alertThreshold}%</Label>
              <Slider
                value={[widget.alertThreshold]}
                onValueChange={([value]) => 
                  onUpdateWidget({ ...widget, alertThreshold: value })
                }
                max={100}
                min={0}
                step={5}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>0%</span>
                <span>100%</span>
              </div>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowSettings(false)}>
                Done
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}