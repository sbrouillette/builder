import { Truck, LogOut, User, Settings } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import type { Employee } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

export function AdminHeader() {
  const { logoutMutation } = useAuth();
  
  const { data: employee } = useQuery<Employee>({
    queryKey: ["/api/employee/current", { admin: true }],
    queryFn: () =>
      fetch("/api/employee/current?admin=true").then((res) => res.json()),
  });

  // Fetch company name from system settings
  const { data: systemSettings = [] } = useQuery<Array<{key: string, value: string}>>({
    queryKey: ["/api/system-settings/public"],
  });

  const companyName = systemSettings.find((s) => s.key === "company_name")?.value || "Lee Transport Systems";

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-gradient-to-r from-primary to-secondary text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/admin">
            <div className="flex items-center space-x-3 cursor-pointer">
              <Truck className="text-2xl h-8 w-8" />
              <div>
                <h1 className="text-xl font-bold">{companyName}</h1>
                <p className="text-blue-200 text-sm">Fleet Management Admin Portal</p>
              </div>
            </div>
          </Link>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span className="text-sm">{employee?.name || "Loading..."}</span>
              <span className="text-xs bg-yellow-500 text-yellow-900 px-2 py-1 rounded-full font-medium">
                ADMIN
              </span>
            </div>
            <Link href="/">
              <button className="text-blue-200 hover:text-white text-sm flex items-center space-x-1">
                <Settings className="h-4 w-4" />
                <span>Driver View</span>
              </button>
            </Link>
            <button 
              onClick={handleLogout}
              className="text-blue-200 hover:text-white"
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}