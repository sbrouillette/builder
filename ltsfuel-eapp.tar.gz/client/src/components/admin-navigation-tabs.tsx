import { BarChart3, FileText, TrendingUp, Fuel, Settings } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

const baseTabs = [
  { id: "dashboard", label: "Dashboard", icon: BarChart3, path: "/admin" },
  { id: "transactions", label: "Transactions", icon: FileText, path: "/admin/transactions" },
  { id: "reports", label: "Reports", icon: TrendingUp, path: "/admin/reports" },
  { id: "tanks", label: "Tanks", icon: Fuel, path: "/admin/tanks" },
  { id: "settings", label: "Settings", icon: Settings, path: "/admin/settings" },
];

export function AdminNavigationTabs() {
  const [location] = useLocation();
  const { user } = useAuth();

  const tabs = baseTabs;

  return (
    <div className="bg-white rounded-lg shadow-sm mb-4 sm:mb-6 sticky top-0 z-10">
      <div className="flex border-b">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = location === tab.path;
          
          return (
            <Link key={tab.id} href={tab.path}>
              <button
                className={cn(
                  "mobile-nav-button flex-col items-center justify-center",
                  isActive
                    ? "text-lee-primary border-b-2 border-lee-primary bg-lee-light"
                    : "text-gray-500 hover:text-lee-primary active:bg-gray-50"
                )}
              >
                <Icon className="h-4 w-4 sm:h-5 sm:w-5 mb-1" />
                <div className="text-xs sm:text-sm font-medium">{tab.label}</div>
              </button>
            </Link>
          );
        })}
      </div>
    </div>
  );
}