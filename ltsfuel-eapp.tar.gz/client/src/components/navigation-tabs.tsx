import { Home, Fuel, Truck, History } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const tabs = [
  { id: "dashboard", label: "Dashboard", icon: Home, path: "/" },
  { id: "fuel", label: "Fuel Log", icon: Fuel, path: "/fuel" },
  { id: "deliveries", label: "Deliveries", icon: Truck, path: "/deliveries" },
  { id: "history", label: "History", icon: History, path: "/history" },
];

export function NavigationTabs() {
  const [location] = useLocation();

  return (
    <div className="bg-white rounded-lg shadow-sm mb-4 sm:mb-6 sticky top-0 z-10">
      <div className="flex border-b">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = location === tab.path;
          
          return (
            <Link key={tab.id} href={tab.path}>
              <button
                className={cn(
                  "mobile-nav-button flex-col items-center justify-center",
                  isActive
                    ? "text-lee-primary border-b-2 border-lee-primary bg-lee-light"
                    : "text-gray-500 hover:text-lee-primary active:bg-gray-50"
                )}
              >
                <Icon className="h-5 w-5 sm:h-6 sm:w-6 mb-1" />
                <div className="text-xs sm:text-sm font-medium">{tab.label}</div>
              </button>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
