import { Truck, LogOut, Settings } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";

export function Header() {
  const { user, logoutMutation } = useAuth();
  
  // Fetch company name from system settings
  const { data: systemSettings = [] } = useQuery<Array<{key: string, value: string}>>({
    queryKey: ["/api/system-settings/public"],
  });

  const companyName = systemSettings.find((s) => s.key === "company_name")?.value || "Lee Transport Systems";

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-primary text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Truck className="text-2xl h-8 w-8" />
            <div>
              <h1 className="text-xl font-bold">{companyName}</h1>
              <p className="text-blue-200 text-sm">Fleet Management Portal</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm">{user?.name || "Loading..."}</span>
            {user?.role === "administrator" && (
              <Link href="/admin">
                <button className="text-blue-200 hover:text-white text-sm flex items-center space-x-1">
                  <Settings className="h-4 w-4" />
                  <span>Admin</span>
                </button>
              </Link>
            )}
            <button 
              onClick={handleLogout}
              className="text-blue-200 hover:text-white"
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
