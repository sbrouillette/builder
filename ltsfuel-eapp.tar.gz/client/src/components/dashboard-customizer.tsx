import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Settings, Plus, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { DashboardWidgets, TankWidget } from "@shared/schema";

interface TankLevel {
  id: string;
  name: string;
  type: string;
  location: string;
  currentLevel: string;
  capacity: string;
  unit: string;
  lastUpdated: string;
}

interface DashboardCustomizerProps {
  currentWidgets: DashboardWidgets;
  onUpdate: (widgets: DashboardWidgets) => void;
}

export function DashboardCustomizer({ currentWidgets, onUpdate }: DashboardCustomizerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [localWidgets, setLocalWidgets] = useState<DashboardWidgets>(currentWidgets);
  const { toast } = useToast();

  const { data: availableTanks = [] } = useQuery<TankLevel[]>({
    queryKey: ["/api/tank-levels/driver"],
  });

  const saveWidgetsMutation = useMutation({
    mutationFn: async (widgets: DashboardWidgets) => {
      const res = await apiRequest("PUT", "/api/user/dashboard-widgets", {
        dashboardWidgets: JSON.stringify(widgets)
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      onUpdate(localWidgets);
      setIsOpen(false);
      toast({
        title: "Dashboard updated",
        description: "Your dashboard widgets have been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error saving dashboard",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addTankWidget = (tankId: string) => {
    const existingWidget = localWidgets.tankWidgets.find(w => w.tankId === tankId);
    if (existingWidget) return;

    const newWidget: TankWidget = {
      tankId,
      showLevel: true,
      showPercentage: true,
      showCapacity: false,
      alertThreshold: 25,
    };

    setLocalWidgets({
      ...localWidgets,
      tankWidgets: [...localWidgets.tankWidgets, newWidget],
    });
  };

  const removeTankWidget = (tankId: string) => {
    setLocalWidgets({
      ...localWidgets,
      tankWidgets: localWidgets.tankWidgets.filter(w => w.tankId !== tankId),
    });
  };

  const updateTankWidget = (tankId: string, updates: Partial<TankWidget>) => {
    setLocalWidgets({
      ...localWidgets,
      tankWidgets: localWidgets.tankWidgets.map(w =>
        w.tankId === tankId ? { ...w, ...updates } : w
      ),
    });
  };

  const getAvailableTanksForWidgets = () => {
    const usedTankIds = new Set(localWidgets.tankWidgets.map(w => w.tankId));
    return availableTanks.filter(tank => !usedTankIds.has(tank.id));
  };

  const handleSave = () => {
    saveWidgetsMutation.mutate(localWidgets);
  };

  const handleCancel = () => {
    setLocalWidgets(currentWidgets);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="fixed top-20 right-4 z-50">
          <Settings className="h-4 w-4 mr-2" />
          Customize Dashboard
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Customize Your Dashboard</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* General Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">General Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="showTransactionStats"
                  checked={localWidgets.showTransactionStats}
                  onCheckedChange={(checked) => 
                    setLocalWidgets({ ...localWidgets, showTransactionStats: !!checked })
                  }
                />
                <Label htmlFor="showTransactionStats">Show transaction statistics</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="showQuickActions"
                  checked={localWidgets.showQuickActions}
                  onCheckedChange={(checked) => 
                    setLocalWidgets({ ...localWidgets, showQuickActions: !!checked })
                  }
                />
                <Label htmlFor="showQuickActions">Show quick actions</Label>
              </div>
            </CardContent>
          </Card>

          {/* Tank Widgets */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Tank Widgets</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Current Tank Widgets */}
              {localWidgets.tankWidgets.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Active Tank Widgets</Label>
                  <div className="space-y-2">
                    {localWidgets.tankWidgets.map((widget) => {
                      const tank = availableTanks.find(t => t.id === widget.tankId);
                      if (!tank) return null;
                      
                      return (
                        <div key={widget.tankId} className="flex items-center justify-between p-2 border rounded-md">
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-medium">{tank.name}</span>
                            <span className="text-xs text-gray-500">
                              Alert at {widget.alertThreshold}%
                            </span>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeTankWidget(widget.tankId)}
                            className="h-8 w-8 p-0"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Add Tank Widgets */}
              {getAvailableTanksForWidgets().length > 0 && (
                <>
                  {localWidgets.tankWidgets.length > 0 && <Separator />}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Add Tank Widgets</Label>
                    <div className="grid grid-cols-1 gap-2">
                      {getAvailableTanksForWidgets().map((tank) => (
                        <div key={tank.id} className="flex items-center justify-between p-2 border rounded-md">
                          <div>
                            <span className="text-sm font-medium">{tank.name}</span>
                            <div className="text-xs text-gray-500">
                              {tank.location} • {tank.type.toUpperCase()}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => addTankWidget(tank.id)}
                            className="h-8 w-8 p-0"
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {availableTanks.length === 0 && (
                <p className="text-sm text-gray-500">No tanks available for widgets.</p>
              )}
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              disabled={saveWidgetsMutation.isPending}
            >
              {saveWidgetsMutation.isPending ? (
                <>
                  <Settings className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}