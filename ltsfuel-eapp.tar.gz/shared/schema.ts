import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("driver"), // 'driver', 'administrator', or 'developer'
  status: text("status").notNull().default("active"), // 'active' or 'locked_out'
  visibleTanks: text("visible_tanks").array().default(sql`'{}'`), // array of tank IDs user can see
  dashboardWidgets: text("dashboard_widgets").default('{"tankWidgets":[],"showTransactionStats":true,"showQuickActions":true}'), // JSON string for dashboard configuration
  permissions: text("permissions").notNull().default('{}'), // JSON string for user permissions
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const employees = pgTable("employees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("driver"), // 'driver' or 'admin'
});

export const vehicles = pgTable("vehicles", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  model: text("model").notNull(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").references(() => users.id).notNull(),
  vehicleId: varchar("vehicle_id").references(() => vehicles.id).notNull(),
  type: text("type").notNull(), // 'fuel' or 'def'
  fuelType: text("fuel_type"), // for fuel transactions only
  gallons: decimal("gallons", { precision: 10, scale: 2 }).notNull(),
  cost: decimal("cost", { precision: 10, scale: 2 }).notNull(),
  location: text("location").notNull(),
  odometer: integer("odometer").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  notes: text("notes"),
  submittedAt: timestamp("submitted_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: z.enum(["driver", "administrator", "developer"]).default("driver"),
  status: z.enum(["active", "locked_out"]).default("active"),
  visibleTanks: z.array(z.string()).default([]),
  dashboardWidgets: z.string().default('{"tankWidgets":[],"showTransactionStats":true,"showQuickActions":true}'),
  permissions: z.string().default('{}'),
});

// Permission schemas
export const userPermissionsSchema = z.object({
  systemSettings: z.object({
    canEditWelcomeMessage: z.boolean().default(false),
    canEditAlertBanner: z.boolean().default(false),
    canViewSystemLogs: z.boolean().default(false),
  }).default({}),
  userManagement: z.object({
    canViewUsers: z.boolean().default(false),
    canCreateUsers: z.boolean().default(false),
    canEditUsers: z.boolean().default(false),
    canDeleteUsers: z.boolean().default(false),
    canManagePermissions: z.boolean().default(false),
  }).default({}),
  transactions: z.object({
    canViewAllTransactions: z.boolean().default(false),
    canEditTransactions: z.boolean().default(false),
    canDeleteTransactions: z.boolean().default(false),
  }).default({}),
  vehicles: z.object({
    canViewVehicles: z.boolean().default(true),
    canCreateVehicles: z.boolean().default(false),
    canEditVehicles: z.boolean().default(false),
    canDeleteVehicles: z.boolean().default(false),
  }).default({}),
  tanks: z.object({
    canViewTanks: z.boolean().default(true),
    canEditTankLevels: z.boolean().default(false),
    canCreateTanks: z.boolean().default(false),
    canDeleteTanks: z.boolean().default(false),
  }).default({}),
}).default({});

// Role templates schema for predefined role permissions
export const roleTemplatesSchema = z.object({
  driver: z.object({
    name: z.string().default("Driver"),
    description: z.string().default("Standard driver access with basic transaction logging"),
    permissions: userPermissionsSchema.default({}),
  }),
  administrator: z.object({
    name: z.string().default("Administrator"),
    description: z.string().default("Fleet management with full administrative access"),
    permissions: userPermissionsSchema.default({
      systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: false },
      userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: false, canManagePermissions: true },
      transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
      vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
      tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: false, canDeleteTanks: false },
    }),
  }),
  developer: z.object({
    name: z.string().default("Developer"),
    description: z.string().default("Full system access with development privileges"),
    permissions: userPermissionsSchema.default({
      systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: true },
      userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: true, canManagePermissions: true },
      transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
      vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
      tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: true, canDeleteTanks: true },
    }),
  }),
});

// User role template assignment schema
export const updateUserRoleSchema = z.object({
  role: z.enum(["driver", "administrator", "developer"]),
  customPermissions: userPermissionsSchema.optional(),
});

// Dashboard widget schemas
export const tankWidgetSchema = z.object({
  tankId: z.string(),
  showLevel: z.boolean().default(true),
  showPercentage: z.boolean().default(true),
  showCapacity: z.boolean().default(false),
  alertThreshold: z.number().min(0).max(100).default(25),
});

export const dashboardWidgetsSchema = z.object({
  tankWidgets: z.array(tankWidgetSchema).default([]),
  showTransactionStats: z.boolean().default(true),
  showQuickActions: z.boolean().default(true),
});

export type TankWidget = z.infer<typeof tankWidgetSchema>;
export type DashboardWidgets = z.infer<typeof dashboardWidgetsSchema>;
export type UserPermissions = z.infer<typeof userPermissionsSchema>;
export type RoleTemplates = z.infer<typeof roleTemplatesSchema>;
export type UpdateUserRole = z.infer<typeof updateUserRoleSchema>;

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  stayLoggedIn: z.boolean().default(false),
});

export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
});

export const insertVehicleSchema = createInsertSchema(vehicles);

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  submittedAt: true,
}).extend({
  gallons: z.coerce.number().positive(),
  cost: z.coerce.number().min(0).default(0),
  odometer: z.coerce.number().positive(),
  location: z.string().default("Tampa Yard"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;

export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;

export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Vehicle = typeof vehicles.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

// Tank levels table
export const tankLevels = pgTable("tank_levels", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // "diesel" or "def"
  location: text("location").notNull(), // "Tampa Yard" or "Elmer Yard"
  currentLevel: decimal("current_level", { precision: 10, scale: 2 }).notNull(),
  capacity: decimal("capacity", { precision: 10, scale: 2 }).notNull(),
  unit: text("unit").notNull().default("gallons"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export type TankLevel = typeof tankLevels.$inferSelect;
export type InsertTankLevel = typeof tankLevels.$inferInsert;

export const insertTankLevelSchema = createInsertSchema(tankLevels).omit({
  id: true,
  lastUpdated: true,
});

export const updateTankLevelSchema = createInsertSchema(tankLevels).omit({
  id: true,
  lastUpdated: true,
}).partial();

export const updateTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  submittedAt: true,
}).extend({
  gallons: z.coerce.number().positive(),
  cost: z.coerce.number().min(0).default(0),
  odometer: z.coerce.number().positive(),
}).partial();

// System logs table for audit trail
export const systemLogs = pgTable("system_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  username: text("username").notNull(),
  action: text("action").notNull(),
  details: text("details"),
  ipAddress: text("ip_address").notNull(),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type SystemLog = typeof systemLogs.$inferSelect;
export type InsertSystemLog = typeof systemLogs.$inferInsert;

export const insertSystemLogSchema = createInsertSchema(systemLogs).omit({
  id: true,
  timestamp: true,
});

// System settings table for global app configuration
export const systemSettings = pgTable("system_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
  updatedBy: varchar("updated_by").references(() => users.id),
});

export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});
