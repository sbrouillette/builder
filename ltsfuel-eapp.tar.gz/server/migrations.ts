import { pool } from "./db";
import { storage } from "./storage";
import fs from "fs";
import path from "path";

export interface MigrationFile {
  filename: string;
  version: string;
  description: string;
  sql: string;
  rollback?: string;
}

export interface MigrationResult {
  success: boolean;
  appliedMigrations: string[];
  errors: string[];
  rollbackAvailable: boolean;
}

export class DatabaseMigrationManager {
  private migrationsDir: string;

  constructor(migrationsDir: string = path.join(process.cwd(), 'tmp', 'migrations')) {
    this.migrationsDir = migrationsDir;
    this.ensureMigrationsDirectory();
    this.ensureMigrationsTable();
  }

  private ensureMigrationsDirectory() {
    if (!fs.existsSync(this.migrationsDir)) {
      fs.mkdirSync(this.migrationsDir, { recursive: true });
    }
  }

  private async ensureMigrationsTable() {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS schema_migrations (
          id SERIAL PRIMARY KEY,
          version VARCHAR(255) UNIQUE NOT NULL,
          filename VARCHAR(255) NOT NULL,
          description TEXT,
          applied_at TIMESTAMP DEFAULT NOW(),
          rollback_sql TEXT,
          applied_by VARCHAR(255)
        )
      `);
    } catch (error) {
      console.error("Failed to create migrations table:", error);
    }
  }

  async getAppliedMigrations(): Promise<string[]> {
    try {
      const result = await pool.query(
        "SELECT version FROM schema_migrations ORDER BY applied_at ASC"
      );
      return result.rows.map(row => row.version);
    } catch (error) {
      console.error("Failed to get applied migrations:", error);
      return [];
    }
  }

  async getPendingMigrations(): Promise<MigrationFile[]> {
    const appliedMigrations = await this.getAppliedMigrations();
    const migrationFiles = this.loadMigrationFiles();
    
    return migrationFiles.filter(migration => 
      !appliedMigrations.includes(migration.version)
    ).sort((a, b) => a.version.localeCompare(b.version));
  }

  private loadMigrationFiles(): MigrationFile[] {
    const migrations: MigrationFile[] = [];
    
    if (!fs.existsSync(this.migrationsDir)) {
      return migrations;
    }

    const files = fs.readdirSync(this.migrationsDir)
      .filter(file => file.endsWith('.sql'))
      .sort();

    for (const file of files) {
      try {
        const filePath = path.join(this.migrationsDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        
        // Parse migration file
        const migration = this.parseMigrationFile(file, content);
        if (migration) {
          migrations.push(migration);
        }
      } catch (error) {
        console.error(`Failed to load migration file ${file}:`, error);
      }
    }

    return migrations;
  }

  private parseMigrationFile(filename: string, content: string): MigrationFile | null {
    try {
      // Extract version from filename (format: YYYYMMDD_HHMMSS_description.sql)
      const versionMatch = filename.match(/^(\d{8}_\d{6})_(.+)\.sql$/);
      if (!versionMatch) {
        console.warn(`Invalid migration filename format: ${filename}`);
        return null;
      }

      const version = versionMatch[1];
      const description = versionMatch[2].replace(/_/g, ' ');

      // Split content into UP and DOWN migrations
      const sections = content.split(/-- DOWN MIGRATION|-- ROLLBACK/i);
      const sql = sections[0].replace(/-- UP MIGRATION/i, '').trim();
      const rollback = sections[1] ? sections[1].trim() : undefined;

      return {
        filename,
        version,
        description,
        sql,
        rollback
      };
    } catch (error) {
      console.error(`Failed to parse migration file ${filename}:`, error);
      return null;
    }
  }

  async applyMigrations(userId: string): Promise<MigrationResult> {
    const result: MigrationResult = {
      success: true,
      appliedMigrations: [],
      errors: [],
      rollbackAvailable: true
    };

    const pendingMigrations = await this.getPendingMigrations();
    
    if (pendingMigrations.length === 0) {
      return result;
    }

    // Begin transaction for all migrations
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');

      for (const migration of pendingMigrations) {
        try {
          console.log(`Applying migration: ${migration.filename}`);
          
          // Execute the migration SQL
          await client.query(migration.sql);
          
          // Record the migration as applied
          await client.query(`
            INSERT INTO schema_migrations (version, filename, description, rollback_sql, applied_by)
            VALUES ($1, $2, $3, $4, $5)
          `, [
            migration.version,
            migration.filename, 
            migration.description,
            migration.rollback || null,
            userId
          ]);

          result.appliedMigrations.push(migration.filename);
          
          // Log the migration application
          await storage.createSystemLog({
            userId,
            username: 'system',
            action: 'DATABASE_MIGRATION_APPLIED',
            details: `Applied migration: ${migration.filename} - ${migration.description}`,
            ipAddress: 'localhost',
            userAgent: 'system-update'
          });

        } catch (error) {
          const errorMsg = `Failed to apply migration ${migration.filename}: ${error instanceof Error ? error.message : 'Unknown error'}`;
          result.errors.push(errorMsg);
          result.success = false;
          console.error(errorMsg);
          break; // Stop on first error
        }
      }

      if (result.success) {
        await client.query('COMMIT');
        console.log(`Successfully applied ${result.appliedMigrations.length} migrations`);
      } else {
        await client.query('ROLLBACK');
        console.log('Rolled back migrations due to errors');
      }

    } catch (error) {
      await client.query('ROLLBACK');
      result.success = false;
      result.errors.push(`Transaction failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      client.release();
    }

    return result;
  }

  async rollbackLastMigration(userId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const client = await pool.connect();
      
      try {
        // Get the last applied migration
        const result = await client.query(`
          SELECT * FROM schema_migrations 
          ORDER BY applied_at DESC 
          LIMIT 1
        `);

        if (result.rows.length === 0) {
          return { success: false, error: "No migrations to rollback" };
        }

        const lastMigration = result.rows[0];
        
        if (!lastMigration.rollback_sql) {
          return { success: false, error: "No rollback SQL available for the last migration" };
        }

        await client.query('BEGIN');

        // Execute rollback SQL
        await client.query(lastMigration.rollback_sql);
        
        // Remove migration record
        await client.query(
          "DELETE FROM schema_migrations WHERE version = $1",
          [lastMigration.version]
        );

        await client.query('COMMIT');

        // Log the rollback
        await storage.createSystemLog({
          userId,
          username: 'system',
          action: 'DATABASE_MIGRATION_ROLLBACK',
          details: `Rolled back migration: ${lastMigration.filename}`,
          ipAddress: 'localhost',
          userAgent: 'system-update'
        });

        return { success: true };

      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }

    } catch (error) {
      return { 
        success: false, 
        error: `Rollback failed: ${error instanceof Error ? error.message : 'Unknown error'}` 
      };
    }
  }

  async createBackup(): Promise<{ success: boolean; backupPath?: string; error?: string }> {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupDir = path.join(process.cwd(), 'tmp', 'backups');
      
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true });
      }

      const backupPath = path.join(backupDir, `database-backup-${timestamp}.sql`);
      
      // For PostgreSQL, you would typically use pg_dump
      // This is a simplified version that saves the schema_migrations table
      const result = await pool.query(`
        SELECT version, filename, description, applied_at, applied_by 
        FROM schema_migrations 
        ORDER BY applied_at ASC
      `);

      const backupContent = [
        '-- Database Backup Created: ' + new Date().toISOString(),
        '-- Applied Migrations:',
        ...result.rows.map(row => 
          `-- ${row.version}: ${row.filename} (${row.description}) - Applied by ${row.applied_by} at ${row.applied_at}`
        ),
        '',
        '-- To restore migrations table:',
        'CREATE TABLE IF NOT EXISTS schema_migrations (',
        '  id SERIAL PRIMARY KEY,',
        '  version VARCHAR(255) UNIQUE NOT NULL,',
        '  filename VARCHAR(255) NOT NULL,',
        '  description TEXT,',
        '  applied_at TIMESTAMP DEFAULT NOW(),',
        '  rollback_sql TEXT,',
        '  applied_by VARCHAR(255)',
        ');',
        ''
      ].join('\n');

      fs.writeFileSync(backupPath, backupContent);

      return { success: true, backupPath };

    } catch (error) {
      return { 
        success: false, 
        error: `Backup failed: ${error instanceof Error ? error.message : 'Unknown error'}` 
      };
    }
  }

  async getMigrationStatus(): Promise<{
    appliedCount: number;
    pendingCount: number;
    lastMigration?: string;
    canRollback: boolean;
  }> {
    const applied = await this.getAppliedMigrations();
    const pending = await this.getPendingMigrations();
    
    let lastMigration: string | undefined;
    let canRollback = false;

    if (applied.length > 0) {
      try {
        const result = await pool.query(`
          SELECT filename, rollback_sql FROM schema_migrations 
          ORDER BY applied_at DESC 
          LIMIT 1
        `);
        
        if (result.rows.length > 0) {
          lastMigration = result.rows[0].filename;
          canRollback = !!result.rows[0].rollback_sql;
        }
      } catch (error) {
        console.error("Failed to get last migration:", error);
      }
    }

    return {
      appliedCount: applied.length,
      pendingCount: pending.length,
      lastMigration,
      canRollback
    };
  }
}

export const migrationManager = new DatabaseMigrationManager();