import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { User as AppUser } from "@shared/schema";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

declare global {
  namespace Express {
    interface User extends AppUser {}
  }
}

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  return bcrypt.compare(supplied, stored);
}

export function setupAuth(app: Express) {
  const PostgresSessionStore = connectPg(session);
  
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || 'lee-transport-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    store: new PostgresSessionStore({ 
      pool: pool, 
      createTableIfMissing: true 
    }),
    cookie: {
      secure: false, // Set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        const isValid = await comparePasswords(password, user.password);
        if (!isValid) {
          return done(null, false, { message: "Invalid username or password" });
        }

        // Check if user account is locked out
        if (user.status === "locked_out") {
          return done(null, false, { message: "Account locked out. Please contact your terminal manager." });
        }

        // Check maintenance mode - only developers can login during maintenance
        const maintenanceMode = await storage.getSystemSetting("maintenance_mode_enabled");
        if (maintenanceMode?.value === "true" && user.role !== "developer") {
          return done(null, false, { message: "System under maintenance" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Maintenance mode middleware
  async function checkMaintenanceMode(req: any, res: any, next: any) {
    try {
      const maintenanceMode = await storage.getSystemSetting("maintenance_mode_enabled");
      if (maintenanceMode?.value === "true" && req.user && req.user.role !== "developer") {
        // Force logout non-developer users during maintenance
        req.logout((err: any) => {
          if (err) {
            console.error('Logout error during maintenance mode:', err);
          }
        });
        return res.status(503).json({ error: "System under maintenance", forceLogout: true });
      }
      next();
    } catch (error) {
      console.error('Maintenance mode check error:', error);
      next();
    }
  }

  // Authentication middleware
  function requireAuth(req: any, res: any, next: any) {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ error: "Authentication required" });
  }

  function requireAdmin(req: any, res: any, next: any) {
    if (req.isAuthenticated() && (req.user.role === "administrator" || req.user.role === "developer")) {
      return next();
    }
    res.status(403).json({ error: "Administrator access required" });
  }

  // Helper functions for developer role permissions
  function hasAdminPermissions(user: any) {
    return user && (user.role === "administrator" || user.role === "developer");
  }

  function canModifyUser(currentUser: any, targetUser: any) {
    // Developers cannot be modified by administrators
    if (targetUser.role === "developer" && currentUser.role === "administrator") {
      return false;
    }
    // Only developers or the user themselves can modify developer accounts
    if (targetUser.role === "developer" && currentUser.role !== "developer" && currentUser.id !== targetUser.id) {
      return false;
    }
    return true;
  }

  // Auth routes
  app.post("/api/register", requireAdmin, async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      const hashedPassword = await hashPassword(req.body.password);
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
      });

      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ 
          error: info?.message || "Invalid username or password" 
        });
      }
      req.logIn(user, async (err) => {
        if (err) {
          return next(err);
        }
        
        // Handle "Stay logged in" functionality
        const { stayLoggedIn } = req.body;
        if (stayLoggedIn) {
          // Set session to expire in 30 days
          req.session.cookie.maxAge = 30 * 24 * 60 * 60 * 1000; // 30 days
        } else {
          // Default session expires when browser closes
          req.session.cookie.maxAge = 24 * 60 * 60 * 1000; // 24 hours
        }
        
        // Log the successful login
        const ipAddress = req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 'unknown';
        const userAgent = req.get('User-Agent') || 'unknown';
        
        try {
          await storage.createSystemLog({
            userId: user.id,
            username: user.username,
            action: 'USER_LOGIN',
            details: `Successful login${stayLoggedIn ? ' (Stay logged in enabled)' : ''}`,
            ipAddress,
            userAgent,
          });
        } catch (logError) {
          console.error('Failed to log login:', logError);
        }
        
        const { password, ...userWithoutPassword } = user;
        return res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", async (req, res, next) => {
    const user = req.user;
    
    req.logout(async (err) => {
      if (err) return next(err);
      
      // Log the logout
      if (user) {
        const ipAddress = req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 'unknown';
        const userAgent = req.get('User-Agent') || 'unknown';
        
        try {
          await storage.createSystemLog({
            userId: user.id,
            username: user.username,
            action: 'USER_LOGOUT',
            details: `User logged out`,
            ipAddress,
            userAgent,
          });
        } catch (logError) {
          console.error('Failed to log logout:', logError);
        }
      }
      
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.sendStatus(401);
    }
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });

  // User management routes (admin only)
  app.get("/api/users", requireAdmin, async (req, res, next) => {
    try {
      const users = await storage.getAllUsers();
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      next(error);
    }
  });

  app.put("/api/users/:id", requireAdmin, async (req, res, next) => {
    try {
      const { id } = req.params;
      const updates = { ...req.body };
      const currentUser = req.user;
      
      // Get the target user to check permissions
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ error: "User not found" });
      }

      // Check if current user can modify this user
      if (!currentUser || !canModifyUser(currentUser, targetUser)) {
        return res.status(403).json({ error: "Cannot modify this user account" });
      }

      // Prevent administrators from changing role to developer
      if (updates.role === "developer" && currentUser.role === "administrator") {
        return res.status(403).json({ error: "Cannot assign developer role" });
      }

      // Prevent administrators from modifying user status
      if (updates.status && currentUser && currentUser.role === "administrator") {
        return res.status(403).json({ error: "Cannot modify user status" });
      }
      
      if (updates.password) {
        updates.password = await hashPassword(updates.password);
      }
      
      const user = await storage.updateUser(id, updates);
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/users/:id", requireAdmin, async (req, res, next) => {
    try {
      const { id } = req.params;
      const currentUser = req.user;
      
      // Only developers can delete users
      if (!currentUser || currentUser.role !== "developer") {
        return res.status(403).json({ error: "Only developers can delete user accounts" });
      }
      
      // Prevent deleting themselves
      if (currentUser && currentUser.id === id) {
        return res.status(400).json({ error: "Cannot delete your own account" });
      }

      // Get the target user to check permissions
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ error: "User not found" });
      }
      
      await storage.deleteUser(id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // Bulk delete users (developer only)
  app.delete("/api/users/bulk", requireAdmin, async (req, res, next) => {
    try {
      const { userIds } = req.body;
      const currentUser = req.user;
      
      // Only developers can bulk delete users
      if (currentUser.role !== "developer") {
        return res.status(403).json({ error: "Only developers can bulk delete user accounts" });
      }
      
      if (!Array.isArray(userIds) || userIds.length === 0) {
        return res.status(400).json({ error: "Invalid user IDs provided" });
      }

      // Prevent deleting themselves
      if (userIds.includes(currentUser.id)) {
        return res.status(400).json({ error: "Cannot delete your own account" });
      }
      
      await storage.deleteUsers(userIds);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  });

  // CSV upload for bulk user operations (developer only)
  app.post("/api/users/csv-upload", requireAdmin, async (req, res, next) => {
    try {
      const currentUser = req.user;
      
      // Only developers can upload CSV
      if (!currentUser || currentUser.role !== "developer") {
        return res.status(403).json({ error: "Only developers can upload user data" });
      }
      
      const { users: csvUsers } = req.body;
      
      if (!Array.isArray(csvUsers)) {
        return res.status(400).json({ error: "Invalid CSV data" });
      }
      
      const results = await storage.bulkUpsertUsers(csvUsers);
      res.json(results);
    } catch (error) {
      next(error);
    }
  });

  // CSV download for user export (developer only)
  app.get("/api/users/csv-export", requireAdmin, async (req, res, next) => {
    try {
      const currentUser = req.user;
      
      // Only developers can export CSV
      if (!currentUser || currentUser.role !== "developer") {
        return res.status(403).json({ error: "Only developers can export user data" });
      }
      
      const users = await storage.getAllUsers();
      const csvData = users.map(({ password, ...user }) => user);
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="users.csv"');
      res.json(csvData);
    } catch (error) {
      next(error);
    }
  });

  return { requireAuth, requireAdmin, checkMaintenanceMode };
}