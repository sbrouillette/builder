import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth, hashPassword } from "./auth";
import { storage } from "./storage";
import { insertTransactionSchema, insertTankLevelSchema, updateTankLevelSchema, updateTransactionSchema, insertUserSchema, insertVehicleSchema, roleTemplatesSchema, updateUserRoleSchema, userPermissionsSchema } from "@shared/schema";
import { createTransport } from "nodemailer";
import multer from "multer";
import path from "path";
import fs from "fs";
import { promisify } from "util";
import { migrationManager } from "./migrations";

export async function registerRoutes(app: Express): Promise<Server> {
  const { requireAuth, checkMaintenanceMode } = setupAuth(app);

  // Helper function to log system actions
  const logAction = async (req: any, action: string, details?: string) => {
    try {
      if (req.user) {
        const ipAddress = req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 'unknown';
        const userAgent = req.get('User-Agent') || 'unknown';
        
        await storage.createSystemLog({
          userId: req.user.id,
          username: req.user.username,
          action,
          details,
          ipAddress,
          userAgent,
        });
      }
    } catch (error) {
      console.error('Failed to log action:', error);
    }
  };
  // Configure email transport
  const transporter = createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: parseInt(process.env.SMTP_PORT || "587"),
    secure: false,
    auth: {
      user: process.env.SMTP_USER || process.env.EMAIL_USER,
      pass: process.env.SMTP_PASS || process.env.EMAIL_PASS,
    },
  });

  // Get all employees
  app.get("/api/employees", async (req, res) => {
    try {
      const employees = await storage.getAllEmployees();
      res.json(employees);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  // Get current employee (now using authentication)
  app.get("/api/employee/current", requireAuth, checkMaintenanceMode, async (req, res) => {
    try {
      // For now, create a compatible employee object from user data
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const employee = {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      };
      
      res.json(employee);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch current employee" });
    }
  });

  // Get all vehicles
  app.get("/api/vehicles", requireAuth, checkMaintenanceMode, async (req, res) => {
    try {
      const vehicles = await storage.getAllVehicles();
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  // Get transactions for current employee or all (admin)
  app.get("/api/transactions", requireAuth, checkMaintenanceMode, async (req, res) => {
    try {
      const isAdmin = req.query.admin === "true";
      const user = req.user;
      
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      if (isAdmin && (user.role === "administrator" || user.role === "developer")) {
        // Admin view - all transactions with employee and vehicle details
        const transactions = await storage.getTransactionsWithDetails();
        res.json(transactions);
      } else {
        // Driver view - their transactions only
        const transactions = await storage.getTransactionsByEmployee(user.id);
        res.json(transactions);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Submit transaction
  app.post("/api/transactions", requireAuth, checkMaintenanceMode, async (req, res) => {
    try {
      // Validate request body
      const validatedData = insertTransactionSchema.parse(req.body);
      
      // Get authenticated user details for email
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Create employee object from authenticated user
      const employee = {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      };

      // For vehicle, try to find by ID first, then by name/unit number
      let vehicle = await storage.getVehicle(validatedData.vehicleId);
      if (!vehicle) {
        // Try to find by name or partial match
        const allVehicles = await storage.getAllVehicles();
        vehicle = allVehicles.find(v => 
          v.name.toLowerCase().includes(validatedData.vehicleId.toLowerCase()) ||
          v.id.toLowerCase().includes(validatedData.vehicleId.toLowerCase())
        );
      }
      
      // If still no vehicle found, create a placeholder for email purposes
      if (!vehicle) {
        vehicle = {
          id: validatedData.vehicleId,
          name: `Unit ${validatedData.vehicleId}`,
          model: "Unknown Model"
        };
      }

      // Create transaction
      const transaction = await storage.createTransaction(validatedData);
      
      // Update tank levels based on the transaction
      await storage.updateTankLevelFromTransaction(
        validatedData.type === "fuel" ? "diesel" : "def",
        validatedData.location,
        parseFloat(validatedData.gallons.toString())
      );

      // Send email notification
      try {
        const emailSubject = `Lee Transport Systems - ${transaction.type.toUpperCase()} Transaction Submitted`;
        const emailBody = `
New ${transaction.type.toUpperCase()} Transaction Submitted

Employee: ${employee.name}
Vehicle: ${vehicle.name} (${vehicle.model})
${transaction.type === 'fuel' ? `Fuel Type: ${transaction.fuelType}` : ''}
Gallons: ${transaction.gallons}
Total Cost: $${transaction.cost}
Location: ${transaction.location}
Odometer Reading: ${transaction.odometer} miles
Date: ${transaction.date}
Time: ${transaction.time}
${transaction.notes ? `Notes: ${transaction.notes}` : ''}

Submitted at: ${new Date(transaction.submittedAt!).toLocaleString()}

--
Lee Transport Systems Fleet Management
        `.trim();

        await transporter.sendMail({
          from: process.env.SMTP_USER || process.env.EMAIL_USER,
          to: process.env.COMPANY_EMAIL || "admin@leetransport.com",
          subject: emailSubject,
          text: emailBody,
        });
      } catch (emailError) {
        console.error("Failed to send email notification:", emailError);
        // Continue even if email fails - transaction is still saved
      }

      // Log the action
      await logAction(
        req, 
        `CREATE_TRANSACTION_${validatedData.type.toUpperCase()}`,
        `Created ${validatedData.type} transaction: ${validatedData.gallons} gallons at ${validatedData.location} for vehicle ${validatedData.vehicleId}`
      );

      res.json(transaction);
    } catch (error) {
      console.error("Transaction submission error:", error);
      res.status(400).json({ message: "Invalid transaction data" });
    }
  });

  // Get transaction statistics
  app.get("/api/transactions/stats", requireAuth, async (req, res) => {
    try {
      const isAdmin = req.query.admin === "true";
      const user = req.user;
      
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      if (isAdmin && (user.role === "administrator" || user.role === "developer")) {
        // Admin stats - all transactions
        const allTransactions = await storage.getAllTransactions();
        
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        
        const thisMonthTransactions = allTransactions.filter(t => {
          const transactionDate = new Date(t.submittedAt!);
          return transactionDate.getMonth() === currentMonth && 
                 transactionDate.getFullYear() === currentYear;
        });

        const fuelTransactions = thisMonthTransactions.filter(t => t.type === 'fuel').length;
        const defTransactions = thisMonthTransactions.filter(t => t.type === 'def').length;
        const totalEmployees = (await storage.getEmployeesByRole("driver")).length;
        const totalVehicles = (await storage.getAllVehicles()).length;

        res.json({
          fuelTransactions,
          defTransactions,
          totalEmployees,
          totalVehicles,
          totalTransactions: thisMonthTransactions.length,
        });
      } else {
        // Driver stats - their transactions only
        const user = req.user;
        if (!user) {
          return res.status(401).json({ message: "Not authenticated" });
        }

        const transactions = await storage.getTransactionsByEmployee(user.id);
        
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        
        const thisMonthTransactions = transactions.filter(t => {
          const transactionDate = new Date(t.submittedAt!);
          return transactionDate.getMonth() === currentMonth && 
                 transactionDate.getFullYear() === currentYear;
        });

        const fuelTransactions = thisMonthTransactions.filter(t => t.type === 'fuel').length;
        const defTransactions = thisMonthTransactions.filter(t => t.type === 'def').length;

        res.json({
          fuelTransactions,
          defTransactions,
        });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Get all tank levels
  app.get("/api/tank-levels", async (req, res) => {
    try {
      const tanks = await storage.getAllTankLevels();
      res.json(tanks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tank levels" });
    }
  });

  // Update tank level
  app.put("/api/tank-levels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = updateTankLevelSchema.parse(req.body);
      
      const updatedTank = await storage.updateTankLevel(id, validatedData);
      res.json(updatedTank);
    } catch (error) {
      console.error("Tank level update error:", error);
      res.status(400).json({ message: "Invalid tank level data" });
    }
  });

  // Get all tank levels (admin)
  app.get("/api/tank-levels", async (req, res) => {
    try {
      const tankLevels = await storage.getAllTankLevels();
      res.json(tankLevels);
    } catch (error) {
      console.error("Tank levels fetch error:", error);
      res.status(500).json({ message: "Failed to fetch tank levels" });
    }
  });

  // Tank levels for drivers (filtered by user permissions)
  app.get("/api/tank-levels/driver", requireAuth, checkMaintenanceMode, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const tankLevels = await storage.getTankLevelsForUser(user.id);
      res.json(tankLevels);
    } catch (error) {
      console.error("Driver tank levels fetch error:", error);
      res.status(500).json({ message: "Failed to fetch tank levels" });
    }
  });

  // Create new tank level (Developer only)
  app.post("/api/tank-levels", requireAuth, checkMaintenanceMode, async (req, res) => {
    try {
      const user = req.user;
      
      // Only developers can create tanks
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const validatedData = insertTankLevelSchema.parse(req.body);
      const tank = await storage.createTankLevel(validatedData);
      res.json(tank);
    } catch (error) {
      console.error("Tank level creation error:", error);
      res.status(400).json({ message: "Invalid tank level data" });
    }
  });

  // Delete tank level (Developer only)
  app.delete("/api/tank-levels/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      // Only developers can delete tanks
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const deleted = await storage.deleteTankLevel(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Tank not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Tank deletion error:", error);
      res.status(500).json({ message: "Failed to delete tank" });
    }
  });

  // Update transaction (Admin only)
  app.put("/api/transactions/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      // Only administrators and developers can update transactions
      if (user?.role !== "administrator" && user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }
      
      const validatedData = updateTransactionSchema.parse(req.body);
      // Convert number fields to strings for database compatibility
      const dataForStorage = {
        ...validatedData,
        gallons: validatedData.gallons?.toString(),
        cost: validatedData.cost?.toString(),
      };
      const updatedTransaction = await storage.updateTransaction(id, dataForStorage);
      
      if (!updatedTransaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      res.json(updatedTransaction);
    } catch (error) {
      console.error("Transaction update error:", error);
      res.status(400).json({ message: "Invalid transaction data" });
    }
  });

  // Delete transaction (Admin only)
  app.delete("/api/transactions/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      // Only administrators and developers can delete transactions
      if (user?.role !== "administrator" && user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }
      
      const deleted = await storage.deleteTransaction(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Transaction deletion error:", error);
      res.status(500).json({ message: "Failed to delete transaction" });
    }
  });

  // User management endpoints (Admin only)
  app.get("/api/users", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "administrator" && user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }
      
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Users fetch error:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Update user (Admin only)
  app.put("/api/users/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      if (user?.role !== "administrator" && user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }
      
      // Get the target user to check their role
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only developers can modify other developers
      if (targetUser.role === "developer" && user?.role !== "developer") {
        return res.status(403).json({ message: "Cannot modify developer accounts. Developer role required." });
      }
      
      const updateData = req.body;
      const updatedUser = await storage.updateUser(id, updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("User update error:", error);
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Update user tank visibility
  app.put("/api/users/:id/tank-visibility", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      const { id } = req.params;
      const { visibleTanks } = req.body;
      
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Check permissions - only admins and developers can modify tank visibility
      if (user.role === "driver") {
        return res.status(403).json({ message: "Access denied. Admin role required." });
      }
      
      // Get the target user
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Administrators cannot edit developer accounts
      if (user.role === "administrator" && targetUser.role === "developer") {
        return res.status(403).json({ message: "Cannot modify developer accounts" });
      }
      
      // Log the tank visibility update
      await logAction(
        req, 
        'TANK_VISIBILITY_UPDATE',
        `Updated tank visibility for ${targetUser.username}: ${visibleTanks.length} tanks visible`
      );
      
      const updatedUser = await storage.updateUserTankVisibility(id, visibleTanks);
      const { password, ...userResponse } = updatedUser;
      res.json(userResponse);
    } catch (error) {
      console.error("Tank visibility update error:", error);
      res.status(500).json({ message: "Failed to update tank visibility" });
    }
  });

  // Update user dashboard widgets
  app.put("/api/user/dashboard-widgets", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const { dashboardWidgets } = req.body;
      
      // Validate the dashboard widgets data
      if (typeof dashboardWidgets !== 'string') {
        return res.status(400).json({ message: "Invalid dashboard widgets data" });
      }
      
      // Parse to validate JSON structure
      try {
        JSON.parse(dashboardWidgets);
      } catch (e) {
        return res.status(400).json({ message: "Invalid JSON format for dashboard widgets" });
      }
      
      // Log the dashboard widgets update
      await logAction(
        req, 
        'DASHBOARD_WIDGETS_UPDATE',
        `Updated dashboard widgets configuration`
      );
      
      const updatedUser = await storage.updateUserDashboardWidgets(user.id, dashboardWidgets);
      const { password, ...userResponse } = updatedUser;
      res.json(userResponse);
    } catch (error) {
      console.error("Dashboard widgets update error:", error);
      res.status(500).json({ message: "Failed to update dashboard widgets" });
    }
  });

  // Delete user (Developer only)
  app.delete("/api/users/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      // Only developers can delete users
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      if (user.id === id) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      await storage.deleteUser(id);
      
      res.status(204).send();
    } catch (error) {
      console.error("User deletion error:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Vehicle management endpoints (Admin only)
  app.post("/api/vehicles", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "administrator" && user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }
      
      const validatedData = insertVehicleSchema.parse(req.body);
      const vehicle = await storage.createVehicle(validatedData);
      res.json(vehicle);
    } catch (error) {
      console.error("Vehicle creation error:", error);
      res.status(400).json({ message: "Invalid vehicle data" });
    }
  });

  app.put("/api/vehicles/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      if (user?.role !== "administrator" && user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }
      
      const vehicleData = insertVehicleSchema.parse(req.body);
      
      // If ID is being changed, handle it specially
      if (vehicleData.id !== id) {
        // Delete old vehicle and create new one with new ID
        const existingVehicle = await storage.getVehicle(id);
        if (!existingVehicle) {
          return res.status(404).json({ message: "Vehicle not found" });
        }
        
        await storage.deleteVehicle(id);
        const newVehicle = await storage.createVehicle(vehicleData);
        res.json(newVehicle);
      } else {
        const updatedVehicle = await storage.updateVehicle(id, vehicleData);
        if (!updatedVehicle) {
          return res.status(404).json({ message: "Vehicle not found" });
        }
        res.json(updatedVehicle);
      }
    } catch (error) {
      console.error("Error updating vehicle:", error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to update vehicle" });
    }
  });

  app.delete("/api/vehicles/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      if (user?.role !== "administrator" && user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Administrator role required." });
      }
      
      await storage.deleteVehicle(id);
      res.status(204).send();
    } catch (error) {
      console.error("Vehicle deletion error:", error);
      res.status(500).json({ message: "Failed to delete vehicle" });
    }
  });

  // Bulk delete users (Developer only)
  app.post("/api/users/bulk-delete", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const { userIds } = req.body;
      
      if (!Array.isArray(userIds)) {
        return res.status(400).json({ message: "userIds must be an array" });
      }
      
      // Prevent self-deletion
      if (userIds.includes(user.id)) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      for (const userId of userIds) {
        await storage.deleteUser(userId);
      }
      
      res.json({ deleted: userIds.length });
    } catch (error) {
      console.error("Bulk delete error:", error);
      res.status(500).json({ message: "Failed to delete users" });
    }
  });

  // CSV upload for bulk user creation (Developer only)
  app.post("/api/users/csv-upload", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const { users } = req.body;
      
      if (!Array.isArray(users)) {
        return res.status(400).json({ message: "users must be an array" });
      }
      
      let created = 0;
      let updated = 0;
      const errors = [];
      
      for (const userData of users) {
        try {
          const existingUser = await storage.getUserByUsername(userData.username);
          
          if (existingUser) {
            // Update existing user
            await storage.updateUser(existingUser.id, userData);
            updated++;
          } else {
            // Create new user
            const hashedPassword = await hashPassword(userData.password || 'temp123');
            await storage.createUser({
              ...userData,
              password: hashedPassword,
            });
            created++;
          }
        } catch (error) {
          errors.push(`Failed to process user ${userData.username}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }
      
      res.json({ created, updated, errors });
    } catch (error) {
      console.error("CSV upload error:", error);
      res.status(500).json({ message: "Failed to process CSV upload" });
    }
  });

  // System logs endpoint (Developer only)
  app.get("/api/system-logs", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const logs = await storage.getAllSystemLogs();
      res.json(logs);
    } catch (error) {
      console.error("System logs fetch error:", error);
      res.status(500).json({ message: "Failed to fetch system logs" });
    }
  });

  // Manual cleanup endpoint (Developer only)
  app.post("/api/system-logs/cleanup", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const deletedCount = await storage.cleanupOldSystemLogs();
      
      // Log the manual cleanup action
      await logAction(
        req, 
        'MANUAL_LOG_CLEANUP',
        `Manually triggered cleanup: ${deletedCount} logs deleted`
      );
      
      res.json({ deletedCount, message: `Cleaned up ${deletedCount} old system logs` });
    } catch (error) {
      console.error("Manual cleanup error:", error);
      res.status(500).json({ message: "Failed to cleanup system logs" });
    }
  });

  // System settings endpoints (Developer only for full access, administrators with permissions)
  app.get("/api/system-settings", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer" && user?.role !== "administrator") {
        return res.status(403).json({ message: "Access denied. Developer or Administrator role required." });
      }
      
      const settings = await storage.getAllSystemSettings();
      res.json(settings);
    } catch (error) {
      console.error("System settings fetch error:", error);
      res.status(500).json({ message: "Failed to fetch system settings" });
    }
  });

  // Public system settings endpoint for alert banner, welcome message, and maintenance mode
  app.get("/api/system-settings/public", async (req, res) => {
    try {
      const settings = await storage.getAllSystemSettings();
      // Only return specific public settings
      const publicSettings = settings.filter(setting => 
        setting.key === "alert_banner_enabled" || 
        setting.key === "alert_banner_message" || 
        setting.key === "welcome_message" ||
        setting.key === "maintenance_mode_enabled" ||
        setting.key === "company_name"
      );
      res.json(publicSettings);
    } catch (error) {
      console.error("Public system settings fetch error:", error);
      res.status(500).json({ message: "Failed to fetch system settings" });
    }
  });

  app.put("/api/system-settings", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer" && user?.role !== "administrator") {
        return res.status(403).json({ message: "Access denied. Developer or Administrator role required." });
      }
      
      const { key, value, description } = req.body;
      
      if (!key || !value) {
        return res.status(400).json({ message: "Key and value are required" });
      }
      
      // Check permissions for administrators
      if (user?.role === "administrator") {
        try {
          const permissions = user.permissions ? JSON.parse(user.permissions) : {};
          
          if (key === "welcome_message" && !permissions.systemSettings?.canEditWelcomeMessage) {
            return res.status(403).json({ message: "Permission denied. Cannot edit welcome message." });
          }
          
          if ((key === "alert_banner_enabled" || key === "alert_banner_message") && !permissions.systemSettings?.canEditAlertBanner) {
            return res.status(403).json({ message: "Permission denied. Cannot edit alert banner." });
          }
        } catch (e) {
          return res.status(403).json({ message: "Permission denied. Invalid permissions configuration." });
        }
      }
      
      const setting = await storage.upsertSystemSetting({
        key,
        value,
        description,
        updatedBy: user.id,
      });
      
      // Log the system setting update
      await logAction(
        req, 
        'SYSTEM_SETTING_UPDATE',
        `Updated system setting: ${key} = ${value}`
      );
      
      res.json(setting);
    } catch (error) {
      console.error("System setting update error:", error);
      res.status(500).json({ message: "Failed to update system setting" });
    }
  });

  // Update user permissions (Developer only)
  app.put("/api/users/:id/permissions", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const { permissions } = req.body;
      
      if (!permissions) {
        return res.status(400).json({ message: "Permissions data is required" });
      }
      
      // Get the target user to check their role
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only allow updating permissions for administrators
      if (targetUser.role !== "administrator") {
        return res.status(400).json({ message: "Permissions can only be set for administrator accounts" });
      }
      
      const updatedUser = await storage.updateUser(id, { permissions });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Log the permission update
      await logAction(
        req, 
        'USER_PERMISSIONS_UPDATE',
        `Updated permissions for ${targetUser.username}`
      );
      
      const { password, ...userResponse } = updatedUser;
      res.json(userResponse);
    } catch (error) {
      console.error("User permissions update error:", error);
      res.status(500).json({ message: "Failed to update user permissions" });
    }
  });

  // Role Templates and Permission Management Endpoints (Developer only)
  
  // Get all role templates with their default permissions
  app.get("/api/role-templates", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const roleTemplates = roleTemplatesSchema.parse({
        driver: {
          name: "Driver",
          description: "Standard driver access with basic transaction logging",
          permissions: {},
        },
        administrator: {
          name: "Administrator", 
          description: "Fleet management with full administrative access",
          permissions: {
            systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: false },
            userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: false, canManagePermissions: true },
            transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
            vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
            tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: false, canDeleteTanks: false },
          },
        },
        developer: {
          name: "Developer",
          description: "Full system access with development privileges", 
          permissions: {
            systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: true },
            userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: true, canManagePermissions: true },
            transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
            vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
            tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: true, canDeleteTanks: true },
          },
        },
      });
      
      res.json(roleTemplates);
    } catch (error) {
      console.error("Role templates fetch error:", error);
      res.status(500).json({ message: "Failed to fetch role templates" });
    }
  });

  // Apply role template to user (Developer only)
  app.put("/api/users/:id/apply-role", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const { role, customPermissions } = updateUserRoleSchema.parse(req.body);
      
      // Get the target user
      const targetUser = await storage.getUser(id);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Prevent changing developer accounts
      if (targetUser.role === "developer" && user.id !== id) {
        return res.status(403).json({ message: "Cannot modify other developer accounts" });
      }
      
      // Get role template defaults
      const roleTemplates = roleTemplatesSchema.parse({
        driver: { name: "Driver", description: "Standard driver access", permissions: {} },
        administrator: {
          name: "Administrator",
          description: "Fleet management access",
          permissions: {
            systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: false },
            userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: false, canManagePermissions: true },
            transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
            vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
            tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: false, canDeleteTanks: false },
          },
        },
        developer: {
          name: "Developer",
          description: "Full system access",
          permissions: {
            systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: true },
            userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: true, canManagePermissions: true },
            transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
            vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
            tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: true, canDeleteTanks: true },
          },
        },
      });
      
      // Use custom permissions if provided, otherwise use role defaults
      const permissions = customPermissions || roleTemplates[role as keyof typeof roleTemplates].permissions;
      
      const updatedUser = await storage.updateUser(id, {
        role,
        permissions: JSON.stringify(permissions),
      });
      
      // Log the role update
      await logAction(
        req,
        'USER_ROLE_UPDATE',
        `Updated user ${targetUser.username} role to ${role}${customPermissions ? ' with custom permissions' : ''}`
      );
      
      const { password, ...userResponse } = updatedUser;
      res.json(userResponse);
    } catch (error) {
      console.error("User role update error:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Create new user with role and permissions (Developer only)
  app.post("/api/users/create-with-role", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const { username, password, name, email, role, customPermissions } = req.body;
      
      // Validate required fields
      if (!username || !password || !name || !email || !role) {
        return res.status(400).json({ message: "All fields are required" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Get role template defaults
      const roleTemplates = roleTemplatesSchema.parse({
        driver: { name: "Driver", description: "Standard driver access", permissions: {} },
        administrator: {
          name: "Administrator",
          description: "Fleet management access",
          permissions: {
            systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: false },
            userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: false, canManagePermissions: true },
            transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
            vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
            tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: false, canDeleteTanks: false },
          },
        },
        developer: {
          name: "Developer",
          description: "Full system access",
          permissions: {
            systemSettings: { canEditWelcomeMessage: true, canEditAlertBanner: true, canViewSystemLogs: true },
            userManagement: { canViewUsers: true, canCreateUsers: true, canEditUsers: true, canDeleteUsers: true, canManagePermissions: true },
            transactions: { canViewAllTransactions: true, canEditTransactions: true, canDeleteTransactions: true },
            vehicles: { canViewVehicles: true, canCreateVehicles: true, canEditVehicles: true, canDeleteVehicles: true },
            tanks: { canViewTanks: true, canEditTankLevels: true, canCreateTanks: true, canDeleteTanks: true },
          },
        },
      });
      
      // Use custom permissions if provided, otherwise use role defaults
      const permissions = customPermissions || roleTemplates[role as keyof typeof roleTemplates].permissions;
      
      // Hash password and create user
      const hashedPassword = await hashPassword(password);
      const newUser = await storage.createUser({
        username,
        password: hashedPassword,
        name,
        email,
        role,
        permissions: JSON.stringify(permissions),
        status: "active",
        visibleTanks: [],
        dashboardWidgets: '{"tankWidgets":[],"showTransactionStats":true,"showQuickActions":true}',
      });
      
      // Log the user creation
      await logAction(
        req,
        'USER_CREATE_WITH_ROLE',
        `Created new user ${username} with role ${role}`
      );
      
      const { password: _, ...userResponse } = newUser;
      res.json(userResponse);
    } catch (error) {
      console.error("User creation with role error:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // Role template management endpoints (Developer only)
  app.get("/api/role-templates", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const roleTemplates = await storage.getRoleTemplates();
      res.json(roleTemplates);
    } catch (error) {
      console.error("Role templates fetch error:", error);
      res.status(500).json({ message: "Failed to fetch role templates" });
    }
  });

  app.put("/api/role-templates/:roleKey", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      const { roleKey } = req.params;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const { name, description, permissions } = req.body;
      
      if (!name || !description || !permissions) {
        return res.status(400).json({ message: "Name, description, and permissions are required" });
      }
      
      const updatedTemplate = await storage.updateRoleTemplate(roleKey, {
        name,
        description,
        permissions
      }, user.id);
      
      // Log the role template update
      await logAction(
        req,
        'ROLE_TEMPLATE_UPDATE',
        `Updated role template ${roleKey}: ${name}`
      );
      
      res.json(updatedTemplate);
    } catch (error) {
      console.error("Role template update error:", error);
      res.status(500).json({ message: "Failed to update role template" });
    }
  });

  app.post("/api/role-templates", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }
      
      const { name, description, permissions } = req.body;
      
      if (!name || !description || !permissions) {
        return res.status(400).json({ message: "Name, description, and permissions are required" });
      }
      
      // Generate a role key from the name (lowercase, replace spaces with underscores)
      const roleKey = name.toLowerCase().replace(/[^a-z0-9]/g, '_');
      
      const newTemplate = await storage.createRoleTemplate(roleKey, {
        name,
        description,
        permissions
      }, user.id);
      
      // Log the role template creation
      await logAction(
        req,
        'ROLE_TEMPLATE_CREATE',
        `Created new role template ${roleKey}: ${name}`
      );
      
      res.json(newTemplate);
    } catch (error) {
      console.error("Role template creation error:", error);
      res.status(500).json({ message: "Failed to create role template" });
    }
  });

  // System Update API endpoints (Developer only)
  
  // Configure multer for file uploads
  const updateStorage = multer.diskStorage({
    destination: function (req, file, cb) {
      const uploadDir = path.join(process.cwd(), 'tmp', 'updates');
      // Ensure directory exists
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
      // Generate unique filename with timestamp
      const timestamp = Date.now();
      const ext = path.extname(file.originalname);
      cb(null, `update-${timestamp}${ext}`);
    }
  });

  const updateUpload = multer({
    storage: updateStorage,
    limits: {
      fileSize: 100 * 1024 * 1024, // 100MB limit
    },
    fileFilter: function (req, file, cb) {
      // Allow only specific file types
      const allowedMimes = [
        'application/zip',
        'application/x-zip-compressed',
        'application/gzip',
        'application/x-gzip',
        'application/x-tar',
        'application/x-compressed-tar'
      ];
      
      const allowedExtensions = ['.zip', '.tar.gz', '.tgz'];
      const hasValidExtension = allowedExtensions.some(ext => 
        file.originalname.toLowerCase().endsWith(ext)
      );
      
      if (allowedMimes.includes(file.mimetype) || hasValidExtension) {
        cb(null, true);
      } else {
        cb(new Error('Only ZIP, TAR.GZ, and TGZ files are allowed'));
      }
    }
  });

  // Upload system update file
  app.post("/api/system-update/upload", requireAuth, updateUpload.single('updateFile'), async (req, res) => {
    try {
      const user = req.user;
      
      // Only developers can upload system updates
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }

      if (!req.file) {
        return res.status(400).json({ message: "No update file provided" });
      }

      const uploadedFile = req.file;
      
      // Log the system update upload
      await logAction(
        req,
        'SYSTEM_UPDATE_UPLOAD',
        `Uploaded system update file: ${uploadedFile.originalname} (${uploadedFile.size} bytes)`
      );

      // Extract and process the update package
      const extractedContent = await extractUpdatePackage(uploadedFile.path);
      
      res.json({
        success: true,
        message: "Update file uploaded and processed successfully",
        filename: uploadedFile.filename,
        originalName: uploadedFile.originalname,
        size: uploadedFile.size,
        uploadPath: uploadedFile.path,
        containsMigrations: extractedContent.migrations.length > 0,
        migrationsFound: extractedContent.migrations,
        filesExtracted: extractedContent.files.length
      });

    } catch (error) {
      console.error("System update upload error:", error);
      
      // Clean up uploaded file on error
      if (req.file && fs.existsSync(req.file.path)) {
        try {
          fs.unlinkSync(req.file.path);
        } catch (cleanupError) {
          console.error("Failed to cleanup uploaded file:", cleanupError);
        }
      }
      
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to upload update file" 
      });
    }
  });

  // Helper function to extract and process update packages
  async function extractUpdatePackage(packagePath: string): Promise<{
    migrations: string[];
    files: string[];
    errors: string[];
  }> {
    const result = {
      migrations: [] as string[],
      files: [] as string[],
      errors: [] as string[]
    };

    try {
      // For now, we'll simulate extraction and look for .sql files
      // In a real implementation, you would use libraries like 'yauzl' for ZIP
      // or 'tar' for TAR.GZ files to extract the contents
      
      // Check if package contains migration files (simulated)
      const packageName = path.basename(packagePath);
      if (packageName.includes('migration') || packageName.includes('schema')) {
        result.migrations.push('Example migration detected in package');
      }
      
      result.files.push(packageName);
      
    } catch (error) {
      result.errors.push(`Extraction failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  // Database migration endpoints
  app.get("/api/system-update/migrations/status", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }

      const status = await migrationManager.getMigrationStatus();
      res.json(status);

    } catch (error) {
      console.error("Migration status error:", error);
      res.status(500).json({ message: "Failed to get migration status" });
    }
  });

  app.post("/api/system-update/migrations/apply", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }

      // Create database backup before applying migrations
      const backup = await migrationManager.createBackup();
      if (!backup.success) {
        return res.status(500).json({ 
          message: "Failed to create database backup before migration",
          error: backup.error 
        });
      }

      // Apply pending migrations
      const result = await migrationManager.applyMigrations(user.id);
      
      // Log the migration operation
      await logAction(
        req,
        'DATABASE_MIGRATIONS_APPLIED',
        `Applied ${result.appliedMigrations.length} migrations. Errors: ${result.errors.length}`
      );

      res.json({
        ...result,
        backupCreated: backup.backupPath
      });

    } catch (error) {
      console.error("Migration apply error:", error);
      res.status(500).json({ message: "Failed to apply migrations" });
    }
  });

  app.post("/api/system-update/migrations/rollback", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }

      const result = await migrationManager.rollbackLastMigration(user.id);
      
      if (result.success) {
        await logAction(
          req,
          'DATABASE_MIGRATION_ROLLBACK',
          'Rolled back last migration'
        );
      }

      res.json(result);

    } catch (error) {
      console.error("Migration rollback error:", error);
      res.status(500).json({ message: "Failed to rollback migration" });
    }
  });

  app.post("/api/system-update/backup", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }

      const backup = await migrationManager.createBackup();
      
      if (backup.success) {
        await logAction(
          req,
          'DATABASE_BACKUP_CREATED',
          `Created database backup: ${backup.backupPath}`
        );
      }

      res.json(backup);

    } catch (error) {
      console.error("Database backup error:", error);
      res.status(500).json({ message: "Failed to create database backup" });
    }
  });

  // Get system update status and history
  app.get("/api/system-update/status", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }

      // Get recent update logs from system logs
      const logs = await storage.getAllSystemLogs();
      const updateLogs = logs.filter(log => 
        log.action.includes('SYSTEM_UPDATE') || log.action.includes('UPDATE')
      ).slice(0, 10); // Get last 10 update-related logs

      // Check for any pending update files
      const updateDir = path.join(process.cwd(), 'tmp', 'updates');
      let pendingFiles = [];
      
      if (fs.existsSync(updateDir)) {
        try {
          const files = fs.readdirSync(updateDir);
          pendingFiles = files.map(filename => {
            const filePath = path.join(updateDir, filename);
            const stats = fs.statSync(filePath);
            return {
              filename,
              size: stats.size,
              uploadedAt: stats.mtime
            };
          });
        } catch (error) {
          console.error("Error reading update directory:", error);
        }
      }

      res.json({
        recentUpdates: updateLogs,
        pendingFiles,
        systemStatus: "operational"
      });

    } catch (error) {
      console.error("System update status error:", error);
      res.status(500).json({ message: "Failed to get system update status" });
    }
  });

  // Apply a specific update file
  app.post("/api/system-update/apply/:filename", requireAuth, async (req, res) => {
    try {
      const user = req.user;
      const { filename } = req.params;
      
      if (user?.role !== "developer") {
        return res.status(403).json({ message: "Access denied. Developer role required." });
      }

      const updatePath = path.join(process.cwd(), 'tmp', 'updates', filename);
      
      if (!fs.existsSync(updatePath)) {
        return res.status(404).json({ message: "Update file not found" });
      }

      // Log the update application
      await logAction(
        req,
        'SYSTEM_UPDATE_APPLY',
        `Applied system update: ${filename}`
      );

      // In a real implementation, this would:
      // 1. Extract the update package
      // 2. Validate the contents
      // 3. Create system backup
      // 4. Apply file changes
      // 5. Run migration scripts
      // 6. Restart services
      // 7. Verify update success
      
      // For demonstration, we'll simulate success
      res.json({
        success: true,
        message: "System update applied successfully",
        filename,
        appliedAt: new Date().toISOString()
      });

    } catch (error) {
      console.error("System update apply error:", error);
      res.status(500).json({ message: "Failed to apply system update" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
