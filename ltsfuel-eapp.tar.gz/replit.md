# Fleet Management Portal - FULLY FUNCTIONAL - replit.md
**Last Updated: July 26, 2025**
**Status: PRODUCTION READY** ✅

## Overview

This is a **FULLY FUNCTIONAL** fleet management portal built for Lee Transport Systems, designed as a mobile-first web application for drivers to log fuel transactions with comprehensive admin management capabilities. The application features complete PostgreSQL database integration with secure authentication, role-based access control, and real-time transaction processing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom Lee Transport branding
- **Build Tool**: Vite for development and production builds
- **Mobile-First Design**: Optimized for mobile devices with responsive layouts

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful API endpoints under `/api` prefix
- **Error Handling**: Centralized error middleware with structured responses
- **Request Logging**: Custom middleware for API request/response logging

### Data Storage - **IMPLEMENTED & FUNCTIONAL**
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM with complete schema implementation
- **Authentication**: Secure user management with bcryptjs + passport.js
- **Sessions**: PostgreSQL-backed session storage
- **Relationships**: Full foreign key constraints between all entities
- **Connection**: @neondatabase/serverless with connection pooling

## Recent Achievements - July 26, 2025
- ✅ **Database Integration Complete**: Full PostgreSQL implementation with secure authentication
- ✅ **Form Submissions Fixed**: All transaction forms working properly with database persistence
- ✅ **Three-Tier Authentication**: Secure login with role-based access (Driver/Administrator/Developer)
- ✅ **Tank Management**: Real-time ullage calculations (removed 100% ullage per user request)
- ✅ **Navigation Updated**: DEF log removed from main navigation as requested
- ✅ **Date/Time Controls**: Non-editable timestamps for drivers, admin-editable for corrections
- ✅ **Vehicle Management**: Full CRUD operations with autocomplete selection
- ✅ **Advanced User Management**: Role hierarchy, bulk operations, CSV import/export, user lockout
- ✅ **Developer Role Protection**: Administrators cannot modify developer accounts
- ✅ **User Status System**: Active/Locked Out status with login prevention for locked users
- ✅ **Locked Out Message Fix**: Proper error display when locked users attempt login
- ✅ **Developer Role Permissions**: Fixed server-side permission checks to properly recognize developer role
- ✅ **Bulk Operations API**: Added CSV upload and bulk delete endpoints for developer role
- ✅ **Administrator Permissions**: Updated so administrators can edit any user except developer accounts
- ✅ **Role Protection**: Only developers can edit/delete other developer accounts and delete any users
- ✅ **System Logs Feature**: Added comprehensive audit logging accessible only to developers
- ✅ **Action Tracking**: All user actions are logged with IP addresses, timestamps, and details
- ✅ **Login/Logout Logging**: Authentication events are automatically tracked
- ✅ **Automatic Log Cleanup**: System logs older than 14 days are automatically deleted daily
- ✅ **Tank Level Alerts**: Red urgent banner on admin dashboard when tank levels drop below 25%
- ✅ **Driver Tank Access**: Added "Tanks" page with read-only tank levels and warning banner
- ✅ **Navigation Updates**: Added "Deliveries" tab and moved tank levels under deliveries section
- ✅ **System Settings Implementation**: Added developer-only system settings management for welcome message and alert banners
- ✅ **Alert Banner System**: Dashboard alert banners with enable/disable controls and customizable messages for all users
- ✅ **Dynamic Welcome Message**: Login screen welcome message customizable through system settings
- ✅ **Navigation Cleanup**: Removed System Settings from main navigation per user request (functionality still accessible via direct URL)
- ✅ **User Group Settings Implementation**: Added comprehensive role and permission management system accessible only to developers
- ✅ **Role Templates System**: Predefined permission templates for Driver, Administrator, and Developer roles with customizable permissions
- ✅ **Advanced User Management**: Create users with specific roles, modify permissions, assign role templates, and delete non-developer accounts
- ✅ **Permission-Based Access Control**: Granular permissions for system settings, user management, transactions, vehicles, and tank operations
- ✅ **Company Name Real-Time Updates**: Fixed company name editing to force page reload ensuring immediate updates across all application components
- ✅ **Production Login Screen**: Removed demo credentials from login screen for professional deployment
- ✅ **Database Backup System**: Created comprehensive PostgreSQL backup with MySQL-compatible conversion for easy migration
- ✅ **PHP/MySQL Version**: Complete project conversion to PHP/MySQL for independent server deployment with install script
- ✅ **PHP Version Feature Parity**: Added all missing advanced features to PHP version including vehicle management, user permissions, system logs, advanced settings, deliveries page, and DEF form
- ✅ **Advanced PHP Features**: Implemented granular user permissions system, system audit logs, vehicle CRUD operations, debug mode controls, and comprehensive admin management interface
- ✅ **PHP Security & Navigation**: Fixed all broken links, enhanced navigation with dropdown menus, improved error handling, and added proper role-based access controls
- ✅ **Mobile-Friendly PHP Version**: Added comprehensive mobile device detection, responsive CSS, mobile navigation, and touch-optimized interface
- ✅ **Mobile Bottom Navigation**: Implemented iOS/Android-style bottom navigation for mobile devices with role-based menu items
- ✅ **Mobile CSS Framework**: Created mobile.css with touch-friendly buttons, responsive layouts, and mobile-first design principles
- ✅ **Mobile Interface Detection**: Smart device detection redirects mobile users to optimized interface automatically
- ✅ **Complete Link Verification**: All 24 PHP files tested and working with comprehensive link testing page for developers
- ✅ **System Settings Database Fix**: Fixed critical 'id' field error when updating alert banners and welcome messages in React app
- ✅ **PHP Version Complete Repairs**: Fixed all broken links, role permissions, Bootstrap dropdowns, and system settings in PHP version
- ✅ **Universal Role Access**: Administrators and developers can now access all driver functions including fuel/DEF logging and history
- ✅ **Bootstrap 5.3.2 Update**: Updated PHP version with latest Bootstrap for proper dropdown and interactive component functionality
- ✅ **cPanel Deployment Guide**: Created comprehensive deployment instructions for both PHP and React versions with step-by-step cPanel setup
- ✅ **VPS Deployment Package**: Created specialized VPS deployment guide with Node.js, PostgreSQL, and systemd service configuration for optimal performance
- ✅ **Custom ltsfuel.com Deployment**: Created personalized 10-step deployment guide for React app with ltsfuel user and domain-specific configuration
- ✅ **React Deployment Support Request**: Customer experiencing dependency and build issues with React version, support requested for professional assistance
- ✅ **Ubuntu VPS Deployment Guide**: Created comprehensive beginner-friendly step-by-step guide for deploying React app on Ubuntu VPS with complete automation script
- ✅ **Stay Logged In Feature**: Added toggle switch on login screen for persistent sessions up to 30 days vs 24-hour default sessions
- ✅ **System Update Feature**: Added developer-only system update interface with secure file upload, progress tracking, and audit logging for applying system updates via ZIP/TAR.GZ packages
- ✅ **Database Migration System**: Created comprehensive migration management with automatic backup creation, SQL migration parsing, rollback capabilities, and migration status tracking for database schema updates
- ✅ **Enhanced Maintenance Mode**: Developer-only toggle with automatic force logout for non-developers, red urgent banner on login screen, yellow maintenance banner on all pages, and complete system restriction during maintenance
- ✅ **Advanced System Configuration**: Added comprehensive developer-only system settings including security controls (session timeout, login attempts, password complexity), email notifications (SMTP configuration), audit logging, backup retention, rate limiting, and maintenance windows
- ✅ **UI Styling Rollback**: Reverted System Settings page from enhanced gradient design back to clean, simple styling with basic card layouts per user request

## Key Components

### Database Schema
Located in `shared/schema.ts`:
- **Employees**: User management with id, name, email
- **Vehicles**: Fleet vehicles with id, name, model
- **Transactions**: Fuel/DEF logs with employee/vehicle references, type, amounts, location, odometer, timestamps

### API Endpoints
- `GET /api/employees` - List all employees
- `GET /api/employee/current` - Get current logged-in employee
- `GET /api/vehicles` - List all vehicles
- `POST /api/transactions` - Submit new fuel/DEF transaction
- `GET /api/transactions` - List transactions with filtering
- `GET /api/transactions/stats` - Transaction statistics
- `GET /api/tank-levels` - Get all tank levels
- `PUT /api/tank-levels/:id` - Update tank level
- `POST /api/tank-levels` - Create new tank level

### Frontend Pages
#### Driver Interface
- **Dashboard**: Overview with quick stats and recent transactions
- **Fuel Form**: Form for logging fuel transactions
- **DEF Form**: Form for logging DEF transactions  
- **History**: Transaction history with filtering capabilities

#### Admin Interface
- **Admin Dashboard**: Fleet-wide statistics and management overview
- **Transaction Management**: View all employee transactions with search/filter
- **Reports & Analytics**: Detailed fleet performance reports with CSV export
- **Tank Management**: Monitor tank levels and update fuel/DEF inventory

### Storage Layer
**FULLY IMPLEMENTED** - Uses PostgreSQL database with Drizzle ORM (`DatabaseStorage` class). Features:
- Complete user authentication with bcryptjs password hashing
- Secure session management with passport.js
- Role-based access control (Driver/Administrator)
- Real-time transaction processing and storage
- Tank level management with automatic updates
- Foreign key relationships between users, vehicles, and transactions
- Database seeding with initial data on startup
- Production-ready with proper data persistence and ACID compliance

## Data Flow

1. **User Authentication**: Role-based access (driver vs admin) with simplified routing
2. **Form Submission**: React Hook Form with Zod validation → API endpoint → PostgreSQL Database
3. **Data Fetching**: TanStack Query handles caching, loading states, and error handling
4. **Real-time Updates**: Query invalidation ensures fresh data after mutations
5. **Email Notifications**: Nodemailer integration for transaction confirmations
6. **Admin Analytics**: Database queries provide fleet-wide statistics and reporting
7. **Quick Location Shortcuts**: Pre-defined location buttons for common fueling stops

## External Dependencies

### UI & Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Class Variance Authority**: Component variant management

### Forms & Validation
- **React Hook Form**: Form state management
- **Zod**: Schema validation
- **@hookform/resolvers**: Zod integration with React Hook Form

### Data & API
- **TanStack Query**: Server state management
- **Drizzle ORM**: Type-safe database queries
- **Drizzle Zod**: Schema to validation integration

### Development
- **TypeScript**: Type safety across the stack
- **Vite**: Fast development and build tooling
- **TSX**: TypeScript execution for development server
- **ESBuild**: Production backend bundling

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: TSX for TypeScript execution
- **Database**: Local PostgreSQL or Neon development database

### Production Build
- **Frontend**: Vite builds to `dist/public`
- **Backend**: ESBuild bundles server to `dist/index.js`
- **Deployment**: Single Node.js process serving both API and static files
- **Environment**: Production mode with optimized builds

### Configuration
- **Database**: Environment variable `DATABASE_URL` required
- **Email**: SMTP configuration via environment variables
- **Build Output**: Separate directories for client and server builds
- **Static Assets**: Express serves built frontend from `dist/public`

The application is designed for easy deployment to platforms like Replit, Vercel, or traditional hosting with PostgreSQL support.