# Fleet Management App - Ubuntu 24 VPS Deployment Guide

**Complete Beginner's Guide for Deploying React Fleet Management System**

## Prerequisites
- Ubuntu 24 VPS server with root access
- Domain name (optional but recommended)
- SSH access to your server
- Basic terminal knowledge

## Step 1: Initial Server Setup

### Connect to Your VPS
```bash
ssh root@your-server-ip
```

### Update System Packages
```bash
apt update && apt upgrade -y
```

### Install Essential Tools
```bash
apt install -y curl wget git nano htop unzip
```

## Step 2: Install Node.js 20

### Add NodeSource Repository
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
```

### Install Node.js
```bash
apt install -y nodejs
```

### Verify Installation
```bash
node --version  # Should show v20.x.x
npm --version   # Should show 10.x.x
```

## Step 3: Install and Configure PostgreSQL

### Install PostgreSQL
```bash
apt install -y postgresql postgresql-contrib
```

### Start PostgreSQL Service
```bash
systemctl start postgresql
systemctl enable postgresql
```

### Create Database and User
```bash
# Switch to postgres user
sudo -u postgres psql

# In PostgreSQL shell, run these commands:
CREATE DATABASE ltsfuel_db;
CREATE USER ltsfueluser WITH ENCRYPTED PASSWORD 'LtsFuel2025!';
GRANT ALL PRIVILEGES ON DATABASE ltsfuel_db TO ltsfueluser;
ALTER USER ltsfueluser CREATEDB;
\q
```

### Configure PostgreSQL for Local Connections
```bash
# Edit PostgreSQL configuration
nano /etc/postgresql/16/main/pg_hba.conf

# Add this line after the existing local connections:
local   all             ltsfueluser                             md5

# Restart PostgreSQL
systemctl restart postgresql
```

## Step 4: Install and Configure Nginx

### Install Nginx
```bash
apt install -y nginx
```

### Start and Enable Nginx
```bash
systemctl start nginx
systemctl enable nginx
```

### Configure Firewall (if UFW is enabled)
```bash
ufw allow 'Nginx Full'
ufw allow ssh
ufw --force enable
```

## Step 5: Create Application User

### Create ltsfuel User
```bash
adduser ltsfuel
usermod -aG sudo ltsfuel
```

### Switch to ltsfuel User
```bash
su - ltsfuel
```

## Step 6: Clone and Setup Application

### Clone Repository (if from Git) or Upload Files
```bash
# If using Git (replace with your repository URL):
git clone https://github.com/your-username/fleet-management.git ltsfuel-app

# Or if uploading files manually:
mkdir ltsfuel-app
cd ltsfuel-app
# Upload your application files here using scp or sftp
```

### Navigate to App Directory
```bash
cd ltsfuel-app
```

### Install Dependencies
```bash
npm install
```

## Step 7: Configure Environment Variables

### Create Environment File
```bash
nano .env
```

### Add Environment Configuration
```bash
# Database Configuration
DATABASE_URL=postgresql://ltsfueluser:LtsFuel2025!@localhost:5432/ltsfuel_db

# Application Settings
NODE_ENV=production
PORT=3000

# Session Secret (generate a random string)
SESSION_SECRET=your-super-secret-session-key-here-make-it-long-and-random

# Email Configuration (optional - for notifications)
SMTP_HOST=your-smtp-server.com
SMTP_PORT=587
SMTP_USER=your-email@domain.com
SMTP_PASS=your-email-password
```

## Step 8: Build the Application

### Install Production Dependencies
```bash
npm ci --production
```

### Build the Application
```bash
npm run build
```

### Test the Application
```bash
npm start
```

Press `Ctrl+C` to stop the test run.

## Step 9: Install Process Manager (PM2)

### Install PM2 Globally
```bash
sudo npm install -g pm2
```

### Create PM2 Ecosystem File
```bash
nano ecosystem.config.js
```

### Add PM2 Configuration
```javascript
module.exports = {
  apps: [{
    name: 'ltsfuel-app',
    script: 'dist/index.js',
    cwd: '/home/ltsfuel/ltsfuel-app',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/home/ltsfuel/logs/app-error.log',
    out_file: '/home/ltsfuel/logs/app-out.log',
    log_file: '/home/ltsfuel/logs/app-combined.log'
  }]
};
```

### Create Logs Directory
```bash
mkdir /home/ltsfuel/logs
```

### Start Application with PM2
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

Follow the instructions shown by PM2 startup command.

## Step 10: Configure Nginx Reverse Proxy

### Exit to Root User
```bash
exit  # Return to root user
```

### Create Nginx Configuration
```bash
nano /etc/nginx/sites-available/ltsfuel
```

### Add Nginx Configuration
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;  # Replace with your domain or server IP

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_redirect off;
        
        # Timeout settings
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # File upload size limit
    client_max_body_size 10M;
}
```

### Enable the Site
```bash
ln -s /etc/nginx/sites-available/ltsfuel /etc/nginx/sites-enabled/
```

### Remove Default Site
```bash
rm /etc/nginx/sites-enabled/default
```

### Test Nginx Configuration
```bash
nginx -t
```

### Restart Nginx
```bash
systemctl restart nginx
```

## Step 11: Setup SSL Certificate (Optional but Recommended)

### Install Certbot
```bash
apt install -y certbot python3-certbot-nginx
```

### Obtain SSL Certificate
```bash
certbot --nginx -d your-domain.com -d www.your-domain.com
```

Follow the prompts to configure SSL.

### Auto-renewal Setup
```bash
systemctl status certbot.timer
```

## Step 12: Setup Database Backup Script

### Create Backup Directory
```bash
mkdir -p /home/ltsfuel/backups
chown ltsfuel:ltsfuel /home/ltsfuel/backups
```

### Create Backup Script
```bash
nano /home/ltsfuel/backup-db.sh
```

### Add Backup Script Content
```bash
#!/bin/bash

# Database backup script
BACKUP_DIR="/home/ltsfuel/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="ltsfuel_db"
DB_USER="ltsfueluser"

# Create backup
pg_dump -h localhost -U $DB_USER -d $DB_NAME > $BACKUP_DIR/ltsfuel_backup_$DATE.sql

# Keep only last 7 days of backups
find $BACKUP_DIR -name "ltsfuel_backup_*.sql" -mtime +7 -delete

echo "Database backup completed: ltsfuel_backup_$DATE.sql"
```

### Make Script Executable
```bash
chmod +x /home/ltsfuel/backup-db.sh
chown ltsfuel:ltsfuel /home/ltsfuel/backup-db.sh
```

### Setup Daily Backup Cron Job
```bash
# Switch to ltsfuel user
su - ltsfuel

# Edit crontab
crontab -e

# Add this line for daily backup at 2 AM:
0 2 * * * /home/ltsfuel/backup-db.sh >> /home/ltsfuel/logs/backup.log 2>&1

# Exit back to root
exit
```

## Step 13: Setup Log Rotation

### Create Logrotate Configuration
```bash
nano /etc/logrotate.d/ltsfuel
```

### Add Logrotate Configuration
```bash
/home/ltsfuel/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 ltsfuel ltsfuel
    postrotate
        /usr/bin/pm2 reloadLogs
    endscript
}
```

## Step 14: System Monitoring Setup

### Create System Status Script
```bash
nano /home/ltsfuel/system-status.sh
```

### Add Status Script Content
```bash
#!/bin/bash

echo "=== LTS Fuel App System Status ==="
echo "Date: $(date)"
echo ""

echo "=== Application Status ==="
su - ltsfuel -c "pm2 status"
echo ""

echo "=== Disk Usage ==="
df -h
echo ""

echo "=== Memory Usage ==="
free -h
echo ""

echo "=== Database Status ==="
systemctl status postgresql --no-pager -l
echo ""

echo "=== Nginx Status ==="
systemctl status nginx --no-pager -l
echo ""
```

### Make Status Script Executable
```bash
chmod +x /home/ltsfuel/system-status.sh
```

## Step 15: Security Hardening

### Configure SSH Security
```bash
nano /etc/ssh/sshd_config
```

### Update SSH Configuration
```bash
# Add or modify these lines:
PermitRootLogin no
PasswordAuthentication no  # Only if you have SSH keys setup
Port 2222  # Change default SSH port (optional)
```

### Restart SSH Service
```bash
systemctl restart ssh
```

### Setup Fail2Ban
```bash
apt install -y fail2ban

# Create jail configuration
nano /etc/fail2ban/jail.local
```

### Add Fail2Ban Configuration
```bash
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
port = http,https
logpath = /var/log/nginx/error.log
```

### Start Fail2Ban
```bash
systemctl start fail2ban
systemctl enable fail2ban
```

## Step 16: Application Updates

### Create Update Script
```bash
nano /home/ltsfuel/update-app.sh
```

### Add Update Script Content
```bash
#!/bin/bash

APP_DIR="/home/ltsfuel/ltsfuel-app"
BACKUP_DIR="/home/ltsfuel/app-backups"
DATE=$(date +%Y%m%d_%H%M%S)

echo "Starting application update..."

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup current application
cp -r $APP_DIR $BACKUP_DIR/ltsfuel-app-backup-$DATE

# Navigate to app directory
cd $APP_DIR

# Pull latest changes (if using Git)
# git pull origin main

# Install dependencies
npm ci --production

# Build application
npm run build

# Restart application
pm2 restart ltsfuel-app

echo "Application update completed!"
echo "Backup saved to: $BACKUP_DIR/ltsfuel-app-backup-$DATE"
```

### Make Update Script Executable
```bash
chmod +x /home/ltsfuel/update-app.sh
chown ltsfuel:ltsfuel /home/ltsfuel/update-app.sh
```

## Step 17: Final Verification

### Check All Services
```bash
# Check PM2 status
su - ltsfuel -c "pm2 status"

# Check Nginx status
systemctl status nginx

# Check PostgreSQL status
systemctl status postgresql

# Check application accessibility
curl -I http://localhost
```

### Test Application Access
```bash
# Test from server
curl http://localhost

# Test database connection
su - ltsfuel -c "cd ltsfuel-app && node -e \"const { neon } = require('@neondatabase/serverless'); const sql = neon(process.env.DATABASE_URL); sql\`SELECT 1\`.then(() => console.log('DB Connected')).catch(console.error)\""
```

## Step 18: Accessing Your Application

### Via Web Browser
- **HTTP**: `http://your-server-ip` or `http://your-domain.com`
- **HTTPS**: `https://your-domain.com` (if SSL configured)

### Default Login Credentials
- **Developer Account**: 
  - Username: `shawn.brouillette@leetransport.com`
  - Password: `password123`

### Change Default Passwords
1. Login to the application
2. Navigate to User Management
3. Change the default developer password immediately

## Troubleshooting

### Check Application Logs
```bash
su - ltsfuel -c "pm2 logs ltsfuel-app"
```

### Check Nginx Logs
```bash
tail -f /var/log/nginx/error.log
tail -f /var/log/nginx/access.log
```

### Check Database Logs
```bash
tail -f /var/log/postgresql/postgresql-16-main.log
```

### Restart Services
```bash
# Restart application
su - ltsfuel -c "pm2 restart ltsfuel-app"

# Restart Nginx
systemctl restart nginx

# Restart PostgreSQL
systemctl restart postgresql
```

### Check Port Usage
```bash
netstat -tlnp | grep :3000
netstat -tlnp | grep :80
```

## Maintenance Commands

### View System Status
```bash
/home/ltsfuel/system-status.sh
```

### Update Application
```bash
su - ltsfuel -c "/home/ltsfuel/update-app.sh"
```

### Backup Database Manually
```bash
su - ltsfuel -c "/home/ltsfuel/backup-db.sh"
```

### View Application Performance
```bash
su - ltsfuel -c "pm2 monit"
```

## Performance Optimization

### Enable Database Connection Pooling (already configured in app)
### Setup Redis for Session Storage (optional)
```bash
apt install -y redis-server
systemctl start redis-server
systemctl enable redis-server
```

### Monitor Resources
```bash
htop
iotop
```

## Security Best Practices

1. **Regular Updates**: Keep system packages updated
2. **Backup Strategy**: Automated daily backups
3. **Monitoring**: Set up log monitoring and alerts
4. **SSL Certificate**: Always use HTTPS in production
5. **Firewall**: Configure UFW or iptables
6. **User Access**: Use SSH keys instead of passwords
7. **Application Security**: Change default passwords immediately

## Support and Maintenance

### Regular Maintenance Tasks
- Monitor disk space usage
- Check application logs for errors
- Verify backup integrity
- Update system packages monthly
- Review user access permissions

### Emergency Procedures
- Application restart: `pm2 restart ltsfuel-app`
- Database restore from backup
- Nginx configuration rollback
- System rollback from app backup

---

**Deployment Complete!**

Your Fleet Management application is now running on Ubuntu 24 VPS with:
- ✅ Node.js 20 runtime
- ✅ PostgreSQL database
- ✅ Nginx reverse proxy
- ✅ PM2 process management
- ✅ SSL certificate (optional)
- ✅ Automated backups
- ✅ Security hardening
- ✅ Log rotation
- ✅ System monitoring

Your application should now be accessible via your domain or server IP address.