import { db } from "./db";
import { users, employees, vehicles, tankLevels } from "@shared/schema";
import { hashPassword } from "./auth";

async function seedDatabase() {
  try {
    console.log("🌱 Seeding database...");

    // Check if users exist (but always ensure tanks are seeded)
    const existingUsers = await db.select().from(users);
    const existingEmployees = await db.select().from(employees);
    const existingTanks = await db.select().from(tankLevels);
    
    if (existingUsers.length > 0 && existingEmployees.length > 0 && existingTanks.length > 0) {
      console.log("✅ Database already seeded");
      return;
    }

    // Create sample users (only if they don't exist)
    if (existingUsers.length === 0) {
      const driverPassword = await hashPassword("driver123");
      const adminPassword = await hashPassword("admin123");
      
      const developerPassword = await hashPassword("dev123");
      
      await db.insert(users).values([
        {
          id: "user-1",
          username: "john.driver",
          password: driverPassword,
          name: "John Driver",
          email: "john.driver@leetransport.com",
          role: "driver",
        },
        {
          id: "user-admin",
          username: "admin",
          password: adminPassword,
          name: "Fleet Administrator",
          email: "admin@leetransport.com",
          role: "administrator",
        },
        {
          id: "user-developer",
          username: "shawn.brouillette",
          password: developerPassword,
          name: "Shawn Brouillette",
          email: "shawn.brouillette@leetransport.com",
          role: "developer",
        },
      ]);
    }

    // Create sample employees (only if they don't exist)
    if (existingEmployees.length === 0) {
      await db.insert(employees).values([
        {
          id: "emp-1",
          name: "John Driver",
          email: "john.driver@leetransport.com",
          role: "driver",
        },
        {
          id: "admin-1",
          name: "Fleet Manager",
          email: "manager@leetransport.com",
          role: "admin",
        },
      ]);
    }

    // Create sample vehicles (only if employees were created)
    if (existingEmployees.length === 0) {
      await db.insert(vehicles).values([
        { id: "truck-247", name: "Truck #247", model: "Kenworth T680" },
        { id: "truck-189", name: "Truck #189", model: "Peterbilt 579" },
        { id: "truck-156", name: "Truck #156", model: "Freightliner Cascadia" },
        { id: "truck-203", name: "Truck #203", model: "Volvo VNL" },
      ]);
    }

    // Create tank levels for both locations
    if (existingTanks.length === 0) {
      await db.insert(tankLevels).values([
        // Tampa Yard tanks
        {
          id: "tampa-diesel-tank",
          name: "Tampa Yard - Diesel Tank",
          type: "diesel",
          location: "Tampa Yard",
          currentLevel: "8500",
          capacity: "10000",
          unit: "gallons",
        },
        {
          id: "tampa-def-tank",
          name: "Tampa Yard - DEF Tank",
          type: "def",
          location: "Tampa Yard",
          currentLevel: "750",
          capacity: "1000",
          unit: "gallons",
        },
        // Elmer Yard tanks
        {
          id: "elmer-diesel-tank",
          name: "Elmer Yard - Diesel Tank",
          type: "diesel",
          location: "Elmer Yard",
          currentLevel: "7200",
          capacity: "8000",
          unit: "gallons",
        },
        {
          id: "elmer-def-tank",
          name: "Elmer Yard - DEF Tank",
          type: "def",
          location: "Elmer Yard",
          currentLevel: "600",
          capacity: "800",
          unit: "gallons",
        },
      ]);
    }

    console.log("✅ Database seeded successfully");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

export { seedDatabase };