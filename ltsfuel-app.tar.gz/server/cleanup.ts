import { storage } from "./storage";

export async function startCleanupScheduler() {
  // Run cleanup immediately on startup
  await performCleanup();
  
  // Schedule cleanup to run every 24 hours (86400000 milliseconds)
  setInterval(async () => {
    await performCleanup();
  }, 24 * 60 * 60 * 1000);
  
  console.log('📅 System logs cleanup scheduler started - will run daily');
}

async function performCleanup() {
  try {
    const deletedCount = await storage.cleanupOldSystemLogs();
    if (deletedCount > 0) {
      console.log(`🧹 Cleaned up ${deletedCount} system logs older than 14 days`);
    } else {
      console.log('🧹 System logs cleanup: No old logs to delete');
    }
  } catch (error) {
    console.error('❌ Error during system logs cleanup:', error);
  }
}