import { users, type User, type InsertUser, vehicles, type Vehicle, type InsertVehicle, transactions, type Transaction, type InsertTransaction, employees, type Employee, type InsertEmployee, tankLevels, type TankLevel, type InsertTankLevel, systemLogs, type SystemLog, type InsertSystemLog, systemSettings, type SystemSetting, type InsertSystemSetting } from "@shared/schema";
import { db } from "./db";
import { eq, sql, and } from "drizzle-orm";

export interface IStorage {
  // User methods (for authentication)
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  deleteUser(id: string): Promise<void>;
  deleteUsers(userIds: string[]): Promise<void>;
  bulkUpsertUsers(users: Partial<InsertUser>[]): Promise<any>;

  // Employee methods
  getEmployee(id: string): Promise<Employee | undefined>;
  getEmployeeByEmail(email: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  getAllEmployees(): Promise<Employee[]>;
  getEmployeesByRole(role: string): Promise<Employee[]>;

  // Vehicle methods
  getVehicle(id: string): Promise<Vehicle | undefined>;
  getAllVehicles(): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: string, updates: Partial<Vehicle>): Promise<Vehicle | undefined>;
  deleteVehicle(id: string): Promise<void>;

  // Transaction methods
  getTransaction(id: string): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionsByEmployee(employeeId: string): Promise<Transaction[]>;
  getAllTransactions(): Promise<Transaction[]>;
  getTransactionsWithDetails(): Promise<(Transaction & { employeeName: string; vehicleName: string })[]>;
  updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: string): Promise<boolean>;

  // Tank level methods
  getTankLevel(id: string): Promise<TankLevel | undefined>;
  getAllTankLevels(): Promise<TankLevel[]>;
  getTankLevelsForUser(userId: string): Promise<TankLevel[]>;
  createTankLevel(insertTankLevel: InsertTankLevel): Promise<TankLevel>;
  updateTankLevel(id: string, updates: Partial<TankLevel>): Promise<TankLevel>;
  updateTankLevelFromTransaction(fuelType: string, location: string, gallons: number): Promise<void>;
  updateUserTankVisibility(userId: string, visibleTanks: string[]): Promise<User>;

  // System logging methods
  createSystemLog(log: InsertSystemLog): Promise<SystemLog>;
  getAllSystemLogs(): Promise<SystemLog[]>;
  getSystemLogsByUser(userId: string): Promise<SystemLog[]>;
  cleanupOldSystemLogs(): Promise<number>;

  // System settings methods
  getSystemSetting(key: string): Promise<SystemSetting | undefined>;
  getAllSystemSettings(): Promise<SystemSetting[]>;
  upsertSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting>;
}

export class DatabaseStorage implements IStorage {
  // User methods (for authentication)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        updatedAt: new Date(),
      })
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }



  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async deleteUsers(userIds: string[]): Promise<void> {
    await db.delete(users).where(sql`${users.id} = ANY(${userIds})`);
  }

  async bulkUpsertUsers(csvUsers: Partial<InsertUser>[]): Promise<any> {
    const results = {
      created: 0,
      updated: 0,
      errors: [] as string[]
    };

    for (const userData of csvUsers) {
      try {
        if (!userData.username) {
          results.errors.push("Missing username for user");
          continue;
        }

        const existingUser = await this.getUserByUsername(userData.username);
        
        if (existingUser) {
          // Update existing user
          await this.updateUser(existingUser.id, userData);
          results.updated++;
        } else {
          // Create new user
          if (!userData.password) {
            userData.password = 'defaultPassword123'; // Set default password for CSV imports
          }
          await this.createUser(userData as InsertUser);
          results.created++;
        }
      } catch (error) {
        results.errors.push(`Error processing user ${userData.username}: ${error}`);
      }
    }

    return results;
  }

  // Employee methods
  async getEmployee(id: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee || undefined;
  }

  async getEmployeeByEmail(email: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.email, email));
    return employee || undefined;
  }

  async createEmployee(insertEmployee: InsertEmployee): Promise<Employee> {
    const [employee] = await db
      .insert(employees)
      .values(insertEmployee)
      .returning();
    return employee;
  }

  async getAllEmployees(): Promise<Employee[]> {
    return await db.select().from(employees);
  }

  async getEmployeesByRole(role: string): Promise<Employee[]> {
    return await db.select().from(employees).where(eq(employees.role, role));
  }

  // Vehicle methods
  async getVehicle(id: string): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle || undefined;
  }

  async getAllVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles);
  }

  async createVehicle(vehicle: InsertVehicle): Promise<Vehicle> {
    const [newVehicle] = await db
      .insert(vehicles)
      .values(vehicle)
      .returning();
    return newVehicle;
  }

  async updateVehicle(id: string, updates: Partial<Vehicle>): Promise<Vehicle | undefined> {
    try {
      const [vehicle] = await db
        .update(vehicles)
        .set(updates)
        .where(eq(vehicles.id, id))
        .returning();
      return vehicle || undefined;
    } catch (error) {
      console.error("Error updating vehicle:", error);
      return undefined;
    }
  }

  async deleteVehicle(id: string): Promise<void> {
    await db.delete(vehicles).where(eq(vehicles.id, id));
  }

  // Transaction methods
  async getTransaction(id: string): Promise<Transaction | undefined> {
    const [transaction] = await db.select().from(transactions).where(eq(transactions.id, id));
    return transaction || undefined;
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const transactionData = {
      ...insertTransaction,
      gallons: insertTransaction.gallons.toString(),
      cost: (insertTransaction.cost || 0).toString(),
      location: insertTransaction.location || "Tampa Yard",
    };
    
    const [transaction] = await db
      .insert(transactions)
      .values(transactionData)
      .returning();

    // Update tank levels based on the transaction
    const fuelType = insertTransaction.type === 'fuel' ? (insertTransaction as any).fuelType || 'diesel' : 'def';
    console.log(`Transaction created - Type: ${insertTransaction.type}, FuelType: ${fuelType}, Location: ${insertTransaction.location}`);
    await this.updateTankLevelFromTransaction(fuelType, insertTransaction.location || "Tampa Yard", insertTransaction.gallons);
    
    return transaction;
  }

  async getTransactionsByEmployee(employeeId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.employeeId, employeeId));
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions);
  }

  async getTransactionsWithDetails(): Promise<(Transaction & { employeeName: string; vehicleName: string })[]> {
    const result = await db
      .select({
        id: transactions.id,
        employeeId: transactions.employeeId,
        vehicleId: transactions.vehicleId,
        type: transactions.type,
        fuelType: transactions.fuelType,
        gallons: transactions.gallons,
        cost: transactions.cost,
        location: transactions.location,
        odometer: transactions.odometer,
        date: transactions.date,
        time: transactions.time,
        notes: transactions.notes,
        submittedAt: transactions.submittedAt,
        employeeName: users.name,
        vehicleName: vehicles.name,
      })
      .from(transactions)
      .leftJoin(users, eq(transactions.employeeId, users.id))
      .leftJoin(vehicles, eq(transactions.vehicleId, vehicles.id))
;

    return result.map(row => ({
      ...row,
      employeeName: row.employeeName || "Unknown Employee",
      vehicleName: row.vehicleName || "Unknown Vehicle",
    }));
  }

  async updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction | undefined> {
    try {
      const [transaction] = await db
        .update(transactions)
        .set(updates)
        .where(eq(transactions.id, id))
        .returning();
      return transaction || undefined;
    } catch (error) {
      console.error("Error updating transaction:", error);
      return undefined;
    }
  }

  async deleteTransaction(id: string): Promise<boolean> {
    try {
      const result = await db
        .delete(transactions)
        .where(eq(transactions.id, id))
        .returning();
      return result.length > 0;
    } catch (error) {
      console.error("Error deleting transaction:", error);
      return false;
    }
  }

  // Tank level methods
  async getTankLevel(id: string): Promise<TankLevel | undefined> {
    const [tank] = await db.select().from(tankLevels).where(eq(tankLevels.id, id));
    return tank || undefined;
  }

  async getAllTankLevels(): Promise<TankLevel[]> {
    return await db.select().from(tankLevels);
  }

  async getTankLevelsForUser(userId: string): Promise<TankLevel[]> {
    const user = await this.getUser(userId);
    if (!user) return [];
    
    // If user has no tank restrictions (empty array or null), show all tanks
    if (!user.visibleTanks || user.visibleTanks.length === 0) {
      return await this.getAllTankLevels();
    }
    
    // Filter tanks based on user's visible tanks
    const allTanks = await this.getAllTankLevels();
    return allTanks.filter(tank => user.visibleTanks!.includes(tank.id));
  }

  async updateUserTankVisibility(userId: string, visibleTanks: string[]): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ visibleTanks, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserDashboardWidgets(userId: string, dashboardWidgets: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ dashboardWidgets, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async createTankLevel(insertTankLevel: InsertTankLevel): Promise<TankLevel> {
    const [tank] = await db
      .insert(tankLevels)
      .values(insertTankLevel)
      .returning();
    return tank;
  }

  async updateTankLevel(id: string, updates: Partial<TankLevel>): Promise<TankLevel> {
    const [tank] = await db
      .update(tankLevels)
      .set({ ...updates, lastUpdated: new Date() })
      .where(eq(tankLevels.id, id))
      .returning();
    return tank;
  }

  async deleteTankLevel(id: string): Promise<boolean> {
    try {
      const result = await db
        .delete(tankLevels)
        .where(eq(tankLevels.id, id))
        .returning();
      return result.length > 0;
    } catch (error) {
      console.error("Error deleting tank level:", error);
      return false;
    }
  }

  async updateTankLevelFromTransaction(fuelType: string, location: string, gallons: number): Promise<void> {
    console.log(`Updating tank level - FuelType: ${fuelType}, Location: ${location}, Gallons: ${gallons}`);
    
    // Use the fuel type directly (diesel or def)
    const tankType = fuelType;
    
    // Find the appropriate tank for this type and location
    const tanks = await db.select().from(tankLevels).where(
      and(
        eq(tankLevels.type, tankType),
        eq(tankLevels.location, location)
      )
    );
    
    console.log(`Found ${tanks.length} tanks matching criteria`);
    
    if (tanks.length > 0) {
      const tank = tanks[0];
      const currentLevel = parseFloat(tank.currentLevel);
      const newLevel = currentLevel - gallons;
      
      console.log(`Tank ${tank.id}: ${currentLevel} - ${gallons} = ${newLevel}`);
      
      await db
        .update(tankLevels)
        .set({ 
          currentLevel: Math.max(0, newLevel).toString(),
          lastUpdated: new Date() 
        })
        .where(eq(tankLevels.id, tank.id));
        
      console.log(`Tank ${tank.id} updated successfully`);
    } else {
      console.log(`No tank found for type: ${tankType}, location: ${location}`);
    }
  }

  // System logging methods
  async createSystemLog(log: InsertSystemLog): Promise<SystemLog> {
    const [systemLog] = await db
      .insert(systemLogs)
      .values(log)
      .returning();
    return systemLog;
  }

  async getAllSystemLogs(): Promise<SystemLog[]> {
    return await db.select().from(systemLogs).orderBy(sql`timestamp DESC`);
  }

  async getSystemLogsByUser(userId: string): Promise<SystemLog[]> {
    return await db.select().from(systemLogs).where(eq(systemLogs.userId, userId)).orderBy(sql`timestamp DESC`);
  }

  async cleanupOldSystemLogs(): Promise<number> {
    const fourteenDaysAgo = new Date();
    fourteenDaysAgo.setDate(fourteenDaysAgo.getDate() - 14);
    
    const deletedLogs = await db
      .delete(systemLogs)
      .where(sql`timestamp < ${fourteenDaysAgo.toISOString()}`)
      .returning();
    
    return deletedLogs.length;
  }

  // System settings methods
  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    const [setting] = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    return setting || undefined;
  }

  async getAllSystemSettings(): Promise<SystemSetting[]> {
    return await db.select().from(systemSettings);
  }

  async upsertSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting> {
    const [existingSetting] = await db.select().from(systemSettings).where(eq(systemSettings.key, setting.key));
    
    if (existingSetting) {
      const [updatedSetting] = await db
        .update(systemSettings)
        .set({
          value: setting.value,
          description: setting.description,
          updatedAt: new Date(),
          updatedBy: setting.updatedBy,
        })
        .where(eq(systemSettings.key, setting.key))
        .returning();
      return updatedSetting;
    } else {
      // Only pass the fields we want, let id auto-generate
      const [newSetting] = await db
        .insert(systemSettings)
        .values({
          key: setting.key,
          value: setting.value,
          description: setting.description,
          updatedBy: setting.updatedBy,
        })
        .returning();
      return newSetting;
    }
  }

  // Role template management methods
  async getRoleTemplates(): Promise<any> {
    // Return predefined role templates with default permissions
    return {
      driver: {
        name: "Driver",
        description: "Standard driver access for logging transactions and viewing basic information",
        permissions: {
          systemSettings: {
            canAccessSystemSettings: false,
            canEditWelcomeMessage: false,
            canEditAlertBanner: false,
          },
          userManagement: {
            canViewUsers: false,
            canCreateUsers: false,
            canEditUsers: false,
            canDeleteUsers: false,
          },
          transactions: {
            canViewAllTransactions: false,
            canEditTransactions: false,
            canDeleteTransactions: false,
          },
          vehicles: {
            canViewVehicles: true,
            canCreateVehicles: false,
            canEditVehicles: false,
            canDeleteVehicles: false,
          },
          tanks: {
            canViewTankLevels: true,
            canEditTankLevels: false,
            canCreateTanks: false,
            canDeleteTanks: false,
          },
        },
      },
      administrator: {
        name: "Administrator",
        description: "Fleet management with full access to transactions, vehicles, and tank monitoring",
        permissions: {
          systemSettings: {
            canAccessSystemSettings: true,
            canEditWelcomeMessage: true,
            canEditAlertBanner: true,
          },
          userManagement: {
            canViewUsers: true,
            canCreateUsers: true,
            canEditUsers: true,
            canDeleteUsers: false,
          },
          transactions: {
            canViewAllTransactions: true,
            canEditTransactions: true,
            canDeleteTransactions: true,
          },
          vehicles: {
            canViewVehicles: true,
            canCreateVehicles: true,
            canEditVehicles: true,
            canDeleteVehicles: true,
          },
          tanks: {
            canViewTankLevels: true,
            canEditTankLevels: true,
            canCreateTanks: true,
            canDeleteTanks: true,
          },
        },
      },
      developer: {
        name: "Developer",
        description: "Full system access including user management, system settings, and development features",
        permissions: {
          systemSettings: {
            canAccessSystemSettings: true,
            canEditWelcomeMessage: true,
            canEditAlertBanner: true,
          },
          userManagement: {
            canViewUsers: true,
            canCreateUsers: true,
            canEditUsers: true,
            canDeleteUsers: true,
          },
          transactions: {
            canViewAllTransactions: true,
            canEditTransactions: true,
            canDeleteTransactions: true,
          },
          vehicles: {
            canViewVehicles: true,
            canCreateVehicles: true,
            canEditVehicles: true,
            canDeleteVehicles: true,
          },
          tanks: {
            canViewTankLevels: true,
            canEditTankLevels: true,
            canCreateTanks: true,
            canDeleteTanks: true,
          },
        },
      },
    };
  }

  async updateRoleTemplate(roleKey: string, templateData: any, userId?: string): Promise<any> {
    // For now, we'll store custom role templates in system settings
    // In a production system, you might want a dedicated table for this
    const settingKey = `role_template_${roleKey}`;
    const setting = {
      key: settingKey,
      value: JSON.stringify(templateData),
      description: `Role template for ${templateData.name}`,
      updatedAt: new Date(),
      updatedBy: userId,
    };
    
    await this.upsertSystemSetting(setting);
    
    // Return the updated template data
    return {
      [roleKey]: templateData
    };
  }

  async createRoleTemplate(roleKey: string, templateData: any, userId?: string): Promise<any> {
    // Check if role template already exists
    const existingSetting = await this.getSystemSetting(`role_template_${roleKey}`);
    if (existingSetting) {
      throw new Error(`Role template with key '${roleKey}' already exists`);
    }
    
    return await this.updateRoleTemplate(roleKey, templateData, userId);
  }
}

export const storage = new DatabaseStorage();
