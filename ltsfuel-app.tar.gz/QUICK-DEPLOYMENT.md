# Quick Deployment Guide - Ubuntu 24 VPS

**Fast 10-Minute Setup for Fleet Management App**

## Option 1: Automated Script (Recommended)

### 1. Download and Run Auto-Deployment Script
```bash
# On your Ubuntu 24 VPS as root:
wget https://raw.githubusercontent.com/your-repo/fleet-management/main/deploy-ubuntu-24.sh
chmod +x deploy-ubuntu-24.sh
./deploy-ubuntu-24.sh
```

### 2. Upload Your Application Files
```bash
# Using SCP from your local machine:
scp -r ./your-app-files/* root@your-server-ip:/home/ltsfuel/ltsfuel-app/

# Or using Git:
cd /home/ltsfuel/ltsfuel-app
git clone https://github.com/your-repo/fleet-management.git .
```

### 3. Start the Application
```bash
cd /home/ltsfuel/ltsfuel-app
npm install
npm run build
sudo -u ltsfuel pm2 start ecosystem.config.js
sudo -u ltsfuel pm2 save
sudo -u ltsfuel pm2 startup
```

**Done! Your app is now running at http://your-server-ip**

---

## Option 2: Manual Quick Setup

### Essential Commands Only (15 minutes)
```bash
# 1. Update system
apt update && apt upgrade -y

# 2. Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# 3. Install PostgreSQL
apt install -y postgresql postgresql-contrib
systemctl start postgresql
systemctl enable postgresql

# 4. Create database
sudo -u postgres createdb ltsfuel_db
sudo -u postgres psql -c "CREATE USER ltsfueluser WITH PASSWORD 'LtsFuel2025!';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ltsfuel_db TO ltsfueluser;"

# 5. Install Nginx & PM2
apt install -y nginx
npm install -g pm2
systemctl start nginx
systemctl enable nginx

# 6. Create app user
adduser ltsfuel
mkdir -p /home/ltsfuel/ltsfuel-app
chown -R ltsfuel:ltsfuel /home/ltsfuel

# 7. Upload your app files to /home/ltsfuel/ltsfuel-app/

# 8. Create .env file
echo "DATABASE_URL=postgresql://ltsfueluser:LtsFuel2025!@localhost:5432/ltsfuel_db" > /home/ltsfuel/ltsfuel-app/.env
echo "NODE_ENV=production" >> /home/ltsfuel/ltsfuel-app/.env
echo "PORT=3000" >> /home/ltsfuel/ltsfuel-app/.env

# 9. Install and build app
cd /home/ltsfuel/ltsfuel-app
npm install
npm run build

# 10. Start with PM2
sudo -u ltsfuel pm2 start dist/index.js --name ltsfuel-app
sudo -u ltsfuel pm2 save
sudo -u ltsfuel pm2 startup

# 11. Configure Nginx
cat > /etc/nginx/sites-available/default << 'EOF'
server {
    listen 80;
    server_name _;
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# 12. Restart Nginx
systemctl restart nginx
```

**Your app is now live at http://your-server-ip**

---

## Post-Deployment Checklist

### Immediate Actions (Required)
- [ ] Test app access: `curl http://localhost`
- [ ] Login with: `shawn.brouillette@leetransport.com` / `password123`
- [ ] Change default password immediately
- [ ] Update company name in settings

### Security (Recommended)
- [ ] Change SESSION_SECRET in .env file
- [ ] Setup SSL certificate: `certbot --nginx -d your-domain.com`
- [ ] Configure firewall: `ufw enable && ufw allow ssh && ufw allow 'Nginx Full'`

### Monitoring (Optional)
- [ ] Check PM2 status: `pm2 status`
- [ ] View logs: `pm2 logs ltsfuel-app`
- [ ] Setup daily backups (see full guide)

---

## Troubleshooting

### App Not Starting?
```bash
# Check logs
pm2 logs ltsfuel-app

# Restart app
pm2 restart ltsfuel-app

# Check database connection
psql -h localhost -U ltsfueluser -d ltsfuel_db
```

### Can't Access Website?
```bash
# Check if app is running
pm2 status

# Check Nginx status
systemctl status nginx

# Check firewall
ufw status
```

### Database Issues?
```bash
# Test database connection
sudo -u postgres psql -c "\l"

# Reset database user
sudo -u postgres psql -c "ALTER USER ltsfueluser PASSWORD 'LtsFuel2025!';"
```

---

## Support

- **Full Documentation**: See `Ubuntu-24-VPS-Deployment-Guide.md`
- **System Status**: Run `/home/ltsfuel/system-status.sh`
- **Update App**: Run `/home/ltsfuel/update-app.sh`

**Default Login**: shawn.brouillette@leetransport.com / password123 (change immediately)