import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Users, Plus, Edit, Trash2, Loader2, Upload, Download, Droplets, Shield } from "lucide-react";
import { AdminNavigationTabs } from "@/components/admin-navigation-tabs";
import { insertUserSchema, type User, type UserPermissions, userPermissionsSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import * as Papa from "papaparse";

type UserFormData = {
  username: string;
  password: string;
  name: string;
  email: string;
  role: "driver" | "administrator" | "developer";
  status: "active" | "locked_out";
  visibleTanks?: string[];
};

function UserManagementContent() {
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isTankVisibilityDialogOpen, setIsTankVisibilityDialogOpen] = useState(false);
  const [tankVisibilityUser, setTankVisibilityUser] = useState<User | null>(null);
  const [selectedTanks, setSelectedTanks] = useState<string[]>([]);
  const [isPermissionsDialogOpen, setIsPermissionsDialogOpen] = useState(false);
  const [permissionsUser, setPermissionsUser] = useState<User | null>(null);
  const [userPermissions, setUserPermissions] = useState<UserPermissions>({
    systemSettings: {
      canEditWelcomeMessage: false,
      canEditAlertBanner: false,
      canViewSystemLogs: false,
    }
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Available tanks
  const availableTanks = [
    { id: "tampa-diesel-tank", name: "Tampa Yard - Diesel" },
    { id: "tampa-def-tank", name: "Tampa Yard - DEF" },
    { id: "elmer-diesel-tank", name: "Elmer Yard - Diesel" },
    { id: "elmer-def-tank", name: "Elmer Yard - DEF" },
  ];

  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const createUserMutation = useMutation({
    mutationFn: async (userData: UserFormData) => {
      const res = await apiRequest("POST", "/api/register", userData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsCreateDialogOpen(false);
      createForm.reset();
      toast({
        title: "User created",
        description: "User has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ id, userData }: { id: string; userData: Partial<UserFormData> }) => {
      const res = await apiRequest("PUT", `/api/users/${id}`, userData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsEditDialogOpen(false);
      setEditingUser(null);
      toast({
        title: "User updated",
        description: "User has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateTankVisibilityMutation = useMutation({
    mutationFn: async ({ id, visibleTanks }: { id: string; visibleTanks: string[] }) => {
      const res = await apiRequest("PUT", `/api/users/${id}/tank-visibility`, { visibleTanks });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsTankVisibilityDialogOpen(false);
      setTankVisibilityUser(null);
      toast({
        title: "Tank visibility updated",
        description: "User's tank access has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating tank visibility",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "User deleted",
        description: "User has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting user",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const csvUploadMutation = useMutation({
    mutationFn: async (csvData: any[]) => {
      const res = await apiRequest("POST", "/api/users/csv-upload", { users: csvData });
      return await res.json();
    },
    onSuccess: (results) => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "CSV Upload Complete",
        description: `Created: ${results.created}, Updated: ${results.updated}, Errors: ${results.errors.length}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "CSV Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updatePermissionsMutation = useMutation({
    mutationFn: async ({ userId, permissions }: { userId: string; permissions: UserPermissions }) => {
      const res = await apiRequest("PUT", `/api/users/${userId}/permissions`, { permissions: JSON.stringify(permissions) });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsPermissionsDialogOpen(false);
      toast({
        title: "Permissions updated",
        description: "User permissions have been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating permissions",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createForm = useForm<UserFormData>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
      name: "",
      email: "",
      role: "driver" as "driver" | "administrator",
      status: "active" as "active" | "locked_out",
      visibleTanks: [],
    },
  });

  const editForm = useForm<Partial<UserFormData>>({
    defaultValues: {
      username: "",
      name: "",
      email: "",
      role: "driver",
      status: "active",
    },
  });

  const onCreateSubmit = (data: UserFormData) => {
    createUserMutation.mutate(data);
  };

  const onEditSubmit = (data: Partial<UserFormData>) => {
    if (!editingUser) return;
    updateUserMutation.mutate({ id: editingUser.id, userData: data });
  };

  const canEditUser = (user: User) => {
    // Only developers can edit other developers
    if (user.role === "developer" && currentUser?.role !== "developer") {
      return false;
    }
    return true;
  };

  const canDeleteUser = (user: User) => {
    // Only developers can delete users
    return currentUser?.role === "developer";
  };

  const handleEdit = (user: User) => {
    if (!canEditUser(user)) {
      toast({
        title: "Cannot edit user",
        description: "Only developers can edit developer accounts.",
        variant: "destructive",
      });
      return;
    }
    
    setEditingUser(user);
    editForm.reset({
      username: user.username,
      name: user.name,
      email: user.email,
      role: user.role as "driver" | "administrator" | "developer",
      status: user.status as "active" | "locked_out",
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (user: User) => {
    if (user.id === currentUser?.id) {
      toast({
        title: "Cannot delete",
        description: "You cannot delete your own account.",
        variant: "destructive",
      });
      return;
    }

    if (!canDeleteUser(user)) {
      toast({
        title: "Cannot delete user",
        description: "Only developers can delete user accounts.",
        variant: "destructive",
      });
      return;
    }
    
    if (confirm(`Are you sure you want to delete user "${user.name}"?`)) {
      deleteUserMutation.mutate(user.id);
    }
  };

  const handleTankVisibility = (user: User) => {
    setTankVisibilityUser(user);
    setSelectedTanks(user.visibleTanks || []);
    setIsTankVisibilityDialogOpen(true);
  };

  const handleTankVisibilitySubmit = () => {
    if (!tankVisibilityUser) return;
    
    updateTankVisibilityMutation.mutate({
      id: tankVisibilityUser.id,
      visibleTanks: selectedTanks,
    });
  };

  const handlePermissions = (user: User) => {
    setPermissionsUser(user);
    // Parse existing permissions or use defaults
    try {
      const parsed = user.permissions ? JSON.parse(user.permissions) : {};
      setUserPermissions({
        systemSettings: {
          canEditWelcomeMessage: parsed.systemSettings?.canEditWelcomeMessage || false,
          canEditAlertBanner: parsed.systemSettings?.canEditAlertBanner || false,
          canViewSystemLogs: parsed.systemSettings?.canViewSystemLogs || false,
        }
      });
    } catch (e) {
      setUserPermissions({
        systemSettings: {
          canEditWelcomeMessage: false,
          canEditAlertBanner: false,
          canViewSystemLogs: false,
        }
      });
    }
    setIsPermissionsDialogOpen(true);
  };

  const handlePermissionsSubmit = () => {
    if (!permissionsUser) return;
    
    updatePermissionsMutation.mutate({
      userId: permissionsUser.id,
      permissions: userPermissions,
    });
  };



  const handleCsvUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        csvUploadMutation.mutate(results.data);
      },
      error: (error) => {
        toast({
          title: "CSV Parse Error",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  const handleCsvExport = async () => {
    try {
      const res = await apiRequest("GET", "/api/users/csv-export");
      const data = await res.json();
      
      const csv = Papa.unparse(data);
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'users.csv';
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export user data.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Users className="h-5 w-5" />
          <h3 className="text-lg font-semibold">User Management</h3>
        </div>
        <div className="flex items-center space-x-2">
          {currentUser?.role === "developer" && (
            <>
              <input
                type="file"
                accept=".csv"
                onChange={handleCsvUpload}
                ref={fileInputRef}
                style={{ display: 'none' }}
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={csvUploadMutation.isPending}
              >
                <Upload className="h-4 w-4 mr-2" />
                Import CSV
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCsvExport}
              >
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>

            </>
          )}
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New User</DialogTitle>
                <DialogDescription>
                  Add a new user to the fleet management system.
                </DialogDescription>
              </DialogHeader>
              <Form {...createForm}>
                <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
                  <FormField
                    control={createForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Enter password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter full name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="Enter email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Role</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value as "driver" | "administrator" | "developer"}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select role" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="driver">Driver</SelectItem>
                            <SelectItem value="administrator">Administrator</SelectItem>
                            {currentUser?.role === "developer" && (
                              <SelectItem value="developer">Developer</SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={createForm.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value as "active" | "locked_out"}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            {currentUser?.role === "developer" && (
                              <SelectItem value="locked_out">Locked Out</SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {createForm.watch("role") === "driver" && (
                    <FormField
                      control={createForm.control}
                      name="visibleTanks"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tank Visibility</FormLabel>
                          <FormControl>
                            <div className="grid gap-2 border rounded-md p-3">
                              {availableTanks.map((tank) => (
                                <div key={tank.id} className="flex items-center space-x-2">
                                  <Checkbox
                                    id={`create-${tank.id}`}
                                    checked={field.value?.includes(tank.id) || false}
                                    onCheckedChange={(checked) => {
                                      const currentTanks = field.value || [];
                                      if (checked) {
                                        field.onChange([...currentTanks, tank.id]);
                                      } else {
                                        field.onChange(currentTanks.filter(id => id !== tank.id));
                                      }
                                    }}
                                  />
                                  <label htmlFor={`create-${tank.id}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                                    {tank.name}
                                  </label>
                                </div>
                              ))}
                              {availableTanks.length === 0 && (
                                <p className="text-sm text-gray-500">No tanks available</p>
                              )}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  <div className="flex space-x-2">
                    <Button
                      type="submit"
                      disabled={createUserMutation.isPending}
                      className="flex-1"
                    >
                      {createUserMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        "Create User"
                      )}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>



      <div className="grid gap-4">
        {users?.map((user) => (
          <Card key={user.id}>
            <CardContent className="flex items-center justify-between p-4">
              <div className="flex items-center space-x-4">
                <div>
                  <h4 className="font-medium">{user.name}</h4>
                  <p className="text-sm text-gray-600">@{user.username}</p>
                  <p className="text-sm text-gray-500">{user.email}</p>
                </div>
                <div className="flex flex-col space-y-1">
                  <Badge variant={
                    user.role === "developer" ? "destructive" : 
                    user.role === "administrator" ? "default" : 
                    "secondary"
                  }>
                    {user.role}
                  </Badge>
                  <Badge variant={user.status === "active" ? "default" : "destructive"}>
                    {user.status === "active" ? "Active" : "Locked Out"}
                  </Badge>
                </div>
              </div>
              <div className="flex space-x-2">
                {canEditUser(user) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(user)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                )}
                {canEditUser(user) && user.role === "driver" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleTankVisibility(user)}
                    title="Manage Tank Visibility"
                  >
                    <Droplets className="h-4 w-4" />
                  </Button>
                )}
                {currentUser?.role === "developer" && user.role === "administrator" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePermissions(user)}
                    title="Manage Permissions"
                  >
                    <Shield className="h-4 w-4" />
                  </Button>
                )}
                {canDeleteUser(user) && user.id !== currentUser?.id && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(user)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              Update user information and permissions.
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter username" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Password (leave blank to keep current)</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="Enter new password" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter full name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="Enter email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value as "driver" | "administrator" | "developer"}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="driver">Driver</SelectItem>
                        <SelectItem value="administrator">Administrator</SelectItem>
                        {currentUser?.role === "developer" && (
                          <SelectItem value="developer">Developer</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value as "active" | "locked_out"}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        {currentUser?.role === "developer" && (
                          <SelectItem value="locked_out">Locked Out</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex space-x-2">
                <Button
                  type="submit"
                  disabled={updateUserMutation.isPending}
                  className="flex-1"
                >
                  {updateUserMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update User"
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Tank Visibility Dialog */}
      <Dialog open={isTankVisibilityDialogOpen} onOpenChange={setIsTankVisibilityDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manage Tank Visibility</DialogTitle>
            <DialogDescription>
              Select which tanks {tankVisibilityUser?.name} can view in the driver portal.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-3">
              {availableTanks.map((tank) => (
                <div key={tank.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={tank.id}
                    checked={selectedTanks.includes(tank.id)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedTanks([...selectedTanks, tank.id]);
                      } else {
                        setSelectedTanks(selectedTanks.filter(id => id !== tank.id));
                      }
                    }}
                  />
                  <label htmlFor={tank.id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    {tank.name}
                  </label>
                </div>
              ))}
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={handleTankVisibilitySubmit}
                disabled={updateTankVisibilityMutation.isPending}
                className="flex-1"
              >
                {updateTankVisibilityMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Tank Visibility"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsTankVisibilityDialogOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Permissions Dialog */}
      <Dialog open={isPermissionsDialogOpen} onOpenChange={setIsPermissionsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manage Administrator Permissions</DialogTitle>
            <DialogDescription>
              Configure system settings access for {permissionsUser?.name}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-3">
              <h4 className="text-sm font-medium">System Settings Access</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="welcome-message"
                    checked={userPermissions.systemSettings.canEditWelcomeMessage}
                    onCheckedChange={(checked) => 
                      setUserPermissions(prev => ({
                        ...prev,
                        systemSettings: {
                          ...prev.systemSettings,
                          canEditWelcomeMessage: checked as boolean
                        }
                      }))
                    }
                  />
                  <label htmlFor="welcome-message" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Can edit welcome message
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="alert-banner"
                    checked={userPermissions.systemSettings.canEditAlertBanner}
                    onCheckedChange={(checked) => 
                      setUserPermissions(prev => ({
                        ...prev,
                        systemSettings: {
                          ...prev.systemSettings,
                          canEditAlertBanner: checked as boolean
                        }
                      }))
                    }
                  />
                  <label htmlFor="alert-banner" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Can edit alert banner
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="system-logs"
                    checked={userPermissions.systemSettings.canViewSystemLogs}
                    onCheckedChange={(checked) => 
                      setUserPermissions(prev => ({
                        ...prev,
                        systemSettings: {
                          ...prev.systemSettings,
                          canViewSystemLogs: checked as boolean
                        }
                      }))
                    }
                  />
                  <label htmlFor="system-logs" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Can view system logs
                  </label>
                </div>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={handlePermissionsSubmit}
                disabled={updatePermissionsMutation.isPending}
                className="flex-1"
              >
                {updatePermissionsMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Permissions"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsPermissionsDialogOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function UserManagement() {
  return (
    <div className="space-y-6">
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>User Management</span>
            </CardTitle>
            <CardDescription>
              Manage system user accounts and permissions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <UserManagementContent />
          </CardContent>
        </Card>
      </div>
      

    </div>
  );
}