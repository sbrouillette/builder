import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import { FileText, Calendar, User, MapPin, Globe } from "lucide-react";
import { format } from "date-fns";
import type { SystemLog } from "@shared/schema";

export default function AdminSystemLogs() {
  const { data: logs, isLoading } = useQuery<SystemLog[]>({
    queryKey: ["/api/system-logs"],
  });

  const getActionBadgeVariant = (action: string) => {
    if (action.includes("LOGIN") || action.includes("REGISTER")) return "default";
    if (action.includes("CREATE") || action.includes("UPDATE")) return "secondary";
    if (action.includes("DELETE")) return "destructive";
    return "outline";
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <FileText className="h-5 w-5" />
          <h3 className="text-lg font-semibold">System Logs</h3>
        </div>
        <div className="flex items-center justify-center py-8">
          <div className="text-muted-foreground">Loading system logs...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <FileText className="h-5 w-5" />
        <h3 className="text-lg font-semibold">System Logs</h3>
        <Badge variant="secondary" className="ml-auto">
          {logs?.length || 0} entries
        </Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Audit Trail</CardTitle>
          <CardDescription>
            Complete log of all user actions in the system with IP addresses and timestamps
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] w-full">
            {logs && logs.length > 0 ? (
              <div className="space-y-4">
                {logs.map((log) => (
                  <div key={log.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <Badge variant={getActionBadgeVariant(log.action)}>
                          {log.action}
                        </Badge>
                        <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                          <User className="h-3 w-3" />
                          <span className="font-medium">{log.username}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        <span>
                          {log.timestamp ? format(new Date(log.timestamp), "MMM dd, yyyy 'at' h:mm a") : "Unknown"}
                        </span>
                      </div>
                    </div>

                    {log.details && (
                      <div className="text-sm text-gray-700 bg-gray-50 rounded p-2">
                        {log.details}
                      </div>
                    )}

                    <Separator className="my-2" />

                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <Globe className="h-3 w-3" />
                          <span>IP: {log.ipAddress}</span>
                        </div>
                        {log.userId && (
                          <div className="flex items-center space-x-1">
                            <span>User ID: {log.userId}</span>
                          </div>
                        )}
                      </div>
                      {log.userAgent && (
                        <div className="max-w-xs truncate" title={log.userAgent}>
                          {log.userAgent.length > 50 
                            ? `${log.userAgent.substring(0, 50)}...` 
                            : log.userAgent
                          }
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No system logs found
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>


    </div>
  );
}