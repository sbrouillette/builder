import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Edit, Plus, Trash2, Fuel, Droplets, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface TankLevel {
  id: string;
  name: string;
  type: string;
  location: string;
  currentLevel: string;
  capacity: string;
  unit: string;
  lastUpdated: string;
}

const tankFormSchema = z.object({
  name: z.string().min(1, "Tank name is required"),
  type: z.enum(["diesel", "def"], { required_error: "Tank type is required" }),
  location: z.string().min(1, "Location is required"),
  capacity: z.coerce.number().positive("Capacity must be positive"),
  currentLevel: z.coerce.number().min(0, "Current level cannot be negative"),
  unit: z.string().default("gallons"),
});

type TankFormData = z.infer<typeof tankFormSchema>;

export default function AdminTankOptions() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingTank, setEditingTank] = useState<TankLevel | null>(null);
  const { toast } = useToast();

  const { data: tanks = [], isLoading } = useQuery<TankLevel[]>({
    queryKey: ["/api/tank-levels"],
  });

  const createTankMutation = useMutation({
    mutationFn: async (data: TankFormData) => {
      const res = await apiRequest("POST", "/api/tank-levels", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tank-levels"] });
      setIsCreateDialogOpen(false);
      createForm.reset();
      toast({
        title: "Tank created",
        description: "Tank has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating tank",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateTankMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<TankFormData> }) => {
      const res = await apiRequest("PUT", `/api/tank-levels/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tank-levels"] });
      setIsEditDialogOpen(false);
      setEditingTank(null);
      editForm.reset();
      toast({
        title: "Tank updated",
        description: "Tank has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating tank",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTankMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/tank-levels/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tank-levels"] });
      toast({
        title: "Tank deleted",
        description: "Tank has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting tank",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createForm = useForm<TankFormData>({
    resolver: zodResolver(tankFormSchema),
    defaultValues: {
      name: "",
      type: "diesel",
      location: "",
      capacity: 0,
      currentLevel: 0,
      unit: "gallons",
    },
  });

  const editForm = useForm<TankFormData>({
    resolver: zodResolver(tankFormSchema),
    defaultValues: {
      name: "",
      type: "diesel",
      location: "",
      capacity: 0,
      currentLevel: 0,
      unit: "gallons",
    },
  });

  const onCreateSubmit = (data: TankFormData) => {
    createTankMutation.mutate(data);
  };

  const onEditSubmit = (data: TankFormData) => {
    if (!editingTank) return;
    updateTankMutation.mutate({ id: editingTank.id, data });
  };

  const handleEdit = (tank: TankLevel) => {
    setEditingTank(tank);
    editForm.reset({
      name: tank.name,
      type: tank.type as "diesel" | "def",
      location: tank.location,
      capacity: parseFloat(tank.capacity),
      currentLevel: parseFloat(tank.currentLevel),
      unit: tank.unit,
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (tank: TankLevel) => {
    if (confirm(`Are you sure you want to delete tank "${tank.name}"? This action cannot be undone.`)) {
      deleteTankMutation.mutate(tank.id);
    }
  };

  const getTankIcon = (type: string) => {
    return type === "diesel" ? Fuel : Droplets;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-lee-primary mb-2">Tank Options</h1>
        </div>
        <div className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="text-center flex-1">
          <h1 className="text-2xl font-bold text-lee-primary mb-2">Tank Options</h1>
          <p className="text-gray-600">Manage tank configurations and settings</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="ml-4">
              <Plus className="h-4 w-4 mr-2" />
              Add Tank
            </Button>
          </DialogTrigger>
          <DialogContent className="dialog-content">
            <DialogHeader>
              <DialogTitle>Create New Tank</DialogTitle>
            </DialogHeader>
            <Form {...createForm}>
              <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
                <FormField
                  control={createForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tank Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Tampa Yard Diesel Tank" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tank Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select tank type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="diesel">Diesel</SelectItem>
                          <SelectItem value="def">DEF</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Yard Location</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Tampa Yard, Elmer Yard" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="capacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tank Capacity (gallons)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="e.g., 10000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="currentLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Level (gallons)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="e.g., 8500" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex space-x-2">
                  <Button
                    type="submit"
                    disabled={createTankMutation.isPending}
                    className="flex-1"
                  >
                    {createTankMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      "Create Tank"
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tank Cards */}
      <div className="space-y-4">
        {tanks.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-gray-500">No tanks configured. Create your first tank to get started.</p>
            </CardContent>
          </Card>
        ) : (
          tanks.map((tank) => {
            const currentLevel = parseFloat(tank.currentLevel);
            const capacity = parseFloat(tank.capacity);
            const percentage = Math.round((currentLevel / capacity) * 100);
            const Icon = getTankIcon(tank.type);
            
            return (
              <Card key={tank.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Icon className="h-6 w-6 text-lee-primary" />
                      <div>
                        <div className="text-lg font-bold">{tank.name}</div>
                        <div className="text-sm text-gray-500 font-normal">
                          {tank.location} • {tank.type.toUpperCase()} Tank
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(tank)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(tank)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Tank Details */}
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Current:</span>
                      <div className="font-bold text-base">
                        {currentLevel.toLocaleString()} {tank.unit}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-500">Capacity:</span>
                      <div className="font-bold text-base">
                        {capacity.toLocaleString()} {tank.unit}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-500">Fill Level:</span>
                      <div className="font-bold text-base">
                        <Badge variant={percentage < 25 ? "destructive" : percentage < 50 ? "secondary" : "default"}>
                          {percentage}%
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Last Updated */}
                  <div className="text-xs text-gray-400 border-t pt-2">
                    Last updated: {new Date(tank.lastUpdated).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Edit Tank Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="dialog-content">
          <DialogHeader>
            <DialogTitle>Edit Tank</DialogTitle>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tank Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Tampa Yard Diesel Tank" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tank Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select tank type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="diesel">Diesel</SelectItem>
                        <SelectItem value="def">DEF</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Yard Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Tampa Yard, Elmer Yard" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="capacity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tank Capacity (gallons)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="e.g., 10000" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="currentLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Level (gallons)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="e.g., 8500" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex space-x-2">
                <Button
                  type="submit"
                  disabled={updateTankMutation.isPending}
                  className="flex-1"
                >
                  {updateTankMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Tank"
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>


    </div>
  );
}